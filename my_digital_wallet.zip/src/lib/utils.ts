import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const currencyFormatter = new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
  useGrouping: true,
});

export function formatCurrency(amount: number, currency: string = 'YER', language: string = 'ar') {
  const formatted = currencyFormatter.format(Math.round(amount));
  
  const symbolsAr: Record<string, string> = {
    'YER': 'ر.ي',
    'SAR': 'ر.س',
    'USD': '$'
  };

  const symbolsEn: Record<string, string> = {
    'YER': 'YER',
    'SAR': 'SAR',
    'USD': 'USD'
  };

  const symbols = language === 'ar' ? symbolsAr : symbolsEn;
  
  if (language === 'ar') {
    return `${formatted} ${symbols[currency] || currency}`;
  } else {
    return `${symbols[currency] || currency} ${formatted}`;
  }
}

export function formatAmountInput(val: string) {
  // Remove all non-digit and non-decimal point characters
  const clean = val.replace(/[^\d.]/g, '');
  
  // Prevent multiple decimal points
  const parts = clean.split('.');
  const fixed = parts[0] + (parts.length > 1 ? '.' + parts[1].slice(0, 2) : '');
  
  if (fixed === '') return '';
  
  const [int, dec] = fixed.split('.');
  const formattedInt = Number(int).toLocaleString('en-US');
  return dec !== undefined ? `${formattedInt}.${dec}` : formattedInt;
}

export function cleanAmount(val: string) {
  return val.replace(/[^\d.]/g, '');
}
