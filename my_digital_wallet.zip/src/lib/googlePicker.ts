let isGapiLoaded = false;

const loadScript = (src: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.body.appendChild(script);
  });
};

export const openGooglePicker = async (
  accessToken: string, 
  onSelected: (file: { id: string; name: string; url: string; mimeType: string }) => void
): Promise<void> => {
  try {
    await loadScript('https://apis.google.com/js/api.js');
    
    return new Promise((resolve, reject) => {
      const globalGapi = (window as any).gapi;
      if (typeof globalGapi === 'undefined') {
        reject(new Error('Google API Client (gapi) not loaded.'));
        return;
      }

      const initPicker = () => {
        try {
          const googleObj = (window as any).google;
          if (!googleObj || !googleObj.picker) {
            reject(new Error('Google Picker API is not loaded yet.'));
            return;
          }

          const view = new googleObj.picker.View(googleObj.picker.ViewId.DOCS);
          
          const picker = new googleObj.picker.PickerBuilder()
            .addView(view)
            .setOAuthToken(accessToken)
            .setDeveloperKey("AIzaSyBNkpdKJY6yD0KDmRPLOJBh1LC-SmqLKXE")
            .setCallback((data: any) => {
              if (data[googleObj.picker.Response.ACTION] === googleObj.picker.Action.PICKED) {
                const doc = data[googleObj.picker.Response.DOCUMENTS][0];
                onSelected({
                  id: doc.id,
                  name: doc.name,
                  url: doc.url,
                  mimeType: doc.mimeType
                });
                resolve();
              } else if (data[googleObj.picker.Response.ACTION] === googleObj.picker.Action.CANCEL) {
                resolve();
              }
            })
            .build();
          picker.setVisible(true);
        } catch (err) {
          console.error('Picker initialization failed:', err);
          reject(err);
        }
      };

      if (isGapiLoaded) {
        initPicker();
      } else {
        globalGapi.load('picker', {
          callback: () => {
            isGapiLoaded = true;
            initPicker();
          },
          onerror: () => reject(new Error('Failed to load Google Picker extension.'))
        });
      }
    });
  } catch (err) {
    console.error('Error in openGooglePicker:', err);
    throw err;
  }
};
