import React, { useState, useEffect, useMemo, useDeferredValue } from 'react';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Search, 
  Filter, 
  Calendar,
  X,
  CreditCard,
  History,
  LayoutDashboard,
  ArrowRightLeft,
  ChevronRight,
  ChevronLeft,
  Check,
  MoreVertical,
  Trash2,
  Briefcase,
  Gift,
  Utensils,
  Home,
  Car,
  HeartPulse,
  Gamepad2,
  ShoppingBag,
  MoreHorizontal,
  UserCircle,
  LogOut,
  Settings,
  Lock,
  Delete,
  Mail,
  User as UserIcon,
  Sun,
  Moon,
  Bell,
  BellOff,
  Clock,
  PieChart as PieChartIcon,
  Target,
  Banknote,
  Building2,
  Sparkles,
  CircleDollarSign,
  Coffee,
  Key,
  BusFront,
  Stethoscope,
  Tv,
  ShoppingCart,
  Receipt,
  ArrowUpDown,
  Tag,
  Phone,
  MapPin,
  FileText,
  FileDown,
  Download,
  Edit2,
  RotateCcw,
  Wand2 // AI Icon
} from 'lucide-react';
import * as Icons from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie,
  Legend
} from 'recharts';
import { format, startOfMonth, endOfMonth, isWithinInterval, parseISO, subDays } from 'date-fns';
import { ar } from 'date-fns/locale';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { 
  onSnapshot, 
  collection, 
  addDoc, 
  deleteDoc, 
  doc, 
  setDoc,
  query,
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { onAuthStateChanged, User, GoogleAuthProvider } from 'firebase/auth';
import { openGooglePicker } from './lib/googlePicker.ts';

import { 
  db, 
  auth, 
  googleProvider, 
  facebookProvider,
  signInWithPopup, 
  signOut, 
  serverTimestamp,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
  sendEmailVerification
} from './lib/firebase.ts';
import { Transaction, TransactionType, DEFAULT_CATEGORIES, Invoice, InvoiceItem, Category } from './types.ts';
import { cn, formatCurrency as formatCurrencyBase, formatAmountInput, cleanAmount } from './lib/utils.ts';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const LOCAL_STORAGE_KEY = 'accounting_ledger_v1';

const CATEGORY_COLORS: Record<string, string> = {
  food: '#F59E0B', // amber-500
  rent: '#3B82F6', // brand blue
  transport: '#6366F1', // indigo-500
  health: '#EF4444', // red-500
  entertainment: '#8B5CF6', // violet-500
  shopping: '#EC4899', // pink-500
  other_expense: '#64748B', // slate-500
  salary: '#10B981', // emerald-500
  business: '#06B6D4', // cyan-500
  gift: '#F43F5E', // rose-500
  other_income: '#64748B', // slate-500
};

const safeHtml2canvas = async (element: HTMLElement, options: any) => {
  const sheetProto = CSSStyleSheet.prototype;
  const ruleProto = CSSRule.prototype;
  const declProto = CSSStyleDeclaration.prototype;

  const originalCssRules = Object.getOwnPropertyDescriptor(sheetProto, 'cssRules');
  const originalRules = Object.getOwnPropertyDescriptor(sheetProto, 'rules');
  const originalRuleCssText = Object.getOwnPropertyDescriptor(ruleProto, 'cssText');
  const originalGetPropertyValue = declProto.getPropertyValue;
  const originalDeclCssText = Object.getOwnPropertyDescriptor(declProto, 'cssText');
  const originalGetComputedStyle = window.getComputedStyle;

  const cleanColorString = (str: string) => {
    if (!str || typeof str !== 'string') return str;
    return str
      .replace(/oklch\([^)]+\)/gi, '#64748b')
      .replace(/oklab\([^)]+\)/gi, '#64748b');
  };

  const createRulesProxy = (rules: any) => {
    if (!rules) return rules;
    return new Proxy(rules, {
      get(target, prop) {
        if (prop === 'length') return target.length;
        const index = Number(prop);
        if (!isNaN(index)) {
          const rule = target[index];
          if (!rule) return rule;
          return new Proxy(rule, {
            get(ruleTarget, ruleProp) {
              if (ruleProp === 'cssText') {
                return cleanColorString(ruleTarget.cssText);
              }
              const val = ruleTarget[ruleProp as any];
              if (typeof val === 'function') {
                return val.bind(ruleTarget);
              }
              return val;
            }
          });
        }
        const val = target[prop as any];
        if (typeof val === 'function') {
          return val.bind(target);
        }
        return val;
      }
    });
  };

  if (originalCssRules) {
    Object.defineProperty(sheetProto, 'cssRules', {
      configurable: true,
      get() {
        return createRulesProxy(originalCssRules.get?.call(this));
      }
    });
  }
  if (originalRules) {
    Object.defineProperty(sheetProto, 'rules', {
      configurable: true,
      get() {
        return createRulesProxy(originalRules.get?.call(this));
      }
    });
  }

  if (originalRuleCssText) {
    Object.defineProperty(ruleProto, 'cssText', {
      configurable: true,
      get() {
        return cleanColorString(originalRuleCssText.get?.call(this) || '');
      },
      set(val) {
        originalRuleCssText.set?.call(this, val);
      }
    });
  }

  declProto.getPropertyValue = function(propertyName: string) {
    const val = originalGetPropertyValue.call(this, propertyName);
    return cleanColorString(val);
  };

  if (originalDeclCssText) {
    Object.defineProperty(declProto, 'cssText', {
      configurable: true,
      get() {
        return cleanColorString(originalDeclCssText.get?.call(this) || '');
      },
      set(val) {
        originalDeclCssText.set?.call(this, val);
      }
    });
  }

  window.getComputedStyle = function(el: Element, pseudoElt?: string | null) {
    const style = originalGetComputedStyle.call(window, el, pseudoElt);
    return new Proxy(style, {
      get(target, prop) {
        if (prop === 'getPropertyValue') {
          return function(this: any, propertyName: string) {
            const val = target.getPropertyValue(propertyName);
            return cleanColorString(val);
          };
        }
        const val = target[prop as any];
        if (typeof val === 'string') {
          return cleanColorString(val);
        }
        if (typeof val === 'function') {
          return val.bind(target);
        }
        return val;
      }
    });
  };

  try {
    return await html2canvas(element, options);
  } finally {
    if (originalCssRules) {
      Object.defineProperty(sheetProto, 'cssRules', originalCssRules);
    }
    if (originalRules) {
      Object.defineProperty(sheetProto, 'rules', originalRules);
    }
    if (originalRuleCssText) {
      Object.defineProperty(ruleProto, 'cssText', originalRuleCssText);
    }
    declProto.getPropertyValue = originalGetPropertyValue;
    if (originalDeclCssText) {
      Object.defineProperty(declProto, 'cssText', originalDeclCssText);
    }
    window.getComputedStyle = originalGetComputedStyle;
  }
};

const cleanHtml2canvasStyles = (doc: Document) => {
  try {
    // 1. Clear adopted style sheets to prevent they hold oklch/oklab in Chrome
    if ((doc as any).adoptedStyleSheets) {
      try {
        (doc as any).adoptedStyleSheets = [];
      } catch (e) {}
    }

    // 2. Read and extract all CSS texts from style tags and stylesheets
    const cssTexts: string[] = [];
    
    // Process all style tags directly
    const styleTags = doc.querySelectorAll('style');
    styleTags.forEach(style => {
      cssTexts.push(style.textContent || style.innerHTML || '');
    });

    // Also try reading from all stylesheets just in case they were dynamically created empty style tags
    const sheets = Array.from(doc.styleSheets);
    for (const sheet of sheets) {
      try {
        const rules = sheet.cssRules || sheet.rules;
        if (rules) {
          const rulesText = Array.from(rules)
            .map(rule => rule.cssText)
            .join('\n');
          if (rulesText && !cssTexts.includes(rulesText)) {
            cssTexts.push(rulesText);
          }
        }
      } catch (e) {
        // Suppress security/CORS errors for cross-origin link tags
      }
    }

    // 3. Remove all original style tags
    styleTags.forEach(node => {
      node.parentNode?.removeChild(node);
    });

    // 4. Create a single new style tag with oklch and oklab stripped
    const fullCssText = cssTexts.join('\n');
    const cleanedCssText = fullCssText
      .replace(/oklch\([^)]+\)/gi, '#64748b')
      .replace(/oklab\([^)]+\)/gi, '#64748b');

    const newStyle = doc.createElement('style');
    newStyle.setAttribute('type', 'text/css');
    newStyle.appendChild(doc.createTextNode(cleanedCssText));
    doc.head.appendChild(newStyle);

    // 5. Override getComputedStyle on the cloned document's window
    const win = doc.defaultView;
    if (win) {
      const originalGetComputedStyle = win.getComputedStyle;
      win.getComputedStyle = function (el: Element, pseudoElt?: string | null) {
        const style = originalGetComputedStyle.call(win, el, pseudoElt);
        return new Proxy(style, {
          get(target, prop) {
            if (prop === 'getPropertyValue') {
              return function(this: any, propertyName: string) {
                const val = target.getPropertyValue(propertyName);
                if (typeof val === 'string' && (val.toLowerCase().includes('oklch') || val.toLowerCase().includes('oklab'))) {
                  return val
                    .replace(/oklch\([^)]+\)/gi, '#64748b')
                    .replace(/oklab\([^)]+\)/gi, '#64748b');
                }
                return val;
              };
            }
            const val = target[prop as any];
            if (typeof val === 'string') {
              if (val.toLowerCase().includes('oklch') || val.toLowerCase().includes('oklab')) {
                return val
                  .replace(/oklch\([^)]+\)/gi, '#64748b')
                  .replace(/oklab\([^)]+\)/gi, '#64748b');
              }
            }
            if (typeof val === 'function') {
              return val.bind(target);
            }
            return val;
          }
        });
      };
    }

    // 6. Inline cleanup of oklch/oklab in elem style attributes
    const allElements = doc.querySelectorAll('*');
    allElements.forEach(el => {
      const htmlEl = el as HTMLElement;
      if (htmlEl.style && htmlEl.style.cssText) {
        if (htmlEl.style.cssText.toLowerCase().includes('oklch') || htmlEl.style.cssText.toLowerCase().includes('oklab')) {
          htmlEl.style.cssText = htmlEl.style.cssText
            .replace(/oklch\([^)]+\)/gi, '#64748b')
            .replace(/oklab\([^)]+\)/gi, '#64748b');
        }
      }
    });
  } catch (error) {
    console.error("Error cleaning stylesheets for HTML2Canvas capture:", error);
  }
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [view, setView] = useState<'dashboard' | 'transactions' | 'invoices' | 'reports' | 'settings' | 'categories'>('dashboard');
  const [settingsView, setSettingsView] = useState<'main' | 'account' | 'exchange' | 'language' | 'budget'>('main');
  const [selectedCurrency, setSelectedCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [pendingCurrency, setPendingCurrency] = useState<'YER' | 'SAR' | 'USD' | null>(null);
  const [isCurrencyConfirmOpen, setIsCurrencyConfirmOpen] = useState(false);
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [budgets, setBudgets] = useState<Record<string, number>>({ YER: 0, SAR: 0, USD: 0 });
  const [reportDate, setReportDate] = useState(format(new Date(), 'yyyy-MM'));
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly'>('monthly');
  const [reportDailyDate, setReportDailyDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [reportWeeklyDate, setReportWeeklyDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [searchQuery, setSearchQuery] = useState('');
  const deferredSearchQuery = useDeferredValue(searchQuery);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryFormData, setCategoryFormData] = useState<Partial<Category>>({
    name: '',
    nameEn: '',
    icon: 'Tag',
    color: 'bg-emerald-500',
    type: 'expense'
  });
  const [invoiceFormData, setInvoiceFormData] = useState<Partial<Invoice>>({
    items: [],
    date: format(new Date(), 'yyyy-MM-dd'),
    invoiceNumber: '',
    shopName: '',
  });
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isAiSummarizing, setIsAiSummarizing] = useState(false);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(() => {
    return localStorage.getItem('google_access_token');
  });

  const ensureGoogleAccessToken = async (): Promise<string> => {
    if (googleAccessToken) return googleAccessToken;
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGoogleAccessToken(credential.accessToken);
        localStorage.setItem('google_access_token', credential.accessToken);
        return credential.accessToken;
      }
      throw new Error('No access token returned');
    } catch (err: any) {
      console.error('Failed to get Google Access Token', err);
      throw err;
    }
  };

   const handleAiSummarize = async (mode: 'summarize' | 'extract' = 'summarize') => {
    if (mode === 'summarize' && (!invoiceFormData.items || invoiceFormData.items.length === 0)) {
      sendNotification(
        language === 'ar' ? 'لا توجد أصناف' : 'No Items',
        language === 'ar' ? 'يرجى إضافة أصناف أولاً لتلخيصها' : 'Please add items first to summarize'
      );
      return;
    }

    if (mode === 'extract' && (!invoiceFormData.notes || invoiceFormData.notes.length < 5)) {
      sendNotification(
        language === 'ar' ? 'الوصف قصير جداً' : 'Description too short',
        language === 'ar' ? 'يرجى كتابة تفاصيل الفاتورة في الملاحظات ليتم استخراجها' : 'Please write invoice details in notes to extract them'
      );
      return;
    }

    setIsAiSummarizing(true);
    try {
      const response = await fetch('/api/ai/summarize-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          transactions: mode === 'summarize' ? invoiceFormData.items.map(it => ({
            date: invoiceFormData.date,
            description: it.name,
            amount: it.total
          })) : undefined,
          text: mode === 'extract' ? invoiceFormData.notes : undefined,
          mode,
          language 
        }),
      });

      if (!response.ok) throw new Error('AI request failed');
      const data = await response.json();
      
      if (mode === 'extract' && data.items) {
        setInvoiceFormData(prev => ({
          ...prev,
          items: data.items.map((it: any) => ({
            ...it,
            id: Math.random().toString(36).substr(2, 9)
          }))
        }));
        sendNotification(
          language === 'ar' ? 'تم استخراج البيانات' : 'Details Extracted',
          language === 'ar' ? 'تم تعبئة بنود الفاتورة من الوصف بنجاح' : 'Invoice items filled from description successfully'
        );
      } else {
        setInvoiceFormData(prev => ({
          ...prev,
          notes: data.summary
        }));
        sendNotification(
          language === 'ar' ? 'تم توليد البيان' : 'Summary Generated',
          language === 'ar' ? 'تم تحديث ملاحظات الفاتورة بنجاح' : 'Invoice notes updated successfully'
        );
      }
    } catch (error) {
      console.error(error);
      sendNotification(
        language === 'ar' ? 'فشل الذكاء الاصطناعي' : 'AI Generation Failed',
        language === 'ar' ? 'حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي' : 'An error occurred while connecting to AI service'
      );
    } finally {
      setIsAiSummarizing(false);
    }
  };

  const handleOpenPickerForInvoice = async () => {
    try {
      const token = await ensureGoogleAccessToken();
      await openGooglePicker(token, (file) => {
        setInvoiceFormData(prev => ({
          ...prev,
          attachment: file
        }));
        sendNotification(
          language === 'ar' ? 'تم إرفاق الملف' : 'File Attached',
          language === 'ar' ? `تم اختيار: ${file.name}` : `Selected: ${file.name}`
        );
      });
    } catch (error) {
      console.error('Failed to open Google Picker', error);
      sendNotification(
        language === 'ar' ? 'فشل الاتصال بـ Google Drive' : 'Drive Connection Failed',
        language === 'ar' ? 'تأكد من إعطاء الصلاحية لـ Google Drive' : 'Ensure scope permission is granted to Google Drive'
      );
    }
  };
  const [isResetLoading, setIsResetLoading] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState('');
  const [isEditingLedgerId, setIsEditingLedgerId] = useState(false);
  const [newLedgerId, setNewLedgerId] = useState('');
  const [ledgerId, setLedgerId] = useState('');
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [newBudget, setNewBudget] = useState('');
  const invoiceRef = React.useRef<HTMLDivElement>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: keyof Transaction, direction: 'asc' | 'desc' }>({
    key: 'date',
    direction: 'desc'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('theme') as 'light' | 'dark') || 'dark';
  });
  const [brandColor, setBrandColor] = useState<string>(() => {
    return localStorage.getItem('brandColor') || '#3B82F6';
  });

  const formatCurrency = (amount: number, currency: string = selectedCurrency) => formatCurrencyBase(amount, currency, language);

  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  
  // Apply theme to document
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Handle RTL/LTR based on language
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  // Apply brand color to document
  useEffect(() => {
    document.documentElement.style.setProperty('--brand-color', brandColor);
    localStorage.setItem('brandColor', brandColor);
  }, [brandColor]);

  // Check notification permission
  useEffect(() => {
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        sendNotification('تم تفعيل الإشعارات', 'ستصلك تنبيهات بكل عملية جديدة يتم تسجيلها بنجاح.');
      }
    }
  };

  const sendNotification = (title: string, body: string) => {
    if (notificationPermission === 'granted') {
      new Notification(title, { body, icon: '/favicon.ico' });
    }
  };

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');
  
  // Auth Form State
  const [authMode, setAuthMode] = useState<'social' | 'email'>('social');
  const [emailMode, setEmailMode] = useState<'login' | 'signup' | 'reset'>('login');
  const [emailAuthData, setEmailAuthData] = useState({
    email: '',
    password: '',
    displayName: ''
  });

  const [authError, setAuthError] = useState<string | null>(null);
  const [authMessage, setAuthMessage] = useState<string | null>(null);
  const [isAuthActionLoading, setIsAuthActionLoading] = useState(false);
  
  // Auth State Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Validation connection on boot
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // Firestore Real-time Listener
  useEffect(() => {
    if (!user) {
      setTransactions([]);
      return;
    }

    const path = `users/${user.uid}/transactions`;
    const q = query(collection(db, path), orderBy('date', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })) as Transaction[];
      setTransactions(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    // Profile listener
    const profilePath = `profiles/${user.uid}`;
    const unsubProfile = onSnapshot(doc(db, profilePath), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setLedgerId(data?.ledgerId || '');
        setBudgets(data?.budgets || { YER: 0, SAR: 0, USD: 0 });
        setLanguage(data?.language || 'ar');
        setSelectedCurrency(data?.selectedCurrency || 'YER');
      }
    });

    // Categories listener
    const categoriesPath = `users/${user.uid}/categories`;
    const unsubCategories = onSnapshot(collection(db, categoriesPath), (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })) as Category[];
      setCategories(docs);
      
      if (snapshot.empty && !localStorage.getItem(`seeded_${user.uid}`)) {
        seedDefaultCategories(user.uid);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, categoriesPath);
    });

    // Invoices listener
    const invoicesPath = `users/${user.uid}/invoices`;
    const invoicesQ = query(collection(db, invoicesPath), orderBy('date', 'desc'));
    const unsubInvoices = onSnapshot(invoicesQ, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })) as Invoice[];
      setInvoices(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, invoicesPath);
    });

    return () => {
      unsubscribe();
      unsubProfile();
      unsubCategories();
      unsubInvoices();
    };
  }, [user]);

  const seedDefaultCategories = async (userId: string) => {
    const categoriesPath = `users/${userId}/categories`;
    const promises = [];
    
    const types: TransactionType[] = ['income', 'expense'];
    for (const type of types) {
      for (const cat of DEFAULT_CATEGORIES[type]) {
        const catData = {
          ...cat,
          type,
          userId,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        promises.push(setDoc(doc(db, categoriesPath, cat.id), catData));
      }
    }
    
    try {
      await Promise.all(promises);
      localStorage.setItem(`seeded_${userId}`, 'true');
    } catch (error) {
      console.error('Seeding failed', error);
    }
  };

  const handleLogin = async (provider: 'google' | 'facebook' = 'google') => {
    setAuthError(null);
    setAuthMessage(null);
    try {
      const authProvider = provider === 'facebook' ? facebookProvider : googleProvider;
      await signInWithPopup(auth, authProvider);
    } catch (error: any) {
      console.warn('Login non-fatal info:', error);
      const code = error.code || '';
      
      if (code === 'auth/operation-not-allowed') {
        setAuthError(language === 'ar' 
          ? 'دخول فيسبوك غير مفعّل حالياً. يرجى تفعيله من لوحة تحكم Firebase.' 
          : 'Social login is not enabled. Please enable it in the Firebase Console.');
      } else if (code === 'auth/account-exists-with-different-credential') {
        setAuthError(language === 'ar' 
          ? 'يوجد حساب مرتبط بهذا البريد الإلكتروني باستخدام وسيلة دخول أخرى. يرجى الدخول بوسيلة الدخول الأصلية.' 
          : 'An account already exists with the same email address but different sign-in credentials. Please use your original sign-in method.');
      } else {
        setAuthError(error.message);
      }
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthMessage(null);
    setIsAuthActionLoading(true);

    const cleanEmail = emailAuthData.email.trim();
    if (!cleanEmail) {
      setAuthError(language === 'ar' ? 'يرجى إدخال البريد الإلكتروني.' : 'Please enter an email.');
      setIsAuthActionLoading(false);
      return;
    }

    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      setAuthMessage(language === 'ar' 
        ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني. يرجى التحقق من صندوق الوارد.' 
        : 'Password reset link sent to your email. Please check your inbox.');
      setEmailMode('login');
    } catch (error: any) {
      console.warn('Password reset non-fatal info:', error);
      const code = error.code || '';
      const message = error.message || '';
      if (code === 'auth/user-not-found' || message.includes('auth/user-not-found')) {
        setAuthError(language === 'ar' ? 'هذا البريد الإلكتروني غير مسجل لدينا.' : 'No user found with this email.');
      } else if (code === 'auth/invalid-email' || message.includes('auth/invalid-email')) {
        setAuthError(language === 'ar' ? 'البريد الإلكتروني غير صالح.' : 'Invalid email address.');
      } else {
        setAuthError(error.message);
      }
    } finally {
      setIsAuthActionLoading(false);
    }
  };

  const handleSendEmailVerification = async () => {
    if (!auth.currentUser) return;
    setAuthError(null);
    setAuthMessage(null);
    setIsAuthActionLoading(true);

    try {
      await sendEmailVerification(auth.currentUser);
      setAuthMessage(language === 'ar' 
        ? 'تم إرسال رابط التحقق إلى بريدك الإلكتروني. يرجى التحقق من صندوق الوارد.' 
        : 'Verification link sent to your email. Please check your inbox.');
    } catch (error: any) {
      console.warn('Email verification non-fatal info:', error);
      setAuthError(error.message);
    } finally {
      setIsAuthActionLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthMessage(null);
    
    const cleanEmail = emailAuthData.email.trim();
    if (!cleanEmail) {
      setAuthError(language === 'ar' ? 'يرجى إدخال البريد الإلكتروني.' : 'Please enter an email.');
      return;
    }

    if (emailMode !== 'reset' && emailAuthData.password.length < 6) {
      setAuthError(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.' : 'Password must be at least 6 characters.');
      return;
    }

    try {
      if (emailMode === 'signup') {
        const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, emailAuthData.password);
        if (emailAuthData.displayName) {
          await updateProfile(userCredential.user, { displayName: emailAuthData.displayName });
        }
        // Auto send verification email on signup
        await sendEmailVerification(userCredential.user);
        setAuthMessage(language === 'ar' 
          ? 'تم إنشاء الحساب بنجاح! يرجى التحقق من بريدك الإلكتروني لتفعيله.' 
          : 'Account created successfully! Please check your email to verify it.');
      } else if (emailMode === 'login') {
        await signInWithEmailAndPassword(auth, cleanEmail, emailAuthData.password);
      } else if (emailMode === 'reset') {
        await handlePasswordReset(e);
      }
    } catch (error: any) {
      console.warn('Email auth non-fatal info:', error);
      const code = error.code || '';
      const message = error.message || '';
      
      if (code === 'auth/operation-not-allowed' || message.includes('auth/operation-not-allowed')) {
        setAuthError(language === 'ar' 
          ? 'طريقة الدخول بواسطة البريد وكلمة المرور غير مفعّلة في Firebase. يرجى تفعيلها من لوحة التحكم.' 
          : 'Email/Password authentication is not enabled. Please enable it in the Firebase Console.');
      } else if (code === 'auth/email-already-in-use' || message.includes('auth/email-already-in-use')) {
        setAuthError(language === 'ar' 
          ? 'هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول بدلاً من ذلك.' 
          : 'This email is already in use. Please login instead.');
      } else if (code === 'auth/invalid-email' || message.includes('auth/invalid-email')) {
        setAuthError(language === 'ar' ? 'البريد الإلكتروني غير صالح.' : 'Invalid email address.');
      } else if (code === 'auth/weak-password' || message.includes('auth/weak-password')) {
        setAuthError(language === 'ar' ? 'كلمة المرور ضعيفة جداً.' : 'The password is too weak.');
      } else if (
        code === 'auth/user-not-found' || 
        code === 'auth/wrong-password' || 
        code === 'auth/invalid-credential' || 
        message.includes('auth/user-not-found') || 
        message.includes('auth/wrong-password') || 
        message.includes('auth/invalid-credential')
      ) {
        setAuthError(language === 'ar' ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Invalid email or password.');
      } else {
        setAuthError(error.message);
      }
    }
  };

  const handleUpdateDisplayName = async () => {
    if (!user || !newName.trim()) return;
    try {
      await updateProfile(user, { displayName: newName.trim() });
      setIsEditingName(false);
    } catch (error: any) {
      setAuthError(error.message);
    }
  };

  const handleUpdateLedgerId = async () => {
    if (!user || !newLedgerId.trim()) return;
    try {
      await setDoc(doc(db, `profiles/${user.uid}`), {
        ledgerId: newLedgerId.trim(),
        displayName: user.displayName || '',
        updatedAt: serverTimestamp()
      }, { merge: true });
      setIsEditingLedgerId(false);
    } catch (error: any) {
      setAuthError(error.message);
    }
  };

  const handleUpdateBudget = async () => {
    if (!user || isNaN(parseFloat(newBudget))) return;
    try {
      await setDoc(doc(db, `profiles/${user.uid}`), {
        monthlyBudget: parseFloat(newBudget),
        updatedAt: serverTimestamp()
      }, { merge: true });
      setIsEditingBudget(false);
    } catch (error: any) {
      setAuthError(error.message);
    }
  };

  const handleResetData = async () => {
    if (!user) return;
    try {
      const path = `users/${user.uid}/transactions`;
      const q = query(collection(db, path));
      // In a real app we'd use a batch delete, but for simplicity we'll delete what we have
      const promises = transactions.map(t => deleteDoc(doc(db, path, t.id)));
      await Promise.all(promises);
      setIsResetConfirmOpen(false);
      setIsAccountModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/transactions`);
    }
  };

  const handleUpdatePhotoURL = async () => {
    const url = prompt(language === 'ar' ? 'أدخل رابط الصورة الجديدة:' : 'Enter new image URL:');
    if (url && user) {
      try {
        await updateProfile(user, { photoURL: url });
        await setDoc(doc(db, `profiles/${user.uid}`), { photoURL: url, updatedAt: serverTimestamp() }, { merge: true });
        // Force refresh user data
        window.location.reload();
      } catch (error: any) {
        setAuthError(error.message);
      }
    }
  };

  const initiateCurrencyChange = (curr: 'YER' | 'SAR' | 'USD') => {
    if (curr === selectedCurrency) return;
    setPendingCurrency(curr);
    setIsCurrencyConfirmOpen(true);
  };

  const confirmCurrencyChange = async () => {
    if (!user || !pendingCurrency) return;
    try {
      await setDoc(doc(db, `profiles/${user.uid}`), {
        selectedCurrency: pendingCurrency,
        updatedAt: serverTimestamp()
      }, { merge: true });
      setSelectedCurrency(pendingCurrency);
      setIsCurrencyConfirmOpen(false);
      setPendingCurrency(null);
      setSettingsView('main');
    } catch (error) {
      console.error(error);
    }
  };

  const handleResetCurrencyData = async () => {
    if (!user) return;
    setIsResetLoading(true);
    try {
      const path = `users/${user.uid}/transactions`;
      const currencyTransactions = transactions.filter(t => (t as any).currencyId === selectedCurrency);
      
      const promises = currencyTransactions.map(t => deleteDoc(doc(db, path, t.id)));
      await Promise.all(promises);
      
      setIsResetConfirmOpen(false);
      setIsResetLoading(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/transactions`);
      setIsResetLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout failed', error);
    }
  };

  // Calculations
  const stats = useMemo(() => {
    const currencyTransactions = transactions.filter(t => (t as any).currencyId === selectedCurrency);
    
    const totalIncome = currencyTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalExpenses = currencyTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const currentBudget = budgets[selectedCurrency] || 0;
    
    return {
      totalIncome,
      totalExpenses,
      balance: totalIncome - totalExpenses,
      budget: currentBudget,
      remainingBudget: currentBudget - totalExpenses
    };
  }, [transactions, budgets, selectedCurrency]);

  const activeCategories = useMemo(() => {
    if (categories.length > 0) {
      return {
        income: categories.filter(c => c.type === 'income'),
        expense: categories.filter(c => c.type === 'expense')
      };
    }
    return DEFAULT_CATEGORIES;
  }, [categories]);

  const allCategoriesList = useMemo(() => {
    return categories.length > 0 ? categories : [...DEFAULT_CATEGORIES.income, ...DEFAULT_CATEGORIES.expense];
  }, [categories]);

  const filteredTransactions = useMemo(() => {
    return transactions
      .filter(t => {
        const matchesCurrency = (t as any).currencyId === selectedCurrency;
        const matchesSearch = 
          t.description.toLowerCase().includes(deferredSearchQuery.toLowerCase()) ||
          t.category.toLowerCase().includes(deferredSearchQuery.toLowerCase());
        return matchesCurrency && matchesSearch;
      })
      .sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue === undefined || bValue === undefined) return 0;

        if (sortConfig.key === 'date') {
          const aTime = new Date(aValue).getTime();
          const bTime = new Date(bValue).getTime();
          return sortConfig.direction === 'asc' ? aTime - bTime : bTime - aTime;
        }

        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return sortConfig.direction === 'asc' 
            ? aValue.localeCompare(bValue) 
            : bValue.localeCompare(aValue);
        }

        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return sortConfig.direction === 'asc' 
            ? aValue - bValue 
            : bValue - aValue;
        }

        return 0;
      });
  }, [transactions, deferredSearchQuery, sortConfig, selectedCurrency]);

  const paginatedTransactions = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredTransactions.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredTransactions, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);

  const [invoiceSortConfig, setInvoiceSortConfig] = useState<{ key: 'date' | 'total', direction: 'asc' | 'desc' }>({ key: 'date', direction: 'desc' });

  // Filtered and Sorted invoices
  const filteredInvoices = useMemo(() => {
    let result = invoices.filter(inv => inv.currencyId === selectedCurrency);
    
    result.sort((a, b) => {
      if (invoiceSortConfig.key === 'date') {
        const dateA = new Date(a.date).getTime();
        const dateB = new Date(b.date).getTime();
        return invoiceSortConfig.direction === 'asc' ? dateA - dateB : dateB - dateA;
      }
      if (invoiceSortConfig.key === 'total') {
        return invoiceSortConfig.direction === 'asc' ? a.total - b.total : b.total - a.total;
      }
      return 0;
    });

    return result;
  }, [invoices, selectedCurrency, invoiceSortConfig]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, sortConfig]);

  // Chart Data
  const chartData = useMemo(() => {
    const currencyTransactions = transactions.filter(t => (t as any).currencyId === selectedCurrency);
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      
      const dayTransactions = currencyTransactions.filter(t => t.date === dateStr);
      
      const dayIncome = dayTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const dayExpense = dayTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      
      return {
        name: format(date, 'EEE', { locale: language === 'ar' ? ar : undefined }),
        income: dayIncome,
        expenses: dayExpense,
        fullDate: dateStr,
        transactions: dayTransactions
      };
    }).reverse();
    
    return last7Days;
  }, [transactions, selectedCurrency, language]);

  const categoryData = useMemo(() => {
    const currencyTransactions = transactions.filter(t => (t as any).currencyId === selectedCurrency);
    const expenses = currencyTransactions.filter(t => t.type === 'expense');
    const grouped = expenses.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([id, value]) => {
      const cat = allCategoriesList.find(c => c.id === id);
      return {
        name: language === 'ar' ? (cat?.name || id) : (cat?.nameEn || id),
        value
      };
    });
  }, [transactions, selectedCurrency, allCategoriesList, language]);

  const reportData = useMemo(() => {
    let filteredTransactions = [];
    let periodLabelAr = '';
    let periodLabelEn = '';

    if (reportPeriod === 'daily') {
      filteredTransactions = transactions.filter(t => {
        const matchesDate = t.date === reportDailyDate;
        const matchesCurrency = (t as any).currencyId === selectedCurrency;
        return matchesDate && matchesCurrency;
      });
      try {
        periodLabelAr = format(new Date(reportDailyDate), 'dd MMMM yyyy', { locale: ar });
        periodLabelEn = format(new Date(reportDailyDate), 'dd MMMM yyyy');
      } catch (e) {
        periodLabelAr = reportDailyDate;
        periodLabelEn = reportDailyDate;
      }
    } else if (reportPeriod === 'weekly') {
      const refDate = new Date(reportWeeklyDate);
      const dayOfWeek = refDate.getDay(); // 0 (Sun) - 6 (Sat)
      const startOfWeekDate = new Date(refDate);
      startOfWeekDate.setDate(refDate.getDate() - dayOfWeek);
      startOfWeekDate.setHours(0, 0, 0, 0);

      const endOfWeekDate = new Date(startOfWeekDate);
      endOfWeekDate.setDate(startOfWeekDate.getDate() + 6);
      endOfWeekDate.setHours(23, 59, 59, 999);

      filteredTransactions = transactions.filter(t => {
        const tDate = new Date(t.date);
        tDate.setHours(12, 0, 0, 0); // avoid exact midnight shift
        const isInRange = tDate >= startOfWeekDate && tDate <= endOfWeekDate;
        const matchesCurrency = (t as any).currencyId === selectedCurrency;
        return isInRange && matchesCurrency;
      });

      try {
        const startLabelAr = format(startOfWeekDate, 'dd MMM', { locale: ar });
        const endLabelAr = format(endOfWeekDate, 'dd MMM yyyy', { locale: ar });
        const startLabelEn = format(startOfWeekDate, 'dd MMM');
        const endLabelEn = format(endOfWeekDate, 'dd MMM yyyy');
        periodLabelAr = `الأسبوع من ${startLabelAr} إلى ${endLabelAr}`;
        periodLabelEn = `Week of ${startLabelEn} to ${endLabelEn}`;
      } catch (e) {
        periodLabelAr = `الأسبوع من ${reportWeeklyDate}`;
        periodLabelEn = `Week of ${reportWeeklyDate}`;
      }
    } else { // monthly
      const [year, month] = reportDate.split('-');
      const yNum = parseInt(year) || new Date().getFullYear();
      const mNum = parseInt(month) || (new Date().getMonth() + 1);
      
      filteredTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        const matchesDate = date.getFullYear() === yNum && (date.getMonth() + 1) === mNum;
        const matchesCurrency = (t as any).currencyId === selectedCurrency;
        return matchesDate && matchesCurrency;
      });

      try {
        periodLabelAr = format(new Date(yNum, mNum - 1), 'MMMM yyyy', { locale: ar });
        periodLabelEn = format(new Date(yNum, mNum - 1), 'MMMM yyyy');
      } catch (e) {
        periodLabelAr = reportDate;
        periodLabelEn = reportDate;
      }
    }

    const income = filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const expenses = filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    const expensesByCategory = filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>);

    const categoryBreakdown = activeCategories.expense.map(cat => {
      const total = expensesByCategory[cat.id] || 0;
      return {
        ...cat,
        total,
        percentage: expenses > 0 ? (total / expenses) * 100 : 0,
        color: CATEGORY_COLORS[cat.id] || cat.color || '#64748B'
      };
    }).filter(c => c.total > 0).sort((a, b) => b.total - a.total);

    // Financial Insights Generation Engine
    const generateInsights = () => {
      const result: {
        titleAr: string;
        titleEn: string;
        descAr: string;
        descEn: string;
        type: 'success' | 'warning' | 'info' | 'neutral';
      }[] = [];

      // 1. Savings Rate and Position
      const net = income - expenses;
      if (income > 0) {
        const savingsRate = (net / income) * 100;
        if (savingsRate >= 30) {
          result.push({
            titleAr: 'معدل ادخار متميز',
            titleEn: 'Excellent Savings Rate',
            descAr: `لقد قمت بادخار ${savingsRate.toFixed(1)}% من إجمالي ميزانيتك لهذه الفترة. هذا السلوك المالي ممتاز جداً ويبني لك احتياطياً نقدياً قوياً لمشاريعك المستقبلية.`,
            descEn: `You saved ${savingsRate.toFixed(1)}% of your budget. This exceptional tracking behavior consolidates a strong emergency buffer for your future goals.`,
            type: 'success'
          });
        } else if (savingsRate >= 10 && savingsRate < 30) {
          result.push({
            titleAr: 'هامش ادخار صحي',
            titleEn: 'Healthy Savings Buffer',
            descAr: `معدل ادخارك الحالي هو ${savingsRate.toFixed(1)}%. يتماشى هذا مع القواعد المالية الذهبية (10% إلى 30%). استمر في الانضباط لتأمين خططك.`,
            descEn: `Your current savings rate is ${savingsRate.toFixed(1)}%. This perfectly complies with key standard rules (10% to 30%). Maintain this pace.`,
            type: 'info'
          });
        } else if (savingsRate >= 0 && savingsRate < 10) {
          result.push({
            titleAr: 'فرصة لتحسين هامش الادخار',
            titleEn: 'Opportunities for Better Savings',
            descAr: `نسبة ادخارك منخفضة بعض الشيء وتقارب ${savingsRate.toFixed(1)}%. نقترح عليك ترشيد نفقات الكماليات لرفع هذا المعدل للحد الآمن (15% على الأقل).`,
            descEn: `Your savings rate is slightly low at ${savingsRate.toFixed(1)}%. Try trimming non-essential outflows to build up a more resilient cushion.`,
            type: 'warning'
          });
        } else {
          result.push({
            titleAr: 'تحذير مالي: صافي عجز نقدي',
            titleEn: 'Financial Deficit warning',
            descAr: `تجاوزت المصاريف إيراداتك بمقدار (${formatCurrencyBase(Math.abs(net), selectedCurrency, language)}). ننصحك بتفعيل خطة ترشيد طارئة والحد من المصاريف غير الضرورية لاستعادة التوازن.`,
            descEn: `Disbursements exceeded income by (${formatCurrencyBase(Math.abs(net), selectedCurrency, language)}). We recommend adopting an urgent capping mechanism immediately.`,
            type: 'warning'
          });
        }
      } else if (expenses > 0) {
        result.push({
          titleAr: 'نفقات مرصودة دون إيرادات',
          titleEn: 'Expenses Logged with Zero Income',
          descAr: `لقد سجلت نفقات بقيمة ${formatCurrencyBase(expenses, selectedCurrency, language)} دون تدوين أي إيرادات. نوصي بتسجيل جميع مصادر الدخل أولاً بأول للحيازة على رؤية متوازنة وكاملة.`,
          descEn: `You logged expenses of ${formatCurrencyBase(expenses, selectedCurrency, language)} without any incoming resources. Map your revenue streams regularly for balanced analysis.`,
          type: 'warning'
        });
      }

      // 2. Classifications Breakdown
      if (categoryBreakdown.length > 0) {
        const top = categoryBreakdown[0];
        const pct = expenses > 0 ? (top.total / expenses) * 100 : 0;
        if (pct >= 40) {
          result.push({
            titleAr: `تركيز نفقات مرتفع في: ${language === 'ar' ? top.name : top.nameEn}`,
            titleEn: `High Expense Concentration: ${language === 'ar' ? top.name : top.nameEn}`,
            descAr: `تستحوذ فئة "${language === 'ar' ? top.name : top.nameEn}" على ${pct.toFixed(0)}% من مجمل إنفاقك المالي في هذه المدة. ضع سقفاً محدداً لهذه الفئة للتحكم الأفضل برأس المال.`,
            descEn: `The "${language === 'ar' ? top.name : top.nameEn}" category takes up ${pct.toFixed(0)}% of your overall spend. Setting a targeted limit will grant greater capital control.`,
            type: 'info'
          });
        } else {
          result.push({
            titleAr: `الفئة الأكثر استهلاكاً للسيولة`,
            titleEn: `Top Capital-Consuming Category`,
            descAr: `القسم الأكثر استهلاكاً للميزانية هو "${language === 'ar' ? top.name : top.nameEn}" بإجمالي يبلغ ${formatCurrencyBase(top.total, selectedCurrency, language)} ما يعادل ${pct.toFixed(0)}% من المصاريف.`,
            descEn: `The leading spend factor was "${language === 'ar' ? top.name : top.nameEn}" totaling ${formatCurrencyBase(top.total, selectedCurrency, language)} (${pct.toFixed(0)}% of total cost).`,
            type: 'neutral'
          });
        }
      }

      // 3. Transactions Spike Review
      if (filteredTransactions.length > 0) {
        const expenseTrans = filteredTransactions.filter(t => t.type === 'expense');
        if (expenseTrans.length > 0) {
          const maxExpense = expenseTrans.reduce((max, t) => t.amount > max.amount ? t : max, expenseTrans[0]);
          if (maxExpense.amount > expenses * 0.4 && expenses > 0) {
            result.push({
              titleAr: 'طفرة دفع مفردة كبيرة',
              titleEn: 'Significant Single Expense Spike',
              descAr: `هناك عملية فردية كبيرة وهي "${maxExpense.description || (language === 'ar' ? 'مصروف عام' : 'Disbursement')}" بقيمة ${formatCurrencyBase(maxExpense.amount, selectedCurrency, language)}، والتي استهلكت أكثر من 40% من المصروفات. يرجى درس تكرارها لتجنب الصدمات النقدية.`,
              descEn: `A single process ("${maxExpense.description || 'Disbursement'}") of ${formatCurrencyBase(maxExpense.amount, selectedCurrency, language)} represented over 40% of all expenses. Evaluate its frequency to avoid liquidity shocks.`,
              type: 'neutral'
            });
          }
        }
      }

      // Default
      if (result.length === 0) {
        result.push({
          titleAr: 'لا توجد أنشطة كافية لاستخلاص أنماط مخصصة',
          titleEn: 'Insufficient Data for Patterns',
          descAr: 'سجّل المزيد من الحركات المصرفية لتفعيل خوارزمية الأنماط والرؤى الذكية المتقدمة.',
          descEn: 'Log additional financial entries to activate the automatic pattern-recognition analytics.',
          type: 'neutral'
        });
      }

      return result;
    };

    return {
      income,
      expenses,
      balance: income - expenses,
      categoryBreakdown,
      periodLabelAr,
      periodLabelEn,
      filteredTransactions: filteredTransactions.sort((a, b) => b.date.localeCompare(a.date)),
      insights: generateInsights()
    };
  }, [transactions, reportPeriod, reportDailyDate, reportWeeklyDate, reportDate, selectedCurrency, activeCategories, language]);

  const handleAddInvoice = async (invoiceData: Partial<Invoice>) => {
    if (!user) return;
    const path = `users/${user.uid}/invoices`;
    const invoiceId = crypto.randomUUID();
    
    // Ensure numeric fields are correctly set
    const total = invoiceData.items?.reduce((sum, item) => sum + item.total, 0) || 0;
    
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber: invoiceData.invoiceNumber || `INV-${Date.now()}`,
      items: (invoiceData.items || []) as InvoiceItem[],
      subtotal: total,
      tax: 0,
      total: total,
      date: invoiceData.date || format(new Date(), 'yyyy-MM-dd'),
      currencyId: (invoiceData.currencyId as any) || selectedCurrency,
      customerName: invoiceData.customerName || '',
      shopName: invoiceData.shopName || '',
      customerAddress: invoiceData.customerAddress || '',
      paymentTerms: invoiceData.paymentTerms || '',
      notes: invoiceData.notes || '',
      userId: user.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      attachment: invoiceData.attachment || undefined,
    };

    try {
      await setDoc(doc(db, path, invoiceId), newInvoice);
      setIsInvoiceModalOpen(false);
      setInvoiceFormData({
        items: [],
        date: format(new Date(), 'yyyy-MM-dd'),
        currencyId: selectedCurrency,
        invoiceNumber: '',
        customerName: '',
        shopName: '',
        customerAddress: '',
        paymentTerms: '',
        notes: '',
        attachment: undefined,
      });
      sendNotification('تم إضافة الفاتورة', `تم تسجيل فاتورة جديدة برقم ${newInvoice.invoiceNumber}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const handleDeleteInvoice = async (id: string) => {
    if (!user) return;
    const path = `users/${user.uid}/invoices`;
    try {
      await deleteDoc(doc(db, path, id));
      sendNotification(language === 'ar' ? 'تم حذف الفاتورة' : 'Invoice Deleted', language === 'ar' ? 'تم إزالة الفاتورة بنجاح' : 'Invoice removed successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const path = `users/${user.uid}/categories`;
    const catId = editingCategory?.id || crypto.randomUUID();
    
    const catData = {
      ...categoryFormData,
      nameEn: categoryFormData.nameEn?.trim() || categoryFormData.name?.trim() || '',
      id: catId,
      userId: user.uid,
      updatedAt: serverTimestamp(),
      ...(editingCategory ? {} : { createdAt: serverTimestamp() })
    };

    try {
      await setDoc(doc(db, path, catId), catData, { merge: true });
      setIsCategoryModalOpen(false);
      setEditingCategory(null);
      setCategoryFormData({ name: '', nameEn: '', icon: 'Tag', color: 'bg-emerald-500', type: 'expense' });
      sendNotification(
        language === 'ar' 
          ? (editingCategory ? 'تم تحديث الفئة' : 'تم إضافة الفئة') 
          : (editingCategory ? 'Category Updated' : 'Category Added'), 
        language === 'ar' ? 'تم حفظ التعديلات بنجاح' : 'Changes saved successfully'
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!user) return;
    if (!window.confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذه الفئة؟' : 'Are you sure you want to delete this category?')) return;
    const path = `users/${user.uid}/categories`;
    try {
      await deleteDoc(doc(db, path, id));
      sendNotification(language === 'ar' ? 'تم حذف الفئة' : 'Category Deleted', language === 'ar' ? 'تم إزالة الفئة بنجاح' : 'Category removed successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const onSubmitTransaction = async (data: any) => {
    if (!user) return;
    const transactionId = crypto.randomUUID();
    const path = `users/${user.uid}/transactions`;
    
    const newTransaction: Transaction = {
      id: transactionId,
      ...data,
      amount: parseFloat(data.amount),
      currencyId: selectedCurrency,
      userId: user.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    try {
      await setDoc(doc(db, path, transactionId), newTransaction);
      setIsModalOpen(false);
      
      // Trigger notification
      const typeLabel = newTransaction.type === 'income' ? 'إيداع' : 'صرف';
      sendNotification('تم تسجيل عملية جديدة', `${typeLabel}: ${formatCurrency(newTransaction.amount)} - ${newTransaction.description || 'بدون وصف'}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const deleteTransaction = (id: string) => {
    setTransactionToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const exportInvoiceToPDF = async (invoice: Invoice) => {
    const invoiceId = invoice.id || 'PREVIEW';
    const templateId = `invoice-template-${invoiceId}`;
    
    sendNotification(
      language === 'ar' ? 'جاري تنظيم الفاتورة بالذكاء الاصطناعي...' : 'AI is organizing the invoice...', 
      language === 'ar' ? 'يرجى الانتظار قليلاً جاري تنظيم البيانات وترتيب البنود وتنسيق النص...' : 'Please wait, AI is structuring items and formatting the text...'
    );

    let finalInvoice = { ...invoice };
    try {
      const response = await fetch('/api/ai/organize-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoice, language }),
      });

      if (response.ok) {
        const aiData = await response.json();
        
        // Map items back and generate unique IDs for any items extracted
        const mappedItems = (aiData.items || []).map((it: any) => ({
          ...it,
          id: it.id || Math.random().toString(36).substr(2, 9)
        }));

        const subtotal = mappedItems.reduce((sum: number, it: any) => sum + (it.total || 0), 0);
        const total = subtotal;

        finalInvoice = {
          ...invoice,
          items: mappedItems,
          notes: aiData.notes || invoice.notes || '',
          customerName: aiData.customerName || invoice.customerName || '',
          shopName: aiData.shopName || invoice.shopName || '',
          customerAddress: aiData.customerAddress || invoice.customerAddress || '',
          paymentTerms: aiData.paymentTerms || invoice.paymentTerms || '',
          subtotal,
          total
        };

        // Update active creation form if current invoice is 'PREVIEW'
        if (invoiceId === 'PREVIEW') {
          setInvoiceFormData(prev => ({
            ...prev,
            items: mappedItems,
            notes: aiData.notes || prev.notes,
            customerName: aiData.customerName || prev.customerName,
            shopName: aiData.shopName || prev.shopName,
            customerAddress: aiData.customerAddress || prev.customerAddress,
            paymentTerms: aiData.paymentTerms || prev.paymentTerms
          }));
        } else {
          // If exporting an existing invoice, update local state
          setInvoices(prev => prev.map(inv => inv.id === invoiceId ? finalInvoice : inv));
          // Save the changes to Firebase Firestore so they are permanent
          if (user?.uid) {
            const path = `users/${user.uid}/invoices`;
            await setDoc(doc(db, path, invoiceId), {
              items: finalInvoice.items,
              notes: finalInvoice.notes,
              customerName: finalInvoice.customerName || '',
              shopName: finalInvoice.shopName || '',
              customerAddress: finalInvoice.customerAddress || '',
              paymentTerms: finalInvoice.paymentTerms || '',
              subtotal: finalInvoice.subtotal,
              total: finalInvoice.total,
              updatedAt: serverTimestamp()
            }, { merge: true });
          }
        }

        sendNotification(
          language === 'ar' ? 'اكتمل تنظيم البيانات بالذكاء الاصطناعي!' : 'AI Organization complete!',
          language === 'ar' ? 'جاري الآن توليد وتنزيل ملف PDF للطباعة الاحترافية...' : 'Preparing the final layout for PDF export...'
        );

        // Give React a short window to flush the state update to the DOM
        await new Promise(resolve => setTimeout(resolve, 800));
      }
    } catch (err) {
      console.warn("AI organization failed, proceeding with original data:", err);
    }

    const templateElement = document.getElementById(templateId);
    if (!templateElement) {
      console.error("Template element not found:", templateId);
      sendNotification(
        language === 'ar' ? 'خطأ في التصدير' : 'Export Error',
        language === 'ar' ? 'لم يتم العثور على قالب الفاتورة' : 'Invoice template not found'
      );
      return;
    }
    
    try {
      // Get the current scroll position to restore it later
      const scrollPos = window.scrollY;
      
      const originalStyle = templateElement.getAttribute('style') || '';
      const originalClassName = templateElement.className;
      
      // Temporarily remove hiding classes and styles (render off-screen so the user doesn't see it open or flashing)
      templateElement.style.display = 'block';
      templateElement.style.visibility = 'visible';
      templateElement.style.opacity = '1';
      templateElement.style.position = 'fixed';
      templateElement.style.left = '-9999px';
      templateElement.style.top = '-9999px';
      templateElement.style.zIndex = '-9999';
      templateElement.classList.remove('invisible', 'opacity-0');
      
      // Increased delay to ensure font rendering and layout calculations are complete
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const canvas = await safeHtml2canvas(templateElement, {
        scale: 3, // Higher scale for better quality
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f8f7f2',
        width: 210 * 3.78, // a4 width in px approx (1mm = 3.78px)
        height: 297 * 3.78, // a4 height in px
        logging: false,
        onclone: (clonedDoc) => {
          const el = clonedDoc.getElementById(templateId);
          if (el) {
            el.style.display = 'block';
            el.style.visibility = 'visible';
            el.style.opacity = '1';
          }
          cleanHtml2canvasStyles(clonedDoc);
        }
      });
      
      const dataUrl = canvas.toDataURL('image/png', 1.0);
      
      // Restore original state
      templateElement.setAttribute('style', originalStyle);
      templateElement.className = originalClassName;
      window.scrollTo(0, scrollPos);

      if (!dataUrl || dataUrl.length < 1000) {
        throw new Error("Generated image is empty or too small");
      }
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(dataUrl);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, Math.min(pdfHeight, 297));
      const safeInvoiceNumber = (finalInvoice.invoiceNumber || 'sales').replace(/[^a-z0-9]/gi, '_').toLowerCase();
      pdf.save(`invoice-${safeInvoiceNumber}.pdf`);
      
      sendNotification(
        language === 'ar' ? 'تم تصدير PDF بنجاح' : 'PDF Exported Successfully', 
        language === 'ar' ? 'تم حفظ الفاتورة بعد تنظيفها وترتيبها بالذكاء الاصطناعي' : 'Invoice organized by AI and saved successfully as PDF'
      );
    } catch (error) {
      console.error("Error creating PDF:", error);
      sendNotification(
        language === 'ar' ? 'فشل التصدير' : 'Export Failed',
        language === 'ar' ? 'حدث خطأ أثناء إنشاء ملف PDF. يرجى المحاولة مرة أخرى.' : 'An error occurred while generating the PDF. Please try again.'
      );
    }
  };

  const exportFinancialReportToPDF = async () => {
    const templateId = 'financial-report-template';
    const templateElement = document.getElementById(templateId);
    
    if (!templateElement) {
      console.error("Template element not found:", templateId);
      sendNotification(
        language === 'ar' ? 'خطأ في التصدير' : 'Export Error',
        language === 'ar' ? 'لم يتم العثور على قالب التقرير المالي' : 'Report template not found'
      );
      return;
    }
    
    sendNotification(
      language === 'ar' ? 'جاري التحضير...' : 'Preparing...', 
      language === 'ar' ? 'يرجى الانتظار قليلاً جاري إنشاء ملف PDF للتقرير المالي' : 'Please wait, generating financial report PDF file'
    );
    
    try {
      // Get current scroll position to restore later
      const scrollPos = window.scrollY;
      
      const originalStyle = templateElement.getAttribute('style') || '';
      const originalClassName = templateElement.className;
      
      // Force visibility for capture (render off-screen so the user doesn't see it open or flashing)
      templateElement.style.display = 'block';
      templateElement.style.visibility = 'visible';
      templateElement.style.opacity = '1';
      templateElement.style.position = 'fixed';
      templateElement.style.left = '-9999px';
      templateElement.style.top = '-9999px';
      templateElement.style.zIndex = '-9999';
      templateElement.classList.remove('invisible', 'opacity-0');
      
      // Allow fonts and charts to settle
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const canvas = await safeHtml2canvas(templateElement, {
        scale: 3,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f8f7f2',
        width: 210 * 3.78, // Approximately 793px
        height: 297 * 3.78, // Approximately 1122px
        logging: false,
        onclone: (clonedDoc) => {
          const el = clonedDoc.getElementById(templateId);
          if (el) {
            el.style.display = 'block';
            el.style.visibility = 'visible';
            el.style.opacity = '1';
          }
          cleanHtml2canvasStyles(clonedDoc);
        }
      });
      
      const dataUrl = canvas.toDataURL('image/png', 1.0);
      
      // Restore original element styles
      templateElement.setAttribute('style', originalStyle);
      templateElement.className = originalClassName;
      window.scrollTo(0, scrollPos);

      if (!dataUrl || dataUrl.length < 1000) {
        throw new Error("Generated image is empty or too small");
      }
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(dataUrl);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, Math.min(pdfHeight, 297));
      const periodName = reportPeriod.toLowerCase();
      pdf.save(`financial-report-${periodName}-${new Date().toISOString().split('T')[0]}.pdf`);
      
      sendNotification(
        language === 'ar' ? 'تم تصدير التقرير بنجاح' : 'Report Exported Successfully', 
        language === 'ar' ? 'تم حفظ التقرير المالي بصيغة PDF بنجاح' : 'Financial report successfully saved as PDF'
      );
    } catch (error) {
      console.error("Error creating PDF:", error);
      sendNotification(
        language === 'ar' ? 'فشل التصدير' : 'Export Failed',
        language === 'ar' ? 'حدث خطأ أثناء إنشاء ملف PDF للتقرير. يرجى المحاولة مرة أخرى.' : 'An error occurred while generating the report PDF. Please try again.'
      );
    }
  };

  const PaperInvoiceTemplate = ({ invoice }: { invoice: Invoice }) => {
    const items = invoice.items || [];
    const invoiceId = invoice.id || 'PREVIEW';

    return (
      <div 
        id={`invoice-template-${invoiceId}`}
        className="fixed left-[-9999px] top-0 bg-[#f8f7f2] w-[210mm] min-h-[297mm] p-[15mm] text-black font-sans leading-relaxed pointer-events-none opacity-1"
        style={{ display: 'none' }}
        dir="rtl"
      >
        {/* Header Section */}
        <div className="text-center mb-10 space-y-2">
          <h1 className="text-4xl font-black text-[#0f172a] tracking-tight">فاتورة مبيعات</h1>
          <p className="text-xl font-bold text-[#475569]">محفظتي الرقمية</p>
          <div className="flex justify-center items-center gap-2 mt-4">
            <div className="w-24 h-[1px] bg-[#94a3b8]"></div>
            <span className="text-lg font-bold px-4">{new Date().getFullYear()}</span>
            <div className="w-24 h-[1px] bg-[#94a3b8]"></div>
          </div>
        </div>

        {/* Info Rows */}
        <div className="flex flex-col items-start gap-3 mb-10 text-[15px] w-full text-right" dir="rtl">
          <div className="flex items-center gap-4 justify-start w-full">
            <span className="font-bold min-w-[100px] text-right">التاريخ:</span>
            <div className="min-w-[200px] border-b border-[#cbd5e1] text-right pb-1 font-mono">{invoice.date}</div>
          </div>
          <div className="flex items-center gap-4 justify-start w-full">
            <span className="font-bold min-w-[100px] text-right">رقم الفاتورة:</span>
            <div className="min-w-[200px] border-b border-[#cbd5e1] text-right pb-1 font-mono">{invoice.invoiceNumber}</div>
          </div>
          <div className="flex items-center gap-4 justify-start w-full">
            <span className="font-bold min-w-[100px] text-right">اسم المحل:</span>
            <div className="min-w-[200px] border-b border-[#cbd5e1] text-right pb-1 font-sans">{invoice.shopName || '................................'}</div>
          </div>
        </div>

        {/* Main Table */}
        <div className="border border-[#444444] overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-[#e2e8f0] text-[14px] font-black border-b border-[#444444]">
                <th className="border-l border-[#444444] p-2 w-[15%]">الإجمالي</th>
                <th className="border-l border-[#444444] p-2 w-[15%]">سعر الوحدة</th>
                <th className="border-l border-[#444444] p-2 w-[12%]">الكمية</th>
                <th className="border-l border-[#444444] p-2 text-right px-4">وصف المنتج / الخدمة</th>
                <th className="p-2 w-[8%]">م</th>
              </tr>
            </thead>
            <tbody className="text-[13px] font-medium">
              {items.map((item, idx) => (
                <tr key={idx} className="border-b border-[#cbd5e1] h-10">
                  <td className="border-l border-[#cbd5e1] p-2 text-center font-mono">{formatCurrency(item.total || 0, invoice.currencyId)}</td>
                  <td className="border-l border-[#cbd5e1] p-2 text-center font-mono">{formatCurrency(item.price || 0, invoice.currencyId)}</td>
                  <td className="border-l border-[#cbd5e1] p-2 text-center font-mono">{item.quantity}</td>
                  <td className="border-l border-[#cbd5e1] p-2 text-right px-4 font-bold">{item.name}</td>
                  <td className="p-2 text-center font-bold">{idx + 1}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer Area */}
        <div className="mt-8 space-y-6">
          <div className="flex items-center justify-end gap-6">
            <div className="border-b-2 border-[#0f172a] min-w-[150px] pb-1 text-center font-black text-xl italic font-mono">
               {formatCurrency(invoice.total || 0, invoice.currencyId)}
            </div>
            <span className="text-xl font-black">إجمالي المبلغ المستحق:</span>
          </div>

          <div className="space-y-4">
            <span className="text-lg font-bold block">ملاحظات:</span>
            <div className="border border-[#cbd5e1] rounded-lg w-full p-4 text-sm text-[#334155] leading-relaxed min-h-[100px] text-right whitespace-pre-wrap">
               {invoice.notes || '................................................................................................................'}
            </div>
          </div>
        </div>

        <div className="mt-10 text-center text-sm font-bold opacity-40 uppercase tracking-[0.2em]">
          هذه الفاتورة تم إصدارها عبر تطبيق "محفظتي الرقمية" | {invoice.currencyId}
        </div>
      </div>
    );
  };

  const PaperReportTemplate = () => {
    const { income, expenses, balance, categoryBreakdown, periodLabelAr, periodLabelEn, filteredTransactions, insights } = reportData;
    const savingsRate = income > 0 ? ((income - expenses) / income) * 100 : 0;

    return (
      <div 
        id="financial-report-template"
        className="fixed left-[-9999px] top-0 bg-[#f8f7f2] w-[210mm] min-h-[297mm] p-[15mm] text-black font-sans leading-relaxed pointer-events-none opacity-1 animate-none"
        style={{ display: 'none' }}
        dir={language === 'ar' ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="text-center mb-8 border-b-2 border-[#0f172a] pb-6 space-y-2">
          <h1 className="text-4xl font-black text-[#0f172a] tracking-tight">
            {language === 'ar' ? 'التقرير المالي الذكي' : 'Intelligent Financial Report'}
          </h1>
          <p className="text-lg font-bold text-[#475569]">
            {language === 'ar' ? 'محفظتي الرقمية - نظام التحليل المالي والأنماط' : 'Digital Wallet - Pattern Analysis & Reporting Service'}
          </p>
          <div className="flex justify-center items-center gap-2 mt-2">
            <div className="w-16 h-[1px] bg-[#94a3b8]"></div>
            <span className="text-xs font-mono font-bold bg-[#0f172a]/10 text-[#0f172a] px-3 py-1 rounded-full uppercase tracking-widest">
              {reportPeriod === 'daily' ? (language === 'ar' ? 'يومي' : 'DAILY') : reportPeriod === 'weekly' ? (language === 'ar' ? 'أسبوعي' : 'WEEKLY') : (language === 'ar' ? 'شهري' : 'MONTHLY')}
            </span>
            <div className="w-16 h-[1px] bg-[#94a3b8]"></div>
          </div>
        </div>

        {/* Period Details & Metadata */}
        <div className="grid grid-cols-2 gap-4 mb-8 text-[13px] border border-[#cbd5e1] p-4 bg-slate-100/40 rounded-xl">
          <div className="space-y-1">
            <p className="opacity-60">{language === 'ar' ? 'البريد الإلكتروني للعميل:' : 'Account Email:'}</p>
            <p className="font-bold">{user?.email || 'Guest User'}</p>
          </div>
          <div className="space-y-1 text-right">
            <p className="opacity-60">{language === 'ar' ? 'المجال المالي المشمول:' : 'Report Duration:'}</p>
            <p className="font-bold text-[#0f172a]">{language === 'ar' ? periodLabelAr : periodLabelEn}</p>
          </div>
          <div className="space-y-1">
            <p className="opacity-60">{language === 'ar' ? 'العملة الأساسية:' : 'Base Currency:'}</p>
            <p className="font-bold font-mono">{selectedCurrency}</p>
          </div>
          <div className="space-y-1 text-right">
            <p className="opacity-60">{language === 'ar' ? 'تاريخ الاستخراج:' : 'Exported On:'}</p>
            <p className="font-mono">{format(new Date(), 'yyyy-MM-dd HH:mm')}</p>
          </div>
        </div>

        {/* Financial Summary KPIs */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="border border-[#cbd5e1] p-4 bg-emerald-50 text-right rounded-xl">
            <p className="text-[10px] uppercase font-black tracking-wider text-emerald-700">{language === 'ar' ? 'إجمالي الإيداعات' : 'Total Income'}</p>
            <p className="text-xl font-bold font-mono text-emerald-600 mt-1 tabular-nums">{formatCurrency(income)}</p>
          </div>
          <div className="border border-[#cbd5e1] p-4 bg-rose-50 text-right rounded-xl">
            <p className="text-[10px] uppercase font-black tracking-wider text-rose-700">{language === 'ar' ? 'إجمالي المصاريف' : 'Total Expenses'}</p>
            <p className="text-xl font-bold font-mono text-rose-600 mt-1 tabular-nums">{formatCurrency(expenses)}</p>
          </div>
          <div className="border border-[#cbd5e1] p-4 bg-slate-50 text-right rounded-xl">
            <p className="text-[10px] uppercase font-black tracking-wider text-slate-700">{language === 'ar' ? 'صافي المتبقي' : 'Net Surplus'}</p>
            <p className={`text-xl font-bold font-mono mt-1 tabular-nums ${balance >= 0 ? 'text-slate-800' : 'text-red-700'}`}>
              {formatCurrency(balance)}
            </p>
          </div>
          <div className="border border-[#cbd5e1] p-4 bg-blue-50 text-right rounded-xl">
            <p className="text-[10px] uppercase font-black tracking-wider text-blue-700">{language === 'ar' ? 'معدل الادخار' : 'Savings Rate'}</p>
            <p className="text-xl font-bold font-mono text-blue-600 mt-1 tabular-nums">{income > 0 ? `${savingsRate.toFixed(1)}%` : '0%'}</p>
          </div>
        </div>

        {/* Insights & Patterns Block Section */}
        <div className="mb-8">
          <h3 className="text-lg font-bold border-b border-[#cbd5e1] pb-2 mb-4">
            {language === 'ar' ? 'التحليلات والرؤى المالية' : 'Financial Intelligence & Spending Patterns'}
          </h3>
          <div className="space-y-3">
            {insights.map((insight: any, index: number) => {
              const bgClass = insight.type === 'success' 
                ? 'bg-emerald-50/50 border-emerald-200 text-emerald-900' 
                : insight.type === 'warning'
                ? 'bg-rose-50/50 border-rose-200 text-rose-900'
                : insight.type === 'info'
                ? 'bg-blue-50/50 border-blue-200 text-blue-900'
                : 'bg-slate-50 border-slate-200 text-slate-900';
              return (
                <div key={index} className={`p-4 border rounded-xl text-xs leading-relaxed ${bgClass}`}>
                  <p className="font-bold mb-1 text-[13px]">{language === 'ar' ? insight.titleAr : insight.titleEn}</p>
                  <p className="opacity-80">{language === 'ar' ? insight.descAr : insight.descEn}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Expenditure Breakdowns */}
        {expenses > 0 && (
          <div className="mb-8">
            <h3 className="text-lg font-bold border-b border-[#cbd5e1] pb-2 mb-4">
              {language === 'ar' ? 'توزيع المصاريف على الفئات' : 'Expense Category Allocation'}
            </h3>
            <div className="border border-[#cbd5e1] rounded-xl overflow-hidden">
              <table className="w-full text-right text-xs border-collapse font-sans text-black">
                <thead>
                  <tr className="bg-slate-100 font-bold border-b border-[#cbd5e1]">
                    <th className="p-3 w-[15%] text-center">{language === 'ar' ? 'النسبة' : 'Percentage'}</th>
                    <th className="p-3 w-[25%] text-center">{language === 'ar' ? 'المبلغ الإجمالي' : 'Total Spent'}</th>
                    <th className="p-3">{language === 'ar' ? 'التصنيف الفئوي' : 'Category'}</th>
                  </tr>
                </thead>
                <tbody>
                  {categoryBreakdown.map((cat: any) => (
                    <tr key={cat.id} className="border-b border-[#cbd5e1] hover:bg-[#fafaf9]">
                      <td className="p-3 text-center font-mono font-bold">{(cat.percentage || 0).toFixed(1)}%</td>
                      <td className="p-3 text-center font-mono font-bold">{formatCurrency(cat.total)}</td>
                      <td className="p-3 font-bold flex items-center justify-start gap-2">
                        <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: CATEGORY_COLORS[cat.id] || '#64748B' }}></span>
                        <span>{language === 'ar' ? cat.name : cat.nameEn}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Detailed Transactions Section */}
        <div className="mb-6">
          <h3 className="text-lg font-bold border-b border-[#cbd5e1] pb-2 mb-4">
            {language === 'ar' ? 'تفاصيل العمليات المصرفية الأخيرة' : 'Activity Audit & Transactions Log'}
          </h3>
          {filteredTransactions.length === 0 ? (
            <div className="p-6 text-center border-2 border-dashed border-[#cbd5e1] rounded-xl text-xs opacity-60">
              {language === 'ar' ? 'لا توجد حركات مصرفية مسجلة لهذه المدة.' : 'No transactions recorded for this interval.'}
            </div>
          ) : (
            <div className="border border-[#cbd5e1] rounded-xl overflow-hidden">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-100 font-bold border-b border-[#cbd5e1]">
                    <th className="p-3 w-[18%] text-center">{language === 'ar' ? 'القيمة' : 'Amount'}</th>
                    <th className="p-3 w-[15%] text-center">{language === 'ar' ? 'النوع' : 'Type'}</th>
                    <th className="p-3 w-[25%]">{language === 'ar' ? 'الوصف' : 'Description'}</th>
                    <th className="p-3 w-[22%] text-center">{language === 'ar' ? 'التصنيف' : 'Category'}</th>
                    <th className="p-3 w-[20%] text-center">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.slice(0, 10).map((t: any) => {
                    const foundCat = activeCategories[t.type as 'income' | 'expense']?.find((c: any) => c.id === t.category);
                    const catLabel = foundCat 
                      ? (language === 'ar' ? foundCat.name : foundCat.nameEn)
                      : t.category;
                    return (
                      <tr key={t.id} className="border-b border-[#cbd5e1] hover:bg-[#fafaf9]">
                        <td className={`p-3 text-center font-mono font-bold tabular-nums ${t.type === 'income' ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {t.type === 'income' ? '+' : '-'} {formatCurrency(t.amount)}
                        </td>
                        <td className="p-3 text-center font-bold">
                          <span className={`px-2 py-0.5 rounded text-[10px] ${t.type === 'income' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'}`}>
                            {t.type === 'income' ? (language === 'ar' ? 'إيداع' : 'INCOME') : (language === 'ar' ? 'صرف' : 'EXPENSE')}
                          </span>
                        </td>
                        <td className="p-3 truncate max-w-[150px]">{t.description || '-'}</td>
                        <td className="p-3 text-center font-bold">{catLabel}</td>
                        <td className="p-3 text-center font-mono">{t.date}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filteredTransactions.length > 10 && (
                <div className="p-2 bg-slate-50 text-center text-[10px] opacity-60 border-t border-[#cbd5e1]">
                  * {language === 'ar' ? `تم عرض 10 حركات فقط من أصل ${filteredTransactions.length}` : `Displaying last 10 out of ${filteredTransactions.length} items`}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="absolute bottom-6 left-[15mm] right-[15mm]">
          <div className="border-t border-[#cbd5e1] pt-4 text-center text-[9px] font-bold opacity-40 flex justify-between items-center bg-transparent">
            <span>{language === 'ar' ? 'تم الفرز والتجميع تلقائياً عبر تطبيق محفظتي الرقمية الذكي' : 'Automated calculations via Digital Wallet App intelligence'}</span>
            <span>{language === 'ar' ? 'تقرير رسمي فوري' : 'Official Instant Report'}</span>
          </div>
        </div>
      </div>
    );
  };

  const exportInvoiceToImage = async (invoice: Invoice) => {
    const invoiceId = invoice.id || 'PREVIEW';
    const templateId = `invoice-template-${invoiceId}`;
    const templateElement = document.getElementById(templateId);
    
    if (!templateElement) {
      console.error("Template element not found for image export:", templateId);
      return;
    }

    try {
      const originalStyle = templateElement.getAttribute('style') || '';
      const originalClassName = templateElement.className;

      // Force visibility for capture (render off-screen so the user doesn't see it open or flashing)
      templateElement.style.display = 'block';
      templateElement.style.visibility = 'visible';
      templateElement.style.opacity = '1';
      templateElement.style.position = 'fixed';
      templateElement.style.left = '-9999px';
      templateElement.style.top = '-9999px';
      templateElement.style.zIndex = '-9999';
      templateElement.classList.remove('invisible', 'opacity-0');

      await new Promise(resolve => setTimeout(resolve, 800));

      const canvas = await safeHtml2canvas(templateElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#f8f7f2',
        logging: false,
        onclone: (clonedDoc) => {
          cleanHtml2canvasStyles(clonedDoc);
        }
      });
      
      const dataUrl = canvas.toDataURL('image/png', 1.0);
      
      // Restore state
      templateElement.setAttribute('style', originalStyle);
      templateElement.className = originalClassName;

      const link = document.createElement('a');
      link.download = `invoice-${invoice.invoiceNumber || Date.now()}.png`;
      link.href = dataUrl;
      link.click();
      
      sendNotification(
        language === 'ar' ? 'تم تصدير الصورة' : 'Image Exported', 
        language === 'ar' ? 'تم حفظ الفاتورة كصورة PNG بجودة عالية' : 'Invoice saved as high-quality PNG image'
      );
    } catch (err) {
      console.error('Error exporting image:', err);
    }
  };

  const handleConfirmDelete = async () => {
    if (!user || !transactionToDelete) return;
    const path = `users/${user.uid}/transactions`;
    try {
      await deleteDoc(doc(db, path, transactionToDelete));
      setIsDeleteModalOpen(false);
      setTransactionToDelete(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  return (
    <>
      <PaperReportTemplate />
      <div className={cn(
        "min-h-screen bg-bg-main text-text-main font-sans pb-24 lg:pb-0 border-t-4 border-brand transition-all duration-500",
        language === 'ar' ? "lg:pr-64" : "lg:pl-64"
      )}>
      {/* Sidebar - Desktop */}
      <aside className={cn(
        "hidden lg:flex fixed top-0 bottom-0 w-64 bg-bg-card border-border-subtle flex-col p-6 z-30 transition-all duration-500",
        language === 'ar' ? "right-0 border-l" : "left-0 border-r"
      )}>
        <div className="flex items-center gap-3 mb-10 overflow-hidden">
          <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center text-black flex-shrink-0 shadow-lg shadow-brand/20">
            <Wallet size={24} />
          </div>
          <h1 className="font-sans font-bold text-xl text-text-main whitespace-nowrap tracking-wide leading-none">{language === 'ar' ? 'محفظتي الرقمية' : 'Digital Wallet'}</h1>
        </div>

        <div className="mb-6 flex gap-2">
          <button 
            onClick={toggleTheme}
            className="flex-1 flex items-center justify-center h-10 bg-bg-header/20 rounded-xl border border-border-subtle cursor-pointer hover:bg-bg-header transition-all text-brand"
            title={theme === 'light' ? (language === 'ar' ? 'الوضع الداكن' : 'Dark Mode') : (language === 'ar' ? 'الوضع الفاتح' : 'Light Mode')}
          >
            {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
          </button>
        </div>

        {user && (
          <div 
            onClick={() => setView('settings')}
            className={cn(
              "mb-8 flex flex-col items-center gap-3 p-4 bg-bg-header/40 rounded-3xl border border-border-subtle cursor-pointer hover:bg-bg-header transition-all group",
              view === 'settings' && "border-brand bg-brand/5 shadow-lg shadow-brand/10"
            )}
          >
            <div className="relative">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || ''} className="w-14 h-14 rounded-2xl object-cover shadow-2xl border-2 border-border-subtle/50 group-hover:border-brand/40 transition-all" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-14 h-14 rounded-2xl bg-brand/20 flex items-center justify-center text-brand border border-brand/20">
                  <UserIcon size={24} />
                </div>
              )}
            </div>
            <div className="text-center overflow-hidden w-full">
              <p className="text-text-main text-xs font-black truncate group-hover:text-brand transition-colors leading-tight">{user.displayName || user.email?.split('@')[0]}</p>
              <p className="text-text-muted text-[10px] truncate opacity-60 font-medium">{selectedCurrency} {language === 'ar' ? 'حساب' : 'Account'}</p>
            </div>
          </div>
        )}

        <nav className="space-y-2 flex-1">
          <button 
            onClick={() => setView('dashboard')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
              view === 'dashboard' ? "bg-bg-header text-brand font-semibold shadow-sm" : "text-text-muted hover:bg-bg-header/50 hover:text-text-main"
            )}
          >
            <Home size={20} className={cn(view === 'dashboard' ? "text-brand" : "text-text-muted opacity-60 group-hover:text-text-main")} />
            <span>{language === 'ar' ? 'لوحة التحكم' : 'Dashboard'}</span>
          </button>
          <button 
            onClick={() => setView('transactions')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
              view === 'transactions' ? "bg-bg-header text-brand font-semibold shadow-sm" : "text-text-muted hover:bg-bg-header/50 hover:text-text-main"
            )}
          >
            <ArrowRightLeft size={20} className={cn(view === 'transactions' ? "text-brand" : "text-text-muted opacity-60 group-hover:text-text-main")} />
            <span>{language === 'ar' ? 'العمليات اليومية' : 'Transactions'}</span>
          </button>
          <button 
            onClick={() => setView('categories')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
              view === 'categories' ? "bg-bg-header text-brand font-semibold shadow-sm" : "text-text-muted hover:bg-bg-header/50 hover:text-text-main"
            )}
          >
            <Tag size={20} className={cn(view === 'categories' ? "text-brand" : "text-text-muted opacity-60 group-hover:text-text-main")} />
            <span>{language === 'ar' ? 'التصنيفات' : 'Categories'}</span>
          </button>
          <button 
            onClick={() => setView('invoices')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
              view === 'invoices' ? "bg-bg-header text-brand font-semibold shadow-sm" : "text-text-muted hover:bg-bg-header/50 hover:text-text-main"
            )}
          >
            <Receipt size={20} className={cn(view === 'invoices' ? "text-brand" : "text-text-muted opacity-60 group-hover:text-text-main")} />
            <span>{language === 'ar' ? 'الفواتير' : 'Invoices'}</span>
          </button>
          <button 
            onClick={() => setView('reports')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group",
              view === 'reports' ? "bg-bg-header text-brand font-semibold shadow-sm" : "text-text-muted hover:bg-bg-header/50 hover:text-text-main"
            )}
          >
            <PieChartIcon size={20} className={cn(view === 'reports' ? "text-brand" : "text-text-muted opacity-60 group-hover:text-text-main")} />
            <span>{language === 'ar' ? 'التقارير المالية' : 'Financial Reports'}</span>
          </button>
        </nav>

        <div className="mt-auto space-y-4">
          <div className="p-4 bg-bg-header/30 border border-border-subtle rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1 h-full bg-brand"></div>
            <p className="text-text-muted text-[10px] uppercase tracking-widest font-bold mb-1">{language === 'ar' ? 'الرصيد الإجمالي' : 'Total Balance'}</p>
            <p className="text-xl font-mono text-text-main leading-none tabular-nums font-bold text-left">{formatCurrency(stats.balance)}</p>
          </div>
          
          <div className="flex items-center gap-2 px-2">
            <div className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></div>
            <span className="text-[10px] text-text-muted uppercase tracking-widest font-black font-sans opacity-60">{language === 'ar' ? 'النظام متصل' : 'Network Active'}</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="p-4 md:p-8 max-w-5xl mx-auto">
        {!user && !authLoading && (
          <div className="flex flex-col items-center justify-center py-16 px-4 text-center max-w-md mx-auto">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 bg-brand/10 rounded-3xl flex items-center justify-center text-brand mb-8"
            >
              <Wallet size={40} />
            </motion.div>
            <h2 className="text-3xl font-sans font-bold text-text-main mb-4">{language === 'ar' ? 'مرحباً بك في محفظتي الرقمية' : 'Welcome to My Digital Wallet'}</h2>
            <p className="text-text-muted mb-10 leading-relaxed text-sm">
              قم بتسجيل الدخول لبدء إدارة مصاريفك اليومية ومراقبة تدفقاتك النقدية بكل أمان وسهولة.
            </p>

            <div className="w-full space-y-6">
              {authMode === 'social' ? (
                <div className="space-y-4">
                  <button 
                    onClick={() => handleLogin('google')}
                    className="w-full flex items-center justify-center gap-3 bg-white/5 text-text-main border border-white/10 px-6 py-4 rounded-2xl font-bold hover:bg-white/10 transition-all active:scale-95"
                  >
                    <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                    <span>{language === 'ar' ? 'متابعة باستخدام Google' : 'Continue with Google'}</span>
                  </button>

                  <div className="flex items-center gap-4 py-2 text-center justify-center">
                    <span className="text-[10px] text-text-muted uppercase font-bold tracking-widest">{language === 'ar' ? 'أو الدخول الآمن عبر' : 'OR SECURE SIGN IN VIA'}</span>
                  </div>

                  <button 
                    onClick={() => {
                      setAuthError(null);
                      setAuthMessage(null);
                      setAuthMode('email');
                    }}
                    className="w-full flex items-center justify-center gap-3 bg-brand text-black px-8 py-4 rounded-2xl font-bold hover:shadow-lg hover:shadow-brand/20 transition-all active:scale-95"
                  >
                    <Mail size={20} />
                    <span>{language === 'ar' ? 'الدخول بواسطة البريد' : 'Login with Email'}</span>
                  </button>
                </div>
              ) : (
                <motion.form 
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  onSubmit={handleEmailAuth} 
                  className={cn("space-y-4", language === 'ar' ? "text-right" : "text-left")}
                >
                  <div className="flex bg-bg-header/50 p-1 rounded-xl mb-6 border border-border-subtle">
                    <button 
                      type="button"
                      onClick={() => setEmailMode('login')}
                      className={cn(
                        "flex-1 py-3 text-xs font-bold rounded-lg transition-all",
                        emailMode === 'login' ? "bg-text-main text-bg-main shadow-lg" : "text-text-muted"
                      )}
                    >
                      {language === 'ar' ? 'تسجيل دخول' : 'Login'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setEmailMode('signup')}
                      className={cn(
                        "flex-1 py-3 text-xs font-bold rounded-lg transition-all",
                        emailMode === 'signup' ? "bg-text-main text-bg-main shadow-lg" : "text-text-muted"
                      )}
                    >
                      {language === 'ar' ? 'إنشاء حساب' : 'Sign Up'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setEmailMode('reset')}
                      className={cn(
                        "flex-1 py-3 text-xs font-bold rounded-lg transition-all",
                        emailMode === 'reset' ? "bg-text-main text-bg-main shadow-lg" : "text-text-muted"
                      )}
                    >
                      {language === 'ar' ? 'استعادة' : 'Reset'}
                    </button>
                  </div>

                  {emailMode === 'reset' && (
                    <p className="text-xs text-text-muted mb-4">
                      {language === 'ar' 
                        ? 'أدخل بريدك الإلكتروني وسنرسل لك رابطاً لإعادة تعيين كلمة المرور.' 
                        : 'Enter your email and we\'ll send you a link to reset your password.'}
                    </p>
                  )}

                  {emailMode === 'signup' && (
                    <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                      <label className="text-[10px] text-text-muted uppercase font-bold tracking-widest block mb-2 px-1">{language === 'ar' ? 'الاسم' : 'Name'}</label>
                      <div className="relative">
                        <UserIcon className={cn("absolute top-1/2 -translate-y-1/2 text-text-muted opacity-60", language === 'ar' ? "right-4" : "left-4")} size={18} />
                        <input 
                          type="text" 
                          placeholder={language === 'ar' ? "مثال: أحمد علي" : "e.g. John Doe"}
                          className={cn("w-full bg-bg-header/50 border border-border-subtle rounded-xl py-3 text-text-main outline-none transition-all", language === 'ar' ? "pr-12 pl-4 text-right" : "pl-12 pr-4 text-left")}
                          value={emailAuthData.displayName}
                          onChange={e => setEmailAuthData({...emailAuthData, displayName: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  )}

                  <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                    <label className="text-[10px] text-text-muted uppercase font-bold tracking-widest block mb-2 px-1">{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</label>
                    <div className="relative">
                      <Mail className={cn("absolute top-1/2 -translate-y-1/2 text-text-muted opacity-60", language === 'ar' ? "right-4" : "left-4")} size={18} />
                      <input 
                        type="email" 
                        placeholder="your@email.com"
                        className={cn("w-full bg-bg-header/50 border border-border-subtle rounded-xl py-3 text-text-main outline-none transition-all placeholder:text-text-muted/40", language === 'ar' ? "pr-12 pl-4 text-right" : "pl-12 pr-4 text-left")}
                        value={emailAuthData.email}
                        onChange={e => setEmailAuthData({...emailAuthData, email: e.target.value})}
                        required
                      />
                    </div>
                  </div>

                  {emailMode !== 'reset' && (
                    <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                      <label className="text-[10px] text-text-muted uppercase font-bold tracking-widest block mb-2 px-1">{language === 'ar' ? 'كلمة المرور' : 'Password'}</label>
                      <div className="relative">
                        <Lock className={cn("absolute top-1/2 -translate-y-1/2 text-text-muted opacity-60", language === 'ar' ? "right-4" : "left-4")} size={18} />
                        <input 
                          type="password" 
                          placeholder="••••••••"
                          className={cn("w-full bg-bg-header/50 border border-border-subtle rounded-xl py-3 text-text-main outline-none transition-all placeholder:text-text-muted/40 font-mono", language === 'ar' ? "pr-12 pl-4 text-right" : "pl-12 pr-4 text-left")}
                          value={emailAuthData.password}
                          onChange={e => setEmailAuthData({...emailAuthData, password: e.target.value})}
                          required
                        />
                      </div>
                      {emailMode === 'login' && (
                        <button 
                          type="button"
                          onClick={() => setEmailMode('reset')}
                          className="text-[10px] text-brand font-bold uppercase tracking-widest mt-2 hover:underline"
                        >
                          {language === 'ar' ? 'نسيت كلمة المرور؟' : 'Forgot Password?'}
                        </button>
                      )}
                    </div>
                  )}

                  {authError && (
                    <p className={cn("text-red-400 text-xs bg-red-400/10 p-3 rounded-lg border border-red-400/20", language === 'ar' ? "text-right" : "text-left")}>{authError}</p>
                  )}

                  {authMessage && (
                    <p className={cn("text-emerald-400 text-xs bg-emerald-400/10 p-3 rounded-lg border border-emerald-400/20", language === 'ar' ? "text-right" : "text-left")}>{authMessage}</p>
                  )}

                  <button 
                    type="submit"
                    disabled={isAuthActionLoading}
                    className="w-full bg-brand text-black py-4 rounded-2xl font-bold hover:shadow-lg hover:shadow-brand/20 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isAuthActionLoading ? (
                      <Icons.Loader2 className="animate-spin mx-auto" size={20} />
                    ) : (
                      emailMode === 'login' 
                        ? (language === 'ar' ? 'دخول' : 'Login') 
                        : emailMode === 'signup' 
                          ? (language === 'ar' ? 'إنشاء الحساب' : 'Create Account')
                          : (language === 'ar' ? 'إرسال رابط الاستعادة' : 'Send Reset Link')
                    )}
                  </button>

                  <button 
                    type="button"
                    onClick={() => setAuthMode('social')}
                    className="w-full text-text-muted text-[10px] font-bold uppercase tracking-widest hover:text-text-main py-2"
                  >
                    {language === 'ar' ? 'العودة لخيارات الدخول' : 'Back to Login Options'}
                  </button>
                </motion.form>
              )}
            </div>
          </div>
        )}

        {authLoading && (
          <div className="flex flex-col items-center justify-center py-64 gap-6">
            <motion.div 
              animate={{ 
                rotate: 360,
                scale: [1, 1.2, 1],
                borderRadius: ["20%", "50%", "20%"]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
              className="w-16 h-16 bg-brand/20 border-4 border-brand flex items-center justify-center"
            >
              <Wallet size={32} className="text-brand" />
            </motion.div>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-text-muted text-xs uppercase tracking-widest font-bold"
            >
              جاري تحميل البيانات...
            </motion.p>
          </div>
        )}

        {user && (
          <>
            {/* Verification Banner */}
            {!user.emailVerified && user.providerData.some(p => p.providerId === 'password') && (
              <motion.div 
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="mb-8 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-500/20 rounded-xl flex items-center justify-center text-amber-500">
                    <Bell size={20} />
                  </div>
                  <p className={cn("text-xs font-bold", language === 'ar' ? "text-right" : "text-left")}>
                    {language === 'ar' 
                      ? 'بريدك الإلكتروني غير مفعّل. يرجى تفعيله للوصول لكامل المميزات.' 
                      : 'Your email is not verified. Please verify it to access all features.'}
                  </p>
                </div>
                <button 
                  onClick={handleSendEmailVerification}
                  disabled={isAuthActionLoading}
                  className="bg-amber-500 text-black px-6 py-2 rounded-xl text-xs font-bold hover:bg-amber-400 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isAuthActionLoading ? <Icons.Loader2 className="animate-spin" size={16} /> : (language === 'ar' ? 'إرسال رابط التحقق' : 'Resend Verification')}
                </button>
              </motion.div>
            )}

            {/* Mobile Header */}
            <header className="lg:hidden flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center text-black">
              <Wallet size={18} />
            </div>
            <h1 className="font-sans font-medium text-lg text-text-main">{language === 'ar' ? 'محفظتي الرقمية' : 'Digital Wallet'}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme}
              className="w-9 h-9 border border-border-subtle rounded-xl flex items-center justify-center bg-bg-card text-brand shadow-lg active:scale-95 transition-all"
            >
              {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
            </button>
            <button 
              onClick={() => setView('settings')}
              className={cn(
                "w-10 h-10 border rounded-2xl flex items-center justify-center shadow-lg active:scale-95 transition-all bg-bg-card ml-1 overflow-hidden",
                view === 'settings' ? "border-brand ring-2 ring-brand/20" : "border-border-subtle"
              )}
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || ''} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full bg-brand/10 flex items-center justify-center text-brand">
                  <UserIcon size={18} />
                </div>
              )}
            </button>
          </div>
        </header>

            <header className="hidden lg:flex items-center justify-between mb-10">
              <div>
                <h2 className="text-3xl font-sans font-medium text-text-main tracking-wide">{language === 'ar' ? 'أهلاً بك 👋' : 'Welcome 👋'}</h2>
                <p className="text-text-muted text-sm mt-1">{language === 'ar' ? 'نظرة عامة على التدفق النقدي والمصاريف اليومية' : 'Overview of cash flow and daily expenses'}</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="flex items-center gap-2 bg-brand text-black px-6 py-2.5 rounded-lg font-bold shadow-lg shadow-brand/10 hover:bg-brand/90 transition-all hover:-translate-y-0.5 active:translate-y-0"
              >
                <Plus size={18} />
                <span>{language === 'ar' ? 'إضافة قيد جديد' : 'Add Transaction'}</span>
              </button>
            </header>

        {view === 'dashboard' && (
          <div className="space-y-8 content-auto">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-4 sm:gap-6">
              <div className="bg-bg-card p-5 sm:p-6 rounded-2xl border border-border-subtle relative overflow-hidden group hover:border-brand/40 transition-all shadow-sm">
                <div className="absolute top-0 right-0 w-1 h-full bg-brand"></div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-text-muted text-[10px] uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'الرصيد النقدي' : 'CASH BALANCE'}</span>
                  <div className="w-8 h-8 rounded-lg bg-brand/10 flex items-center justify-center text-brand">
                    <Wallet size={16} />
                  </div>
                </div>
                <p className="text-xl sm:text-2xl font-sans text-text-main font-bold leading-none tabular-nums">{formatCurrency(stats.balance)}</p>
                <div className="mt-4 flex items-center gap-2 text-brand text-[8px] sm:text-[10px] uppercase tracking-widest font-medium opacity-60">
                  <div className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse"></div>
                  <span>{language === 'ar' ? 'محدث الآن' : 'SYNCED'}</span>
                </div>
              </div>

              <div className="bg-bg-card p-5 sm:p-6 rounded-2xl border border-border-subtle relative overflow-hidden group hover:border-blue-500/40 transition-all shadow-sm">
                <div className="absolute top-0 right-0 w-1 h-full bg-blue-500"></div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-text-muted text-[10px] uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'الميزانية الشهرية' : 'MONTHLY BUDGET'}</span>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
                    <Target size={16} />
                  </div>
                </div>
                <p className="text-xl sm:text-2xl font-sans text-blue-400 font-bold leading-none tabular-nums">{formatCurrency(stats.budget)}</p>
                <div className="mt-4 flex items-center gap-2 text-blue-500/60 text-[8px] sm:text-[10px] uppercase tracking-widest font-medium">
                  <span>{language === 'ar' ? `المتبقي: ${formatCurrency(stats.remainingBudget)}` : `LEFT: ${formatCurrency(stats.remainingBudget)}`}</span>
                </div>
              </div>

              <div className="bg-bg-card p-5 sm:p-6 rounded-2xl border border-border-subtle relative overflow-hidden group hover:border-emerald-500/40 transition-all shadow-sm">
                <div className="absolute top-0 right-0 w-1 h-full bg-emerald-500"></div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-text-muted text-[10px] uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'إجمالي الإيرادات' : 'TOTAL INCOME'}</span>
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                    <TrendingUp size={16} />
                  </div>
                </div>
                <p className="text-xl sm:text-2xl font-sans text-emerald-400 font-bold leading-none tabular-nums">{formatCurrency(stats.totalIncome)}</p>
                <div className="mt-4 flex items-center gap-2 text-emerald-500/60 text-[8px] sm:text-[10px] uppercase tracking-widest font-medium">
                   <TrendingUp size={12} />
                  <span>{language === 'ar' ? 'الدخل المحقق' : 'EARNED'}</span>
                </div>
              </div>

              <div className="bg-bg-card p-5 sm:p-6 rounded-2xl border border-border-subtle relative overflow-hidden group hover:border-rose-500/40 transition-all shadow-sm">
                <div className="absolute top-0 right-0 w-1 h-full bg-rose-500"></div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-text-muted text-[10px] uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'إجمالي المصاريف' : 'TOTAL EXPENSES'}</span>
                  <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-500">
                    <TrendingDown size={16} />
                  </div>
                </div>
                <p className="text-xl sm:text-2xl font-sans text-rose-400 font-bold leading-none tabular-nums">{formatCurrency(stats.totalExpenses)}</p>
                <div className="mt-4 flex items-center gap-2 text-rose-500/60 text-[8px] sm:text-[10px] uppercase tracking-widest font-medium">
                   <TrendingDown size={12} />
                  <span>{language === 'ar' ? 'المصروفات المسجلة' : 'SPENT'}</span>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-bg-card p-6 rounded-2xl border border-border-subtle overflow-hidden">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="font-sans font-medium text-text-main text-lg">{language === 'ar' ? 'تحليل التدفق النقدي' : 'Cash Flow Analysis'}</h3>
                  <div className="flex items-center gap-4 text-[10px] uppercase tracking-widest font-bold font-sans">
                    <div className="flex items-center gap-1.5 text-orange-400">
                      <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
                      <span>{language === 'ar' ? 'مصاريف' : 'Expense'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-emerald-500">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      <span>{language === 'ar' ? 'إيرادات' : 'Inflow'}</span>
                    </div>
                  </div>
                </div>
                <div className="h-64 mt-4 w-full">
                  <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-subtle)" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#64748b', fontSize: 10, letterSpacing: '0.05em' }} 
                      />
                      <YAxis hide />
                      <RechartsTooltip 
                        content={<CustomTooltip currency={selectedCurrency} language={language} />}
                        cursor={{ fill: 'var(--border-subtle)', opacity: 0.1 }}
                      />
                      <Bar dataKey="expenses" fill="#EF4444" radius={[4, 4, 0, 0]} barSize={24} />
                      <Bar dataKey="income" fill="#10B981" radius={[4, 4, 0, 0]} barSize={24} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-bg-card p-6 rounded-2xl border border-border-subtle">
                <h3 className="font-sans font-bold text-text-main text-lg mb-8 text-center uppercase tracking-wide">{language === 'ar' ? 'توزيع النفقات' : 'Expense Distribution'}</h3>
                <div className="h-48 relative flex items-center justify-center w-full">
                  {categoryData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={8}
                          dataKey="value"
                          stroke="none"
                        >
                          {categoryData.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={[
                              '#10B981', '#3B82F6', '#EF4444', '#F59E0B', '#8B5CF6', '#EC4899'
                            ][index % 6]} />
                          ))}
                        </Pie>
                        <RechartsTooltip 
                           contentStyle={{ 
                            backgroundColor: 'var(--bg-header)', 
                            borderRadius: '12px', 
                            border: '1px solid var(--border-subtle)',
                            color: 'var(--text-main)'
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center text-text-muted text-xs uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'لا توجد بيانات' : 'No Data'}</div>
                  )}
                </div>

                <div className="mt-8 space-y-3">
                  {categoryData.slice(0, 3).map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-xs px-2 py-1.5 border-b border-border-subtle/30 last:border-0 hover:bg-bg-header/20 rounded-lg transition-colors">
                      <div className="flex items-center gap-2.5">
                        <div className="w-2 h-2 rounded-full shadow-sm" style={{ backgroundColor: ['#10B981', '#3B82F6', '#EF4444'][i % 3] }}></div>
                        <span className="text-text-muted font-medium">{item.name}</span>
                      </div>
                      <span className="font-sans text-text-main font-bold tabular-nums">{Math.round((item.value / (stats.totalExpenses || 1)) * 100)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Invoices Preview */}
            {invoices.length > 0 && (
              <div className="bg-bg-card rounded-2xl border border-border-subtle overflow-hidden">
                <div className="px-8 py-5 border-b border-border-subtle flex justify-between items-center bg-bg-header/50">
                  <h3 className="font-sans font-semibold text-text-main text-lg">{language === 'ar' ? 'آخر الفواتير' : 'Recent Invoices'}</h3>
                  <button 
                    onClick={() => setView('invoices')}
                    className="text-xs text-text-muted underline underline-offset-4 hover:text-brand transition-colors"
                  >
                    {language === 'ar' ? 'إدارة كافة الفواتير' : 'Manage all invoices'}
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x md:divide-x-reverse border-border-subtle">
                  {invoices.slice(0, 3).map((inv) => (
                    <div key={inv.id} className="p-6 flex items-center justify-between gap-4 group hover:bg-brand/5 transition-colors">
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-text-main group-hover:text-brand transition-colors">{inv.invoiceNumber}</p>
                        <p className="text-[10px] text-text-muted flex items-center gap-1.5 uppercase tracking-widest font-bold">
                          <span>{inv.date}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className="text-sm font-sans font-semibold text-brand tabular-nums">{formatCurrency(inv.total)}</p>
                          <p className="text-[9px] uppercase font-black tracking-widest text-text-muted opacity-40">
                            {inv.items.length} {language === 'ar' ? 'أصناف' : 'items'}
                          </p>
                        </div>
                        <button 
                          onClick={() => exportInvoiceToPDF(inv)}
                          className="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center hover:bg-brand hover:text-black transition-all"
                          title={language === 'ar' ? 'تنزيل PDF' : 'Download PDF'}
                        >
                          <FileDown size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Transactions List (in Dashboard) */}
            <div className="bg-bg-card rounded-2xl border border-border-subtle overflow-hidden">
              <div className="px-8 py-5 border-b border-border-subtle flex justify-between items-center bg-bg-header/50">
                <h3 className="font-sans font-semibold text-text-main text-lg">{language === 'ar' ? 'سجل المعاملات بمحفظتك' : 'Wallet Transaction History'}</h3>
                <button 
                  onClick={() => setView('transactions')}
                  className="text-xs text-text-muted underline underline-offset-4 hover:text-brand transition-colors"
                >
                  عرض سجل المعاملات الكامل
                </button>
              </div>
              <div className="divide-y border-border-subtle">
                {filteredTransactions.slice(0, 10).map((t) => (
                  <TransactionRow 
                    key={t.id} 
                    transaction={t} 
                    onDelete={deleteTransaction} 
                    currency={selectedCurrency} 
                    language={language}
                    allCategories={allCategoriesList}
                  />
                ))}
                {filteredTransactions.length === 0 && (
                  <div className="py-20 text-center">
                    <p className="text-text-muted text-xs uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'ارشفة العمليات فارغة' : 'Transaction archive is empty'}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {view === 'settings' && (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8"
          >
            <header className={cn("flex items-center justify-between mb-10", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
              <div className={cn("flex items-center gap-4", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                {settingsView !== 'main' && (
                  <button 
                    onClick={() => setSettingsView('main')}
                    className="w-10 h-10 bg-bg-header/50 rounded-xl flex items-center justify-center text-text-muted hover:text-brand border border-border-subtle transition-all"
                  >
                    {language === 'ar' ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
                  </button>
                )}
                <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                  <h2 className="text-3xl font-sans font-bold text-text-main tracking-wide">{language === 'ar' ? 'الإعدادات' : 'Settings'}</h2>
                  <p className="text-text-muted text-sm mt-1">{language === 'ar' ? 'تخصيص التطبيق وتهيئة الحسابات' : 'Personalize app and configure accounts'}</p>
                </div>
              </div>
              <button 
                onClick={() => setView('dashboard')}
                className="w-10 h-10 bg-bg-header/50 rounded-xl flex items-center justify-center text-text-muted hover:text-red-500 border border-border-subtle transition-all"
              >
                <X size={20} />
              </button>
            </header>

            {settingsView === 'main' && (
              <div className="space-y-8">
                <section>
                  <h4 className={cn("text-[10px] text-text-muted uppercase font-black tracking-widest mb-4 opacity-50 px-2 font-mono", language === 'ar' ? "text-right" : "text-left")}>
                    {language === 'ar' ? 'الحساب والأمان' : 'Account & Security'}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div 
                      onClick={() => setSettingsView('account')}
                      className={cn("bg-bg-card p-6 rounded-3xl border border-border-subtle group hover:border-brand/40 transition-all cursor-pointer flex items-center gap-6", language === 'ar' ? "flex-row" : "flex-row-reverse")}
                    >
                      <div className="w-14 h-14 bg-brand/10 rounded-2xl flex items-center justify-center text-brand transition-transform group-hover:scale-110">
                        <UserIcon size={28} />
                      </div>
                      <div className={cn("flex-1 truncate", language === 'ar' ? "text-right font-sans" : "text-left font-mono")}>
                        <h3 className="font-bold text-lg text-text-main">{language === 'ar' ? 'إدارة الحساب' : 'ACCOUNT MANAGEMENT'}</h3>
                        <p className="text-text-muted text-xs truncate font-light">{language === 'ar' ? 'إدارة بيانات الحساب' : 'System identity and credentials'}</p>
                      </div>
                    </div>
                  </div>
                </section>

                <section>
                  <h4 className={cn("text-[10px] text-text-muted uppercase font-black tracking-widest mb-4 opacity-50 px-2 font-mono", language === 'ar' ? "text-right" : "text-left")}>
                    {language === 'ar' ? 'التخصيص والمالية' : 'Settings & Financials'}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div 
                      onClick={() => setSettingsView('exchange')}
                      className={cn("bg-bg-card p-6 rounded-3xl border border-border-subtle group hover:border-brand/40 transition-all cursor-pointer flex items-center gap-6", language === 'ar' ? "flex-row" : "flex-row-reverse")}
                    >
                      <div className="w-14 h-14 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-500 transition-transform group-hover:scale-110">
                        <ArrowRightLeft size={28} />
                      </div>
                      <div className={cn("flex-1 truncate", language === 'ar' ? "text-right font-sans" : "text-left font-mono")}>
                        <div className={cn("flex items-center justify-between", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                          <h3 className="font-bold text-lg text-text-main">{language === 'ar' ? 'تبديل الحساب' : 'ACTIVE LEDGER'}</h3>
                          <span className="text-[10px] bg-brand text-black px-2 py-0.5 rounded font-mono font-black">{selectedCurrency}</span>
                        </div>
                        <p className="text-text-muted text-xs truncate font-light">{language === 'ar' ? 'عزل مالي كامل لكل عملة' : 'Isolated financial data node'}</p>
                      </div>
                    </div>

                    <div 
                      onClick={() => setSettingsView('language')}
                      className={cn("bg-bg-card p-6 rounded-3xl border border-border-subtle group hover:border-brand/40 transition-all cursor-pointer flex items-center gap-6", language === 'ar' ? "flex-row" : "flex-row-reverse")}
                    >
                      <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 transition-transform group-hover:scale-110">
                        <Sparkles size={28} />
                      </div>
                      <div className={cn("flex-1 truncate", language === 'ar' ? "text-right font-sans" : "text-left font-mono")}>
                        <div className={cn("flex items-center justify-between", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                          <h3 className="font-bold text-lg text-text-main">{language === 'ar' ? 'لغة التطبيق' : 'LOCALE / UI'}</h3>
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-2 py-0.5 rounded font-mono font-black uppercase">{language === 'ar' ? 'العربية' : 'English'}</span>
                        </div>
                        <p className="text-text-muted text-xs truncate font-light">{language === 'ar' ? 'تغيير اتجاه الواجهة (RTL/LTR)' : 'Mirroring and translation'}</p>
                      </div>
                    </div>

                    <div 
                      onClick={() => setSettingsView('budget')}
                      className={cn("bg-bg-card p-6 rounded-3xl border border-border-subtle group hover:border-brand/40 transition-all cursor-pointer flex items-center gap-6", language === 'ar' ? "flex-row" : "flex-row-reverse")}
                    >
                      <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 transition-transform group-hover:scale-110">
                        <Banknote size={28} />
                      </div>
                      <div className={cn("flex-1 truncate", language === 'ar' ? "text-right font-sans" : "text-left font-mono")}>
                        <h3 className="font-bold text-lg text-text-main">{language === 'ar' ? 'الميزانية الشهرية' : 'MONTHLY QUOTA'}</h3>
                        <p className="text-text-muted text-xs truncate font-light">{language === 'ar' ? `تحديد سقف مصروفات ${selectedCurrency}` : `Operational limit for ${selectedCurrency}`}</p>
                      </div>
                    </div>

                    <div 
                      onClick={() => setSettingsView('categories')}
                      className={cn("bg-bg-card p-6 rounded-3xl border border-border-subtle group hover:border-brand/40 transition-all cursor-pointer flex items-center gap-6", language === 'ar' ? "flex-row" : "flex-row-reverse")}
                    >
                      <div className="w-14 h-14 bg-orange-500/10 rounded-2xl flex items-center justify-center text-orange-500 transition-transform group-hover:scale-110">
                        <Tag size={28} />
                      </div>
                      <div className={cn("flex-1 truncate", language === 'ar' ? "text-right font-sans" : "text-left font-mono")}>
                        <h3 className="font-bold text-lg text-text-main">{language === 'ar' ? 'إدارة الفئات' : 'CATEGORIES'}</h3>
                        <p className="text-text-muted text-xs truncate font-light">{language === 'ar' ? 'تخصيص بنود المصاريف والدخل' : 'Custom income/expense tags'}</p>
                      </div>
                    </div>
                  </div>
                </section>

                <div className="pt-10 flex flex-col items-center gap-2">
                  <div className="w-12 h-1 bg-border-subtle rounded-full"></div>
                  <p className="text-[10px] text-text-muted font-black tracking-[0.2em] opacity-40 uppercase">Pro Version 1.2.0</p>
                </div>
              </div>
            )}

            {settingsView === 'account' && (
              <div className="bg-bg-card rounded-[32px] p-8 border border-border-subtle max-w-2xl mx-auto">
                <div className="flex flex-col items-center gap-6">
                  <div className="relative group">
                    <div className="w-24 h-24 rounded-[32px] overflow-hidden border-4 border-brand/20 shadow-2xl transition-transform group-hover:scale-105">
                      {user?.photoURL ? (
                        <img src={user.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full bg-brand/10 flex items-center justify-center text-brand">
                          <UserIcon size={40} />
                        </div>
                      )}
                    </div>
                    <button 
                      onClick={handleUpdatePhotoURL}
                      className="absolute -bottom-2 -right-2 w-10 h-10 bg-brand text-black rounded-xl border-4 border-bg-card flex items-center justify-center shadow-lg hover:scale-110 transition-all"
                    >
                      <Sparkles size={16} />
                    </button>
                  </div>
                    <div className="text-center">
                      <h3 className="text-xl font-sans font-bold text-text-main">{user?.displayName || (language === 'ar' ? 'مستخدم جديد' : 'New User')}</h3>
                      <p className="text-text-muted text-sm opacity-60">{user?.email}</p>
                    </div>
                  <div className="w-full grid grid-cols-1 gap-4 mt-4">
                    <button 
                      onClick={() => setIsResetConfirmOpen(true)}
                      className="w-full py-4 bg-red-500/5 text-red-500 rounded-2xl border border-red-500/10 text-xs font-bold hover:bg-red-500/10 transition-all flex items-center justify-center gap-3"
                    >
                      <Trash2 size={16} />
                      <span>{language === 'ar' ? `تصفير رصيد ${selectedCurrency}` : `Reset ${selectedCurrency} Balance`}</span>
                    </button>

                    <button 
                      onClick={handleLogout}
                      className="w-full py-4 bg-bg-header/40 rounded-2xl border border-border-subtle text-xs font-bold hover:bg-bg-header transition-all flex items-center justify-center gap-3"
                    >
                      <LogOut size={16} />
                      <span>{language === 'ar' ? 'تسجيل الخروج' : 'Log Out'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {settingsView === 'exchange' && (
              <div className="bg-bg-card rounded-[32px] p-8 border border-border-subtle max-w-xl mx-auto">
                <div className="space-y-3">
                    {[
                      { id: 'YER', name: language === 'ar' ? 'الريال اليمني' : 'Yemeni Rial', flag: '🇾🇪' },
                      { id: 'SAR', name: language === 'ar' ? 'الريال السعودي' : 'Saudi Rial', flag: '🇸🇦' },
                      { id: 'USD', name: language === 'ar' ? 'الدولار الأمريكي' : 'US Dollar', flag: '🇺🇸' }
                    ].map(curr => (
                      <button
                        key={curr.id}
                        onClick={() => initiateCurrencyChange(curr.id as any)}
                        className={cn(
                          "w-full flex items-center justify-between p-5 rounded-2xl border transition-all",
                          selectedCurrency === curr.id ? "bg-brand/5 border-brand ring-1 ring-brand/20" : "bg-bg-header/20 border-border-subtle hover:bg-bg-header/40",
                          language === 'ar' ? "flex-row" : "flex-row-reverse"
                        )}
                      >
                        <div className={cn("flex items-center gap-4", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                          <span className="text-2xl">{curr.flag}</span>
                          <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                            <p className="font-bold text-text-main">{curr.name}</p>
                            <p className="text-[10px] text-text-muted uppercase tracking-widest font-mono font-bold opacity-60 tabular-nums">{curr.id}</p>
                          </div>
                        </div>
                        {selectedCurrency === curr.id && <Check className="text-brand" size={20} />}
                      </button>
                    ))}
                </div>
                <p className="mt-8 text-center text-text-muted text-[10px] font-black uppercase tracking-widest opacity-40 leading-relaxed">
                  {language === 'ar' ? 'تنبيه: سيتم عرض المصروفات والتقارير الخاصة بالعملة المحددة فقط' : 'Note: Only expenses and reports for the selected currency will be displayed'}
                </p>
              </div>
            )}

            {settingsView === 'language' && (
              <div className="bg-bg-card rounded-[32px] p-8 border border-border-subtle max-w-xl mx-auto">
                <h3 className="text-xl font-sans font-bold text-text-main mb-6 text-center">{language === 'ar' ? 'لغة التطبيق' : 'App Language'}</h3>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: 'ar', name: 'العربية', native: 'العربية' },
                    { id: 'en', name: 'English', native: 'English' }
                  ].map(lang => (
                    <button
                      key={lang.id}
                      onClick={() => {
                        const nextLang = lang.id as any;
                        setLanguage(nextLang);
                        if (user) {
                           setDoc(doc(db, `profiles/${user.uid}`), { language: nextLang, updatedAt: serverTimestamp() }, { merge: true });
                        }
                        setSettingsView('main');
                      }}
                      className={cn(
                        "flex flex-col items-center gap-3 p-8 rounded-2xl border transition-all",
                        language === lang.id ? "bg-emerald-500/5 border-emerald-500 ring-1 ring-emerald-500/20" : "bg-bg-header/20 border-border-subtle hover:bg-bg-header/40"
                      )}
                    >
                      <span className="text-2xl font-bold">{lang.id === 'ar' ? 'ع' : 'En'}</span>
                      <span className="font-bold text-sm">{lang.name}</span>
                      {language === lang.id && <Check className="text-emerald-500" size={16} />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {settingsView === 'budget' && (
              <div className="bg-bg-card rounded-[32px] p-8 border border-border-subtle max-w-xl mx-auto">
                <div className="text-center mb-8">
                  <h3 className="text-xl font-sans font-bold text-text-main">{language === 'ar' ? `ميزانية ${selectedCurrency}` : `${selectedCurrency} Budget`}</h3>
                  <p className="text-text-muted text-xs mt-2 uppercase tracking-widest font-black opacity-60">{language === 'ar' ? 'تحديد سقف المصاريف للعملة الحالية' : 'Set spending limit for current currency'}</p>
                </div>
                <div className="space-y-8">
                  <div className="relative">
                    <input 
                      type="text"
                      inputMode="decimal"
                      value={formatAmountInput(String(budgets[selectedCurrency] || ''))}
                      onChange={(e) => {
                        const val = cleanAmount(e.target.value);
                        setBudgets(prev => ({ ...prev, [selectedCurrency]: parseFloat(val) || 0 }));
                      }}
                      className="w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-8 px-8 text-4xl font-mono font-bold outline-none focus:border-brand/40 text-center tabular-nums"
                      placeholder="0"
                    />
                  </div>
                  <button 
                    onClick={() => {
                      if (user) {
                        setDoc(doc(db, `profiles/${user.uid}`), { budgets, updatedAt: serverTimestamp() }, { merge: true });
                        setSettingsView('main');
                      }
                    }}
                    className="w-full py-5 bg-brand text-black rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-brand/20 hover:scale-[1.02] active:scale-95 transition-all"
                  >
                    {language === 'ar' ? 'موافق' : 'OK'}
                  </button>
                </div>
              </div>
            )}

            {settingsView === 'categories' && (
              <div className="space-y-8 max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-6 px-2">
                  <h3 className={cn("text-xl font-sans font-bold text-text-main", language === 'ar' ? "text-right" : "text-left")}>
                    {language === 'ar' ? 'إدارة الفئات' : 'Category Management'}
                  </h3>
                  <button 
                    onClick={() => {
                      setEditingCategory(null);
                      setCategoryFormData({ name: '', nameEn: '', icon: 'Tag', color: 'bg-emerald-500', type: 'expense' });
                      setIsCategoryModalOpen(true);
                    }}
                    className="flex items-center gap-2 bg-brand text-black px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
                  >
                    <Plus size={16} />
                    <span>{language === 'ar' ? 'فئة جديدة' : 'NEW CATEGORY'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className={cn("text-[10px] text-emerald-500 uppercase font-black tracking-widest mb-4 px-2", language === 'ar' ? "text-right" : "text-left")}>
                      {language === 'ar' ? 'فئات الدخل' : 'INCOME CATEGORIES'}
                    </h4>
                    <div className="space-y-2">
                      {activeCategories.income.map(cat => (
                        <div key={cat.id} className="bg-bg-card p-4 rounded-2xl border border-border-subtle flex items-center justify-between group hover:border-emerald-500/30 transition-all">
                          <div className="flex items-center gap-4">
                            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white", cat.color)}>
                              <CategoryIcon name={cat.icon} size={18} />
                            </div>
                            <div>
                              <h5 className="font-bold text-sm text-text-main">{language === 'ar' ? cat.name : cat.nameEn}</h5>
                              <p className="text-[10px] text-text-muted font-mono opacity-50 uppercase">{cat.id}</p>
                            </div>
                          </div>
                          {!DEFAULT_CATEGORIES.income.find(d => d.id === cat.id) && (
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                              <button 
                                onClick={() => {
                                  setEditingCategory(cat);
                                  setCategoryFormData(cat);
                                  setIsCategoryModalOpen(true);
                                }}
                                className="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center hover:bg-brand hover:text-black transition-all"
                              >
                                <Edit2 size={14} />
                              </button>
                              <button 
                                onClick={() => handleDeleteCategory(cat.id)}
                                className="w-8 h-8 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className={cn("text-[10px] text-rose-500 uppercase font-black tracking-widest mb-4 px-2", language === 'ar' ? "text-right" : "text-left")}>
                      {language === 'ar' ? 'فئات المصروفات' : 'EXPENSE CATEGORIES'}
                    </h4>
                    <div className="space-y-2">
                      {activeCategories.expense.map(cat => (
                        <div key={cat.id} className="bg-bg-card p-4 rounded-2xl border border-border-subtle flex items-center justify-between group hover:border-rose-500/30 transition-all">
                          <div className="flex items-center gap-4">
                            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white", cat.color)}>
                              <CategoryIcon name={cat.icon} size={18} />
                            </div>
                            <div>
                              <h5 className="font-bold text-sm text-text-main">{language === 'ar' ? cat.name : cat.nameEn}</h5>
                              <p className="text-[10px] text-text-muted font-mono opacity-50 uppercase">{cat.id}</p>
                            </div>
                          </div>
                          {!DEFAULT_CATEGORIES.expense.find(d => d.id === cat.id) && (
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                              <button 
                                onClick={() => {
                                  setEditingCategory(cat);
                                  setCategoryFormData(cat);
                                  setIsCategoryModalOpen(true);
                                }}
                                className="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center hover:bg-brand hover:text-black transition-all"
                              >
                                <Edit2 size={14} />
                              </button>
                              <button 
                                onClick={() => handleDeleteCategory(cat.id)}
                                className="w-8 h-8 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {view === 'transactions' && (
          <div className="space-y-6 content-auto">
            {/* Transactions Header with Search */}
            <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between bg-bg-card p-6 rounded-2xl border border-border-subtle shadow-sm">
              <div className="relative flex-1">
                <Search className={cn("absolute top-1/2 -translate-y-1/2 text-text-muted opacity-60", language === 'ar' ? "right-4" : "left-4")} size={18} />
                <input 
                  type="text"
                  placeholder={language === 'ar' ? "ابحث في سجل البيانات الرقمي..." : "Search in digital transaction history..."}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={cn(
                    "w-full bg-bg-header/50 border border-border-subtle rounded-lg py-3 text-text-main placeholder:text-text-muted/40 transition-all outline-none",
                    language === 'ar' ? "pr-12 pl-4" : "pl-12 pr-4"
                  )}
                />
              </div>
              <div className="flex gap-2">
                <select 
                  value={`${sortConfig.key}-${sortConfig.direction}`}
                  onChange={(e) => {
                    const [key, direction] = e.target.value.split('-') as [any, any];
                    setSortConfig({ key, direction });
                  }}
                  className={cn(
                    "bg-bg-header/50 text-text-muted px-4 py-3 rounded-lg border border-border-subtle hover:bg-bg-header transition-all text-xs font-bold outline-none cursor-pointer appearance-none",
                    language === 'ar' ? "text-right" : "text-left"
                  )}
                >
                  <option value="date-desc">{language === 'ar' ? 'الأحدث أولاً' : 'Newest First'}</option>
                  <option value="date-asc">{language === 'ar' ? 'الأقدم أولاً' : 'Oldest First'}</option>
                  <option value="amount-desc">{language === 'ar' ? 'الأعلى قيمة' : 'Highest Amount'}</option>
                  <option value="amount-asc">{language === 'ar' ? 'الأقل قيمة' : 'Lowest Amount'}</option>
                  <option value="description-asc">{language === 'ar' ? 'الوصف (أ-ي)' : 'Description (A-Z)'}</option>
                  <option value="description-desc">{language === 'ar' ? 'الوصف (ي-أ)' : 'Description (Z-A)'}</option>
                </select>
                <div className="bg-bg-header/50 text-text-muted px-4 py-3 rounded-lg border border-border-subtle flex items-center justify-center">
                  <Filter size={16} />
                </div>
              </div>
            </div>

            {/* Full Transactions List */}
            <div className="bg-bg-card rounded-2xl border border-border-subtle overflow-hidden">
               <div className="px-8 py-4 border-b border-border-subtle flex justify-between items-center bg-bg-header/50">
                <h3 className="font-sans font-bold text-text-main">{language === 'ar' ? 'نتائج البحث في القيود' : 'Search Results'}</h3>
              </div>
              <div className="divide-y divide-border-subtle">
                {paginatedTransactions.map((t) => (
                  <TransactionRow 
                    key={t.id} 
                    transaction={t} 
                    onDelete={deleteTransaction} 
                    currency={selectedCurrency} 
                    language={language}
                    allCategories={allCategoriesList}
                  />
                ))}
              </div>
              {paginatedTransactions.length > 0 && totalPages > 1 && (
                <div className="px-8 py-6 border-t border-border-subtle flex items-center justify-between bg-bg-header/30">
                  <div className="text-[10px] text-text-muted uppercase tracking-widest font-bold">
                    {language === 'ar' ? `الصفحة ${currentPage} من ${totalPages}` : `Page ${currentPage} of ${totalPages}`}
                  </div>
                  <div className="flex gap-2">
                    <button 
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="w-10 h-10 border border-border-subtle rounded-xl flex items-center justify-center text-text-muted hover:bg-bg-header disabled:opacity-30 transition-all shadow-sm hover:text-brand"
                    >
                      {language === 'ar' ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
                    </button>
                    <button 
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      className="w-10 h-10 border border-border-subtle rounded-xl flex items-center justify-center text-text-muted hover:bg-bg-header disabled:opacity-30 transition-all shadow-sm hover:text-brand"
                    >
                      {language === 'ar' ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
                    </button>
                  </div>
                </div>
              )}
              {filteredTransactions.length === 0 && (
                <div className="py-32 text-center text-text-muted">
                  <div className="w-16 h-16 bg-bg-header/50 rounded-full flex items-center justify-center mx-auto mb-6 border border-border-subtle">
                    <Search className="opacity-40" size={24} />
                  </div>
                  <p className="text-text-main font-sans font-bold text-xl">{language === 'ar' ? 'لا توجد بيانات متطابقة' : 'No matching results'}</p>
                  <p className="text-xs mt-2 uppercase tracking-widest opacity-60">{language === 'ar' ? 'تأكد من صحة كلمات البحث المدخلة' : 'Check your search terms'}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'invoices' && (
          <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 content-auto">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-bg-card/30 p-6 rounded-[32px] border border-border-subtle/50">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-3 mb-2">
                  <Receipt className="text-brand" size={32} />
                  <h2 className="text-3xl font-sans font-medium text-text-main">
                    <span>{language === 'ar' ? 'الفواتير الرقمية' : 'Digital Invoices'}</span>
                  </h2>
                </div>
                <p className="text-text-muted text-sm uppercase tracking-widest font-semibold opacity-60">{language === 'ar' ? 'إدارة وتنظيم فواتيرك الاحترافية' : 'Manage your professional invoices'}</p>
              </div>
              
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 bg-bg-header/50 border border-border-subtle rounded-2xl px-4 py-2">
                  <ArrowUpDown size={16} className="text-brand opacity-60" />
                  <select 
                    className="bg-transparent text-xs font-bold text-text-main outline-none cursor-pointer"
                    onChange={(e) => {
                      const [key, dir] = e.target.value.split('-') as [any, any];
                      setInvoiceSortConfig({ key, direction: dir });
                    }}
                    value={`${invoiceSortConfig.key}-${invoiceSortConfig.direction}`}
                  >
                    <option value="date-desc">{language === 'ar' ? 'الأحدث أولاً' : 'Newest First'}</option>
                    <option value="date-asc">{language === 'ar' ? 'الأقدم أولاً' : 'Oldest First'}</option>
                    <option value="total-desc">{language === 'ar' ? 'الأعلى مبلغاً' : 'Highest Amount'}</option>
                    <option value="total-asc">{language === 'ar' ? 'الأقل مبلغاً' : 'Lowest Amount'}</option>
                  </select>
                </div>

                <button 
                  onClick={() => {
                    setInvoiceFormData({
                      items: [],
                      date: format(new Date(), 'yyyy-MM-dd'),
                      currencyId: selectedCurrency,
                      invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
                    });
                    setIsInvoiceModalOpen(true);
                  }}
                  className="group flex items-center gap-3 bg-brand text-bg-main px-6 py-3.5 rounded-2xl font-bold shadow-xl shadow-brand/20 hover:scale-[1.02] active:scale-95 transition-all justify-center"
                >
                  <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" />
                  <span>{language === 'ar' ? 'إضافة فاتورة' : 'Add Invoice'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredInvoices.length === 0 ? (
                <div className="col-span-full py-20 px-8 bg-bg-header/20 border-2 border-dashed border-border-subtle rounded-3xl text-center">
                  <Receipt className="mx-auto mb-4 opacity-20" size={48} />
                  <p className="text-xs font-bold uppercase tracking-widest leading-relaxed opacity-60">{language === 'ar' ? 'لا توجد فواتير مسجلة' : 'No invoices recorded'}</p>
                </div>
              ) : (
                filteredInvoices.map(invoice => (
                  <React.Fragment key={invoice.id}>
                    <PaperInvoiceTemplate invoice={invoice} />
                    <motion.div 
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      whileHover={{ y: -4 }}
                      className="bg-bg-card p-6 rounded-[32px] border border-border-subtle hover:border-brand/40 transition-all group flex flex-col gap-5 shadow-sm relative overflow-hidden"
                    >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-brand/5 rounded-bl-[64px] -mr-8 -mt-8 flex items-end justify-start pl-8 pb-8 text-brand opacity-20 group-hover:scale-110 transition-transform">
                      <Receipt size={32} />
                    </div>

                    <div className="flex justify-between items-start relative z-10">
                      <div className="space-y-1">
                        <p className={cn("text-[10px] text-text-muted font-black uppercase tracking-[0.2em] opacity-40 font-mono")}>
                          {invoice.date}
                        </p>
                        <h4 className="text-lg font-sans font-medium text-text-main tracking-tight group-hover:text-brand transition-colors">{invoice.invoiceNumber}</h4>
                      </div>
                      {invoice.attachment && (
                        <a 
                          href={invoice.attachment.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-500 rounded-xl text-[11px] font-bold hover:bg-emerald-500 hover:text-white transition-all shadow-md shadow-emerald-500/5 duration-200"
                          title={invoice.attachment.name}
                        >
                          <Icons.HardDrive size={12} />
                          <span className="font-sans text-[10px] truncate max-w-[80px]">{language === 'ar' ? 'مرفق' : 'Attachment'}</span>
                        </a>
                      )}
                    </div>

                    <div className="flex-1 space-y-3 py-4 border-y border-border-subtle/30">
                      {invoice.items.slice(0, 3).map((item, i) => (
                        <div key={i} className={cn("flex justify-between items-center text-[10px] font-medium", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                          <span className="text-text-muted truncate max-w-[140px] opacity-80">{item.name}</span>
                          <div className={cn("flex items-center gap-2", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                            <span className="text-text-muted opacity-30 text-[9px] font-mono">x{item.quantity}</span>
                            <span className="text-text-main font-mono tabular-nums tracking-tighter">{formatCurrency(item.total, invoice.currencyId)}</span>
                          </div>
                        </div>
                      ))}
                      {invoice.items.length > 3 && (
                        <p className="text-[9px] text-brand font-black text-center pt-1 uppercase tracking-widest font-mono">{language === 'ar' ? `+ ${invoice.items.length - 3} أصناف إضافية` : `+ ${invoice.items.length - 3} more items`}</p>
                      )}
                    </div>

                    <div className={cn("flex items-center justify-between pt-1 relative z-10", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                       <div className={cn(language === 'ar' ? "text-right" : "text-left")}>
                          <p className="text-[9px] text-text-muted uppercase font-black tracking-[0.2em] opacity-30 mb-0.5">{language === 'ar' ? 'القيمة الإجمالية' : 'Total Amount'}</p>
                          <p className="text-xl font-mono font-semibold text-brand tabular-nums tracking-tighter">{formatCurrency(invoice.total, invoice.currencyId)}</p>
                       </div>
                       <div className="flex gap-2">
                          <button 
                            onClick={() => exportInvoiceToPDF(invoice)}
                            className="w-11 h-11 rounded-2xl bg-brand/10 text-brand hover:bg-brand hover:text-black transition-all flex items-center justify-center shadow-lg shadow-brand/5 group/btn"
                            title={language === 'ar' ? 'تنزيل PDF' : 'Download PDF'}
                          >
                            <FileDown size={20} className="group-hover/btn:scale-110 transition-transform" />
                          </button>
                          <button 
                            onClick={() => handleDeleteInvoice(invoice.id)}
                            className="w-11 h-11 rounded-2xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all flex items-center justify-center opacity-40 group-hover:opacity-100 shadow-lg shadow-red-500/10 group/del"
                          >
                            <Trash2 size={20} className="group-hover/del:scale-110 transition-transform" />
                          </button>
                       </div>
                    </div>
                  </motion.div>
                </React.Fragment>
                ))
              )}
            </div>
          </div>
        )}

        {view === 'reports' && (
          <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 lg:pb-0 content-auto">
            {/* Header with PDF Download Trigger */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-bg-card border border-border-subtle p-6 rounded-[32px] shadow-sm">
              <div className="space-y-1">
                <h2 className="text-3xl font-sans font-medium text-text-main flex items-center gap-3">
                  <PieChartIcon className="text-brand" size={32} />
                  <span>{language === 'ar' ? 'التحليلات والتقارير المالية' : 'Financial Reports & Analytics'}</span>
                </h2>
                <p className="text-text-muted text-xs uppercase tracking-widest font-semibold opacity-60">
                  {language === 'ar' ? 'رصد الأنماط الذكية وتوليد تقارير PDF فورية' : 'Pattern spotting and instant PDF generator'}
                </p>
              </div>

              <button
                onClick={exportFinancialReportToPDF}
                className="flex items-center justify-center gap-2 bg-brand text-black font-bold px-6 py-3 rounded-2xl shadow-lg shadow-brand/20 hover:bg-brand/90 transition-all active:scale-95 cursor-pointer text-sm"
              >
                <Download size={18} />
                <span>{language === 'ar' ? 'تحميل تقرير PDF مالي رسمي' : 'Download PDF Financial Report'}</span>
              </button>
            </div>

            {/* Interval Controls Dashboard */}
            <div className="bg-bg-card border border-border-subtle p-6 rounded-[32px] shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border-subtle pb-6">
                <div className="space-y-1">
                  <h4 className="text-xs uppercase font-black tracking-widest text-text-muted opacity-40">
                    {language === 'ar' ? 'الفترة الزمنية للتقرير' : 'REPORT ACCRUAL INTERVAL'}
                  </h4>
                  <p className="text-xs text-text-muted">
                    {language === 'ar' ? 'اختر النطاق الزمني لعرض الإحصاءات والأنماط' : 'Select interval to load charts, metrics & patterns'}
                  </p>
                </div>

                {/* Period Selector Pills */}
                <div className="grid grid-cols-3 gap-1 bg-bg-header p-1.5 rounded-2xl w-full sm:w-auto border border-border-subtle">
                  {(['daily', 'weekly', 'monthly'] as const).map((period) => {
                    const isActive = reportPeriod === period;
                    let label = '';
                    if (period === 'daily') label = language === 'ar' ? 'يومي' : 'Daily';
                    if (period === 'weekly') label = language === 'ar' ? 'أسبوعي' : 'Weekly';
                    if (period === 'monthly') label = language === 'ar' ? 'شهري' : 'Monthly';

                    return (
                      <button
                        key={period}
                        onClick={() => setReportPeriod(period)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer",
                          isActive 
                            ? "bg-bg-card border border-border-subtle text-brand shadow-sm" 
                            : "text-text-muted hover:text-text-main"
                        )}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dynamic Period Inputs / Chevron Adjusters */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-bg-header/20 p-4 rounded-2xl border border-border-subtle">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-brand animate-ping" />
                  <span className="text-xs font-bold text-text-main">
                    {language === 'ar' ? 'النطاق النشط حالياً:' : 'Active Interval scope:'}
                  </span>
                  <span className="text-xs font-mono font-bold text-brand bg-brand/5 border border-brand/10 px-3 py-1 rounded-full">
                    {language === 'ar' ? reportData.periodLabelAr : reportData.periodLabelEn}
                  </span>
                </div>

                {/* Dynamic Filters */}
                {reportPeriod === 'daily' && (
                  <div className="flex items-center gap-2">
                    <input
                      type="date"
                      value={reportDailyDate}
                      onChange={(e) => setReportDailyDate(e.target.value)}
                      className="bg-bg-card text-text-main border border-border-subtle rounded-xl px-4 py-2 text-xs font-mono focus:outline-none focus:border-brand"
                    />
                  </div>
                )}

                {reportPeriod === 'weekly' && (
                  <div className="flex items-center gap-2">
                    <input
                      type="date"
                      value={reportWeeklyDate}
                      onChange={(e) => setReportWeeklyDate(e.target.value)}
                      className="bg-bg-card text-text-main border border-border-subtle rounded-xl px-4 py-2 text-xs font-mono focus:outline-none focus:border-brand"
                    />
                  </div>
                )}

                {reportPeriod === 'monthly' && (
                  <div className="flex items-center gap-2 bg-bg-card border border-border-subtle p-1 rounded-xl">
                    <button 
                      onClick={() => {
                        const [y, m] = reportDate.split('-').map(Number);
                        const d = new Date(y, m - 2);
                        setReportDate(format(d, 'yyyy-MM'));
                      }}
                      className="p-1.5 hover:bg-bg-header rounded-lg transition-all text-text-muted hover:text-brand cursor-pointer"
                    >
                      {language === 'ar' ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
                    </button>
                    <input
                      type="month"
                      value={reportDate}
                      onChange={(e) => setReportDate(e.target.value)}
                      className="bg-transparent text-text-main font-mono text-center font-bold text-xs focus:outline-none cursor-pointer border-none px-2"
                    />
                    <button 
                      onClick={() => {
                        const [y, m] = reportDate.split('-').map(Number);
                        const d = new Date(y, m);
                        setReportDate(format(d, 'yyyy-MM'));
                      }}
                      className="p-1.5 hover:bg-bg-header rounded-lg transition-all text-text-muted hover:text-brand cursor-pointer"
                    >
                      {language === 'ar' ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* KPI Cards section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-bg-card p-6 rounded-3xl border border-border-subtle shadow-sm group hover:border-emerald-500/40 transition-all flex flex-col justify-between">
                <div className={cn("flex items-center gap-3 mb-4", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                    <TrendingUp size={20} />
                  </div>
                  <span className="text-[10px] uppercase font-black tracking-widest text-text-muted opacity-60 font-mono">
                    {language === 'ar' ? 'إجمالي المقبوضات' : 'TOTAL INCOME'}
                  </span>
                </div>
                <p className={cn("text-2xl font-mono font-bold text-emerald-500 tabular-nums", language === 'ar' ? "text-right" : "text-left")}>
                  {formatCurrency(reportData.income)}
                </p>
              </div>

              <div className="bg-bg-card p-6 rounded-3xl border border-border-subtle shadow-sm group hover:border-red-500/40 transition-all flex flex-col justify-between">
                <div className={cn("flex items-center gap-3 mb-4", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                  <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center text-red-500">
                    <TrendingDown size={20} />
                  </div>
                  <span className="text-[10px] uppercase font-black tracking-widest text-text-muted opacity-60 font-mono">
                    {language === 'ar' ? 'إجمالي المصاريف' : 'TOTAL EXPENSES'}
                  </span>
                </div>
                <p className={cn("text-2xl font-mono font-bold text-red-500 tabular-nums", language === 'ar' ? "text-right" : "text-left")}>
                  {formatCurrency(reportData.expenses)}
                </p>
              </div>

              <div className="bg-bg-card p-6 rounded-3xl border border-border-subtle shadow-sm group hover:border-brand/40 transition-all flex flex-col justify-between">
                <div className={cn("flex items-center gap-3 mb-4", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                  <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center text-brand">
                    <Wallet size={20} />
                  </div>
                  <span className="text-[10px] uppercase font-black tracking-widest text-text-muted opacity-60 font-mono">
                    {language === 'ar' ? 'صافي المتبقي' : 'SURPLUS / DEFICIT'}
                  </span>
                </div>
                <p className={cn(
                  "text-2xl font-mono font-bold tabular-nums", 
                  reportData.balance >= 0 ? "text-text-main" : "text-red-500",
                  language === 'ar' ? "text-right" : "text-left"
                )}>
                  {formatCurrency(reportData.balance)}
                </p>
              </div>
            </div>

            {/* Financial Insights Panel (وتوفر رؤى حول الأنماط المالية) */}
            <div className="bg-bg-card border border-border-subtle p-6 rounded-[32px] shadow-sm space-y-4">
              <div className="flex items-center gap-3 border-b border-border-subtle pb-4">
                <div className="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center">
                  <PieChartIcon size={18} />
                </div>
                <div>
                  <h3 className="text-md font-sans font-bold text-text-main">
                    {language === 'ar' ? 'التحليلات الذكية والأنماط المالية الكبرى' : 'Financial Intelligence & Spending Patterns'}
                  </h3>
                  <p className="text-[11px] text-text-muted">
                    {language === 'ar' ? 'ملاحظات آلية حول سلوك الصرف والإيداع من خلال دراسة الفئات والتدفقات ومعدل الادخار' : 'AI-generated insights summarizing your spending behaviors, savings rate, and allocations'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {reportData.insights.map((insight: any, index: number) => {
                  const colorMap = {
                    success: {
                      bg: 'bg-emerald-500/5 border-emerald-500/25 text-emerald-900 dark:text-emerald-300',
                      badge: 'bg-emerald-500/10 text-emerald-500',
                      label: language === 'ar' ? 'ممتاز' : 'Excellent'
                    },
                    warning: {
                      bg: 'bg-red-500/5 border-red-500/25 text-red-900 dark:text-red-300',
                      badge: 'bg-red-500/10 text-red-500',
                      label: language === 'ar' ? 'تنبيه' : 'Warning'
                    },
                    info: {
                      bg: 'bg-blue-500/5 border-blue-500/25 text-blue-900 dark:text-blue-300',
                      badge: 'bg-blue-500/10 text-blue-500',
                      label: language === 'ar' ? 'توصية' : 'Advice'
                    },
                    neutral: {
                      bg: 'bg-slate-500/5 border-slate-500/25 text-slate-800 dark:text-slate-300',
                      badge: 'bg-slate-500/10 text-slate-500',
                      label: language === 'ar' ? 'ملاحظة' : 'Notice'
                    }
                  }[insight.type];

                  return (
                    <div 
                      key={index}
                      className={cn(
                        "p-5 rounded-2xl border flex flex-col justify-between gap-3 text-xs leading-relaxed transition-all hover:scale-[1.01] animate-in fade-in zoom-in-95 duration-300",
                        colorMap.bg
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm tracking-tight">
                          {language === 'ar' ? insight.titleAr : insight.titleEn}
                        </span>
                        <span className={cn("px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider", colorMap.badge)}>
                          {colorMap.label}
                        </span>
                      </div>
                      <p className="opacity-80">
                        {language === 'ar' ? insight.descAr : insight.descEn}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Dynamic visual charts */}
            {reportData.expenses === 0 ? (
              <div className="bg-bg-card p-20 text-center space-y-4 border border-border-subtle rounded-[32px] opacity-40">
                <PieChartIcon className="mx-auto" size={48} />
                <p className="text-sm font-bold uppercase tracking-widest text-[#64748B]">
                  {language === 'ar' ? 'لا توجد بيانات مصروفات مرصودة لهذا المجال' : 'No expense entries found for this scope'}
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Pie Chart Card */}
                  <div className="bg-bg-card rounded-3xl border border-border-subtle shadow-sm overflow-hidden p-8 flex flex-col h-[400px]">
                    <h3 className={cn("w-full font-sans font-bold text-xl text-text-main mb-6", language === 'ar' ? "text-right" : "text-left")}>
                      {language === 'ar' ? 'توزيع المصروفات الكلي' : 'Overall Expense breakdown'}
                    </h3>
                    <div className="flex-1 w-full min-h-0">
                      <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                        <PieChart>
                          <Pie
                            data={reportData.categoryBreakdown.filter(c => c.total > 0)}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="total"
                            nameKey={language === 'ar' ? "name" : "nameEn"}
                          >
                            {reportData.categoryBreakdown.filter(c => c.total > 0).map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.id] || '#6b7280'} />
                            ))}
                          </Pie>
                          <RechartsTooltip 
                            contentStyle={{ 
                              backgroundColor: 'var(--color-bg-card)', 
                              border: '1px solid var(--color-border-subtle)',
                              borderRadius: '12px',
                              color: 'var(--color-text-main)'
                            }}
                            itemStyle={{ color: 'var(--color-text-main)', fontSize: '10px', fontFamily: 'var(--font-mono)' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* List Card */}
                  <div className="bg-bg-card rounded-3xl border border-border-subtle shadow-sm overflow-hidden p-8 flex flex-col h-[400px]">
                    <h3 className={cn("w-full font-sans font-bold text-xl text-text-main mb-6", language === 'ar' ? "text-right" : "text-left")}>
                      {language === 'ar' ? 'تفاصيل توزيع الميزانية' : 'Categorical allocation details'}
                    </h3>
                    <div className="flex-1 overflow-y-auto space-y-5 px-2 custom-scrollbar">
                      {reportData.categoryBreakdown.filter(c => c.total > 0).map((cat) => (
                        <div key={cat.id} className="space-y-2">
                          <div className={cn("flex items-center justify-between text-sm", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                            <div className={cn("flex items-center gap-3", language === 'ar' ? "flex-row" : "flex-row-reverse")}>
                              <div className={cn("w-3 h-3 rounded-full shadow-sm", cat.color)} />
                              <span className="font-bold text-text-main">{language === 'ar' ? cat.name : cat.nameEn}</span>
                            </div>
                            <div className="font-mono flex items-center gap-2">
                              <span className="text-text-muted text-[10px] opacity-60 font-mono tracking-tighter">({(cat.percentage || 0).toFixed(0)}%)</span>
                              <span className="text-text-main font-mono tabular-nums tracking-tighter">{formatCurrency(cat.total)}</span>
                            </div>
                          </div>
                          <div className="h-1 w-full bg-bg-header/50 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${cat.percentage}%` }}
                              transition={{ duration: 1, ease: 'easeOut' }}
                              className={cn("h-full rounded-full transition-all duration-1000 shadow-sm", cat.color)}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {view === 'categories' && (
          <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20 lg:pb-0 content-auto">
             <header className="flex items-center justify-between">
              <div>
                <h3 className="text-3xl font-sans font-medium text-text-main flex items-center gap-3">
                  <Tag className="text-brand" size={32} />
                  <span>{language === 'ar' ? 'تصنيفات الحسابات' : 'Account Categories'}</span>
                </h3>
                <p className="text-text-muted text-sm uppercase tracking-widest font-semibold opacity-60">{language === 'ar' ? 'تخصيص فئات المصاريف والإيرادات' : 'Customize Expense and Income Categories'}</p>
              </div>
              <button 
                onClick={() => {
                  setEditingCategory(null);
                  setCategoryFormData({ name: '', nameEn: '', icon: 'Tag', color: 'bg-brand', type: 'expense' });
                  setIsCategoryModalOpen(true);
                }}
                className="flex items-center gap-2 bg-brand text-black px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-brand/10 hover:bg-brand/90 transition-all active:scale-95"
              >
                <Plus size={18} />
                <span>{language === 'ar' ? 'إضافة فئة' : 'Add Category'}</span>
              </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Expense Categories */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 px-2">
                  <TrendingDown className="text-rose-500" size={16} />
                  <h4 className="text-[10px] uppercase font-black tracking-[0.2em] text-text-muted opacity-40">{language === 'ar' ? 'فئات المصاريف' : 'EXPENSE CATEGORIES'}</h4>
                </div>
                <div className="grid grid-cols-1 gap-3">
                  {activeCategories.expense.map(cat => (
                    <div key={cat.id} className="bg-bg-card border border-border-subtle p-4 rounded-2xl flex items-center justify-between group hover:border-brand/40 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white scale-90 group-hover:scale-100 transition-transform shadow-lg", cat.color || 'bg-brand')}>
                          <CategoryIcon name={cat.icon} size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-text-main">{language === 'ar' ? cat.name : cat.nameEn}</p>
                          <p className="text-[10px] text-text-muted opacity-40 uppercase tracking-widest font-mono">ID: {cat.id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button 
                          onClick={() => {
                            setEditingCategory(cat);
                            setCategoryFormData(cat);
                            setIsCategoryModalOpen(true);
                          }}
                          className="p-2 text-text-muted hover:text-brand hover:bg-brand/10 rounded-lg transition-all"
                        >
                          <Settings size={14} />
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(cat.id)}
                          className="p-2 text-text-muted hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

               {/* Income Categories */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 px-2">
                  <TrendingUp className="text-emerald-500" size={16} />
                  <h4 className="text-[10px] uppercase font-black tracking-[0.2em] text-text-muted opacity-40">{language === 'ar' ? 'فئات الإيرادات' : 'INCOME CATEGORIES'}</h4>
                </div>
                <div className="grid grid-cols-1 gap-3">
                  {activeCategories.income.map(cat => (
                    <div key={cat.id} className="bg-bg-card border border-border-subtle p-4 rounded-2xl flex items-center justify-between group hover:border-brand/40 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white scale-90 group-hover:scale-100 transition-transform shadow-lg", cat.color || 'bg-brand')}>
                          <CategoryIcon name={cat.icon} size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-text-main">{language === 'ar' ? cat.name : cat.nameEn}</p>
                          <p className="text-[10px] text-text-muted opacity-40 uppercase tracking-widest font-mono">ID: {cat.id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button 
                          onClick={() => {
                            setEditingCategory(cat);
                            setCategoryFormData(cat);
                            setIsCategoryModalOpen(true);
                          }}
                          className="p-2 text-text-muted hover:text-brand hover:bg-brand/10 rounded-lg transition-all"
                        >
                          <Settings size={14} />
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(cat.id)}
                          className="p-2 text-text-muted hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </>
    )}
  </main>

        {user && (
          <>
            {/* Mobile Navigation Bar */}
            <nav className="lg:hidden fixed bottom-6 left-6 right-6 h-20 bg-bg-card/60 backdrop-blur-2xl border border-border-subtle shadow-2xl rounded-3xl flex items-center justify-around px-4 z-40">
              <button 
                onClick={() => setView('dashboard')}
                className={cn(
                  "p-3 rounded-2xl transition-all",
                  view === 'dashboard' ? "text-brand bg-brand/10" : "text-text-muted opacity-60"
                )}
              >
                <Home size={24} />
              </button>
              <button 
                onClick={() => setView('invoices')}
                className={cn(
                  "p-3 rounded-2xl transition-all",
                  view === 'invoices' ? "text-brand bg-brand/10" : "text-text-muted opacity-60"
                )}
              >
                <Receipt size={24} />
              </button>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="w-14 h-14 bg-brand text-black rounded-2xl flex items-center justify-center shadow-xl shadow-brand/20 -mt-10 border-4 border-bg-main active:scale-90 transition-all"
              >
                <Plus size={32} />
              </button>
              <button 
                onClick={() => setView('reports')}
                className={cn(
                  "p-3 rounded-2xl transition-all",
                  view === 'reports' ? "text-brand bg-brand/10" : "text-text-muted opacity-60"
                )}
              >
                <PieChartIcon size={24} />
              </button>
              <button 
                onClick={() => setView('transactions')}
                className={cn(
                  "p-3 rounded-2xl transition-all",
                  view === 'transactions' ? "text-brand bg-brand/10" : "text-text-muted opacity-60"
                )}
              >
                <ArrowRightLeft size={24} />
              </button>
            </nav>

            {/* Modals outside main for proper positioning */}
            <TransactionModal 
              isOpen={isModalOpen} 
              onClose={() => setIsModalOpen(false)} 
              onSubmit={onSubmitTransaction} 
              currency={selectedCurrency}
              language={language}
              categories={activeCategories}
              ensureGoogleAccessToken={ensureGoogleAccessToken}
            />

            <CategoryModal
              isOpen={isCategoryModalOpen}
              onClose={() => setIsCategoryModalOpen(false)}
              onSubmit={handleSaveCategory}
              onDelete={handleDeleteCategory}
              formData={categoryFormData}
              setFormData={setCategoryFormData}
              editingCategory={editingCategory}
              language={language}
            />

            <AnimatePresence>
              {isInvoiceModalOpen && (
                <>
                  <PaperInvoiceTemplate invoice={{ ...invoiceFormData, id: invoiceFormData.id || 'PREVIEW' } as Invoice} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="fixed inset-0 bg-white z-[100] flex flex-col overflow-hidden"
                  >
                  {/* Modern Turquoise Header */}
                  <div className="flex items-center justify-between p-6 bg-white border-b border-slate-100 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-brand rounded-2xl flex items-center justify-center text-white shadow-lg shadow-brand/20">
                        <Receipt size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl sm:text-2xl font-sans font-bold text-slate-900">{language === 'ar' ? 'محفظتي الرقمية' : 'Digital Wallet'}</h3>
                        <p className="text-[10px] text-brand mt-0.5 uppercase tracking-widest font-sans font-bold">
                          {language === 'ar' ? 'نظام إدارة الفواتير الاحترافي' : 'PRO INVOICE MANAGEMENT'}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsInvoiceModalOpen(false)}
                      className="w-12 h-12 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center hover:text-brand hover:bg-brand/5 transition-all border border-slate-100"
                    >
                      <X size={20} />
                    </button>
                  </div>

                  {/* Form Content matching the image */}
                  <div className="flex-1 overflow-y-auto p-4 sm:p-10 custom-scrollbar bg-slate-50">
                    <div className="max-w-xl mx-auto space-y-8" ref={invoiceRef}>
                      
                      <div className="text-center space-y-4">
                        <h2 className="text-2xl sm:text-3xl font-sans font-black text-brand tracking-tight">
                          {language === 'ar' ? 'إضافة فاتورة جديدة' : 'Add New Invoice'}
                        </h2>
                      </div>

                      {/* Invoice Details Card */}
                      <div className="bg-white p-6 sm:p-8 rounded-[24px] border border-slate-100 shadow-sm space-y-6">
                        <div className="flex items-center justify-end gap-2 text-brand border-b border-slate-50 pb-3">
                           <span className="text-[14px] font-black">{language === 'ar' ? 'تفاصيل الفاتورة' : 'Invoice Details'}</span>
                        </div>

                        <div className="space-y-4">
                          {/* Row: Invoice Name */}
                          <div className="flex items-center justify-between gap-4">
                            <input 
                              type="text" 
                              placeholder={language === 'ar' ? 'اسم الفاتورة' : 'Invoice Name'}
                              className="flex-1 bg-white border border-slate-200 rounded-xl py-3 px-5 text-sm text-slate-900 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition-all text-right"
                              value={invoiceFormData.customerName || ''}
                              onChange={(e) => setInvoiceFormData({ ...invoiceFormData, customerName: e.target.value })}
                            />
                            <label className="w-24 text-[13px] font-bold text-slate-700 text-right">{language === 'ar' ? 'اسم الفاتورة' : 'Invoice Name'}</label>
                          </div>

                          {/* Row: Shop Name */}
                          <div className="flex items-center justify-between gap-4">
                            <input 
                              type="text" 
                              placeholder={language === 'ar' ? 'اسم المحل' : 'Shop Name'}
                              className="flex-1 bg-white border border-slate-200 rounded-xl py-3 px-5 text-sm text-slate-900 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition-all text-right"
                              value={invoiceFormData.shopName || ''}
                              onChange={(e) => setInvoiceFormData({ ...invoiceFormData, shopName: e.target.value })}
                            />
                            <label className="w-24 text-[13px] font-bold text-slate-700 text-right">{language === 'ar' ? 'اسم المحل' : 'Shop Name'}</label>
                          </div>

                          {/* Row: Date */}
                          <div className="flex items-center justify-between gap-4">
                            <input 
                              type="date" 
                              className="flex-1 bg-white border border-slate-200 rounded-xl py-3 px-5 text-sm text-slate-900 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition-all text-right"
                              value={invoiceFormData.date || ''}
                              onChange={(e) => setInvoiceFormData({ ...invoiceFormData, date: e.target.value })}
                            />
                            <label className="w-24 text-[13px] font-bold text-slate-700 text-right">{language === 'ar' ? 'التاريخ' : 'Date'}</label>
                          </div>

                          {/* Row: Currency */}
                          <div className="flex items-center justify-between gap-4">
                            <select 
                              className="flex-1 bg-white border border-slate-200 rounded-xl py-3 px-5 text-sm text-slate-900 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition-all text-right appearance-none"
                              value={invoiceFormData.currencyId || selectedCurrency}
                              onChange={(e) => setInvoiceFormData({ ...invoiceFormData, currencyId: e.target.value as any })}
                            >
                              <option value="YER">YER - الريال اليمني</option>
                              <option value="SAR">SAR - الريال السعودي</option>
                              <option value="USD">USD - الدولار الأمريكي</option>
                            </select>
                            <label className="w-24 text-[13px] font-bold text-slate-700 text-right">{language === 'ar' ? 'العملة' : 'Currency'}</label>
                          </div>

                          {/* Row: Total (Read Only / Greyed) */}
                          <div className="flex items-center justify-between gap-4">
                            <div className="flex-1 bg-slate-100 border border-slate-200 rounded-xl py-3 px-5 text-sm text-slate-400 font-mono text-right">
                              {formatCurrency((invoiceFormData.items || []).reduce((sum, it) => sum + (it.total || 0), 0), invoiceFormData.currencyId)}
                            </div>
                            <label className="w-24 text-[13px] font-bold text-slate-700 text-right">{language === 'ar' ? 'المبلغ الإجمالي' : 'Total Amount'}</label>
                          </div>
                        </div>
                      </div>

                      {/* Items Card */}
                      <div className="bg-white p-6 sm:p-8 rounded-[24px] border border-slate-100 shadow-sm space-y-6">
                        <div className="flex items-center justify-end gap-2 text-brand border-b border-slate-50 pb-3">
                           <span className="text-[14px] font-black">{language === 'ar' ? 'الأصناف' : 'Items'}</span>
                        </div>

                        {/* Table Header */}
                        <div className="grid grid-cols-12 gap-2 text-[11px] font-black text-brand text-center">
                          <div className="col-span-1">{language === 'ar' ? 'إجراءات' : 'Act'}</div>
                          <div className="col-span-2">{language === 'ar' ? 'الإجمالي' : 'Total'}</div>
                          <div className="col-span-2">{language === 'ar' ? 'السعر' : 'Price'}</div>
                          <div className="col-span-2">{language === 'ar' ? 'الكمية' : 'Qty'}</div>
                          <div className="col-span-5">{language === 'ar' ? 'اسم الصنف' : 'Item Name'}</div>
                        </div>

                        {/* Table Body */}
                        <div className="space-y-3">
                          {(invoiceFormData.items || []).map((item, index) => (
                            <div key={item.id || index} className="grid grid-cols-12 gap-2 items-center text-center">
                              {/* Actions */}
                              <div className="col-span-1 flex justify-center">
                                <button 
                                  onClick={() => {
                                    const newItems = (invoiceFormData.items || []).filter((_, i) => i !== index);
                                    setInvoiceFormData({ ...invoiceFormData, items: newItems });
                                  }}
                                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-red-500 border border-slate-100 hover:border-red-100 transition-all"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>

                              {/* Total (Display only) */}
                              <div className="col-span-2 py-2 text-[12px] font-mono font-bold text-slate-600">
                                {formatCurrency(item.total || 0, invoiceFormData.currencyId)}
                              </div>

                              {/* Price */}
                              <div className="col-span-2">
                                <input 
                                  type="number"
                                  className="w-full bg-white border border-brand/20 rounded-xl py-1 px-2 text-[12px] font-mono text-center outline-none focus:border-brand transition-all font-bold text-slate-700"
                                  value={item.price || ''}
                                  onChange={(e) => {
                                    const price = parseFloat(e.target.value) || 0;
                                    const newItems = [...(invoiceFormData.items || [])];
                                    newItems[index] = { ...item, price, total: price * item.quantity };
                                    setInvoiceFormData({ ...invoiceFormData, items: newItems });
                                  }}
                                />
                              </div>

                              {/* Qty */}
                              <div className="col-span-2">
                                <input 
                                  type="number"
                                  className="w-full bg-white border border-brand/20 rounded-xl py-1 px-2 text-[12px] font-mono text-center outline-none focus:border-brand transition-all font-bold text-slate-700"
                                  value={item.quantity}
                                  onChange={(e) => {
                                    const quantity = parseFloat(e.target.value) || 0;
                                    const newItems = [...(invoiceFormData.items || [])];
                                    newItems[index] = { ...item, quantity, total: (item.price || 0) * quantity };
                                    setInvoiceFormData({ ...invoiceFormData, items: newItems });
                                  }}
                                />
                              </div>

                              {/* Name */}
                              <div className="col-span-5">
                                <input 
                                  type="text"
                                  placeholder={language === 'ar' ? 'وصف الصنف' : 'Description'}
                                  className="w-full bg-white border border-brand/20 rounded-xl py-1 px-3 text-[12px] text-right outline-none focus:border-brand transition-all font-bold text-slate-700"
                                  value={item.name}
                                  onChange={(e) => {
                                    const newItems = [...(invoiceFormData.items || [])];
                                    newItems[index] = { ...item, name: e.target.value };
                                    setInvoiceFormData({ ...invoiceFormData, items: newItems });
                                  }}
                                />
                              </div>
                            </div>
                          ))}

                          {/* Add Item Trigger */}
                          <div className="flex justify-center pt-2">
                            <button 
                              onClick={() => {
                                const newItem: InvoiceItem = { id: crypto.randomUUID(), name: '', quantity: 1, price: 0, total: 0 };
                                setInvoiceFormData({
                                  ...invoiceFormData,
                                  items: [...(invoiceFormData.items || []), newItem]
                                });
                              }}
                              className="text-brand flex items-center gap-2 text-[13px] font-bold hover:opacity-80 transition-all font-sans"
                            >
                              <Plus size={16} />
                              <span>{language === 'ar' ? 'أضف صنف جديد' : 'Add New Item'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Grand Total Row */}
                        <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                           <div className="bg-slate-50 px-8 py-2 rounded-xl text-lg font-mono font-black text-slate-900 border border-slate-100">
                             {((invoiceFormData.items || []).reduce((sum, it) => sum + (it.total || 0), 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                           </div>
                           <span className="text-[13px] font-black text-slate-700">{language === 'ar' ? 'المجموع النهائي' : 'GRAND TOTAL'}</span>
                        </div>
                      </div>

                      {/* Statement / Notes Card with AI */}
                      <div className="bg-white p-6 sm:p-8 rounded-[24px] border border-slate-100 shadow-sm space-y-6">
                        <div className="flex items-center justify-between border-b border-slate-50 pb-3">
                          <div className="flex flex-wrap gap-2">
                            <button 
                              onClick={() => handleAiSummarize('extract')}
                              disabled={isAiSummarizing}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all active:scale-95",
                                isAiSummarizing ? "bg-slate-100 text-slate-400" : "bg-blue-50 text-blue-600 hover:bg-blue-100 border border-blue-100"
                              )}
                            >
                              <Wand2 size={12} className={isAiSummarizing ? "animate-spin" : ""} />
                              <span>{language === 'ar' ? 'استخراج البنود ذكياً' : 'AI Smart Extract'}</span>
                            </button>
                            <button 
                              onClick={() => handleAiSummarize('summarize')}
                              disabled={isAiSummarizing}
                              className={cn(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all active:scale-95",
                                isAiSummarizing ? "bg-slate-100 text-slate-400" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100 border border-emerald-100"
                              )}
                            >
                              <Wand2 size={12} className={isAiSummarizing ? "animate-spin text-emerald-400" : "text-emerald-500"} />
                              <span className="font-sans">{language === 'ar' ? 'تلخيص البيان' : 'AI Generate'}</span>
                            </button>
                          </div>
                          <div className={cn("flex items-center gap-2 text-slate-900", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                             <FileText size={16} className="text-brand" />
                             <span className="text-[14px] font-black">{language === 'ar' ? 'ملاحظات / البيان' : 'Notes / Statement'}</span>
                          </div>
                        </div>
                        <textarea 
                          className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-5 px-6 text-sm text-slate-900 outline-none focus:border-brand focus:ring-4 focus:ring-brand/10 transition-all text-right min-h-[140px] resize-none font-sans leading-relaxed"
                          placeholder={language === 'ar' ? 'اكتب ملاحظات إضافية أو اترك الذكاء الاصطناعي يحررها لك...' : 'Add additional notes or let AI write it for you...'}
                          value={invoiceFormData.notes || ''}
                          onChange={(e) => setInvoiceFormData({ ...invoiceFormData, notes: e.target.value })}
                        />
                      </div>

                      {/* Google Drive Attachment Card */}
                      <div className="bg-white p-6 sm:p-8 rounded-[24px] border border-slate-100 shadow-sm space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-50 pb-3">
                          <div className={cn("flex items-center gap-2 text-slate-900", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                             <Icons.HardDrive size={16} className="text-emerald-500" />
                             <span className="text-[14px] font-black">{language === 'ar' ? 'مستندات Google Drive' : 'Google Drive Documents'}</span>
                          </div>
                        </div>

                        {invoiceFormData.attachment ? (
                          <div className={cn("flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-2xl", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                            <div className={cn("flex items-center gap-3", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                              <Icons.FileText size={20} className="text-brand" />
                              <div className={language === 'ar' ? "text-right" : "text-left"}>
                                <a 
                                  href={invoiceFormData.attachment.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-xs font-bold text-brand hover:underline block max-w-[200px] truncate"
                                >
                                  {invoiceFormData.attachment.name}
                                </a>
                                <span className="text-[9px] font-mono text-slate-400 block mt-0.5">
                                  {invoiceFormData.attachment.mimeType}
                                </span>
                              </div>
                            </div>
                            <button 
                              type="button"
                              onClick={() => setInvoiceFormData(prev => ({ ...prev, attachment: undefined }))}
                              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                              title={language === 'ar' ? 'حذف الملف' : 'Remove File'}
                            >
                              <Icons.X size={16} />
                            </button>
                          </div>
                        ) : (
                          <button 
                            type="button"
                            onClick={handleOpenPickerForInvoice}
                            className="w-full py-4 bg-slate-50 border border-dashed border-slate-200 hover:border-brand hover:bg-brand/5 rounded-2xl flex flex-col items-center justify-center gap-2 group transition-all"
                          >
                            <Icons.Cloud size={24} className="text-slate-400 group-hover:text-brand transition-all" />
                            <span className="text-xs font-bold text-slate-600 group-hover:text-brand transition-all">
                              {language === 'ar' ? 'إرفاق ملف من Google Drive' : 'Attach file from Google Drive'}
                            </span>
                            <span className="text-[9px] text-slate-400">
                              {language === 'ar' ? 'اختر فاتورة، إيصال أو مستند PNG، JPG، PDF' : 'Select Invoice, Receipt or Document PNG, JPG, PDF'}
                            </span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Image Styled Actions Bar */}
                  <div className="p-8 bg-white border-t border-slate-100 flex flex-row items-center justify-center gap-3">
                    <button 
                      onClick={() => handleAddInvoice(invoiceFormData)}
                      className="bg-brand text-white px-6 py-3 rounded-xl text-[13px] font-bold shadow-lg shadow-brand/20 hover:shadow-brand/40 transition-all active:scale-95 flex items-center gap-2"
                    >
                      {language === 'ar' ? 'حفظ الفاتورة' : 'Save Invoice'}
                    </button>
                    <button 
                      onClick={() => {
                        const items = (invoiceFormData.items || []) as InvoiceItem[];
                        const tempInvoice: Invoice = {
                          id: 'PREVIEW',
                          invoiceNumber: invoiceFormData.invoiceNumber || 'PREVIEW',
                          date: invoiceFormData.date || format(new Date(), 'yyyy-MM-dd'),
                          items: items,
                          total: items.reduce((sum, it) => sum + it.total, 0),
                          subtotal: items.reduce((sum, it) => sum + it.total, 0),
                          tax: 0,
                          currencyId: (invoiceFormData.currencyId || selectedCurrency) as any,
                          customerName: invoiceFormData.customerName,
                          notes: invoiceFormData.notes,
                          userId: user?.uid || '',
                          createdAt: new Date(),
                          updatedAt: new Date()
                        };
                        exportInvoiceToImage(tempInvoice);
                      }}
                      className="border border-brand text-brand hover:bg-brand/5 px-6 py-3 rounded-xl text-[13px] font-bold transition-all active:scale-95"
                    >
                      {language === 'ar' ? 'تصدير PNG' : 'Export PNG'}
                    </button>
                    <button 
                      onClick={() => {
                        const items = (invoiceFormData.items || []) as InvoiceItem[];
                        const total = items.reduce((sum, it) => sum + it.total, 0);
                        const tempInvoice: Invoice = {
                          id: 'PREVIEW',
                          invoiceNumber: invoiceFormData.invoiceNumber || 'PREVIEW',
                          date: invoiceFormData.date || format(new Date(), 'yyyy-MM-dd'),
                          items: items,
                          total: total,
                          subtotal: total,
                          tax: 0,
                          currencyId: (invoiceFormData.currencyId || selectedCurrency) as any,
                          customerName: invoiceFormData.customerName || '',
                          customerAddress: invoiceFormData.customerAddress || '',
                          paymentTerms: invoiceFormData.paymentTerms || '',
                          notes: invoiceFormData.notes || '',
                          userId: user?.uid || '',
                          createdAt: new Date(),
                          updatedAt: new Date()
                        };
                        exportInvoiceToPDF(tempInvoice);
                      }}
                      className="border border-brand text-brand hover:bg-brand/5 px-6 py-3 rounded-xl text-[13px] font-bold transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <FileDown size={16} />
                      {language === 'ar' ? 'تصدير PDF' : 'Export PDF'}
                    </button>
                  </div>
                </motion.div>
                </>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {isDeleteModalOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => {
                      setIsDeleteModalOpen(false);
                      setTransactionToDelete(null);
                    }}
                    className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] overflow-hidden"
                  />
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm bg-bg-card rounded-[32px] p-8 z-[110] shadow-2xl border border-border-subtle text-center"
                  >
                    <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mx-auto mb-6">
                      <Trash2 size={32} />
                    </div>
                    <h3 className="text-xl font-sans font-medium text-text-main mb-4">{language === 'ar' ? 'تأكيد حذف القيد' : 'Confirm Delete'}</h3>
                    <p className="text-text-muted text-sm leading-relaxed mb-10">
                      {language === 'ar' ? 'هل أنت متأكد من حذف هذه العملية؟ لا يمكنك التراجع عن هذا الإجراء بعد تنفيذه.' : 'Are you sure you want to delete this transaction? This action cannot be undone.'}
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        onClick={handleConfirmDelete}
                        className="bg-red-500 text-white py-3.5 rounded-xl text-xs font-medium hover:bg-red-600 transition-all shadow-lg shadow-red-500/10 active:scale-95"
                      >
                        تأكيد الحذف
                      </button>
                      <button 
                        onClick={() => {
                          setIsDeleteModalOpen(false);
                          setTransactionToDelete(null);
                        }}
                        className="bg-bg-header/50 text-text-muted py-3.5 rounded-xl text-xs font-bold hover:bg-bg-header transition-all border border-border-subtle active:scale-95"
                      >
                        إلغاء
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>

            {/* Reset Confirmation Modal */}
            <AnimatePresence>
              {isResetConfirmOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setIsResetConfirmOpen(false)}
                    className="fixed inset-0 bg-black/80 backdrop-blur-md z-[120]"
                  />
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm bg-bg-card rounded-[32px] p-8 z-[130] shadow-2xl border border-border-subtle text-center"
                  >
                    <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 mx-auto mb-6">
                      <Trash2 size={32} />
                    </div>
                    <h3 className="text-xl font-sans font-bold text-text-main mb-4">{language === 'ar' ? 'تصفير البيانات' : 'Reset Data'}</h3>
                    <p className="text-text-muted text-sm leading-relaxed mb-10">
                      {language === 'ar' ? `هل أنت متأكد من مسح كافة عمليات ${selectedCurrency}؟ لا يمكن التراجع عن هذا الإجراء.` : `Are you sure you want to clear all ${selectedCurrency} transactions? This cannot be undone.`}
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        onClick={handleResetCurrencyData}
                        disabled={isResetLoading}
                        className="bg-red-500 text-white py-3.5 rounded-xl text-xs font-bold hover:bg-red-600 transition-all shadow-lg shadow-red-500/10 active:scale-95 disabled:opacity-50"
                      >
                        {isResetLoading ? '...' : (language === 'ar' ? 'تأكيد الحذف' : 'Confirm Reset')}
                      </button>
                      <button 
                        onClick={() => setIsResetConfirmOpen(false)}
                        className="bg-bg-header/50 text-text-muted py-3.5 rounded-xl text-xs font-bold hover:bg-bg-header transition-all border border-border-subtle active:scale-95"
                      >
                        {language === 'ar' ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>

            {/* Currency Change Confirmation Modal */}
            <AnimatePresence>
              {isCurrencyConfirmOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setIsCurrencyConfirmOpen(false)}
                    className="fixed inset-0 bg-black/80 backdrop-blur-md z-[120]"
                  />
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm bg-bg-card rounded-[32px] p-8 z-[130] shadow-2xl border border-border-subtle text-center"
                  >
                    <div className="w-16 h-16 bg-brand/10 rounded-2xl flex items-center justify-center text-brand mx-auto mb-6">
                      <ArrowRightLeft size={32} />
                    </div>
                    <h3 className="text-xl font-sans font-bold text-text-main mb-4">{language === 'ar' ? 'تبديل العملة' : 'Change Currency'}</h3>
                    <p className="text-text-muted text-sm leading-relaxed mb-10">
                      {language === 'ar' ? `هل أنت متأكد من الانتقال إلى ${pendingCurrency === 'YER' ? 'الريال اليمني' : pendingCurrency === 'SAR' ? 'الريال السعودي' : 'الدولار الأمريكي'}؟ سيتم عزل البيانات تماماً.` : `Switch to ${pendingCurrency}? Data will be completely isolated.`}
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        onClick={confirmCurrencyChange}
                        className="bg-brand text-black py-3.5 rounded-xl text-xs font-bold hover:bg-brand/90 transition-all shadow-lg shadow-brand/10 active:scale-95"
                      >
                        {language === 'ar' ? 'تأكيد التبديل' : 'Confirm'}
                      </button>
                      <button 
                        onClick={() => setIsCurrencyConfirmOpen(false)}
                        className="bg-bg-header/50 text-text-muted py-3.5 rounded-xl text-xs font-bold hover:bg-bg-header transition-all border border-border-subtle active:scale-95"
                      >
                        {language === 'ar' ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </>
        )}
      </div>
    </>
  );
}

const TransactionRow = React.memo(({ transaction: t, onDelete, currency, language, allCategories }: { transaction: Transaction, onDelete: (id: string) => void, currency: string, language: string, allCategories: Category[], key?: string }) => {
  const category = useMemo(() => allCategories.find(c => c.id === t.category), [t.category, allCategories]);
  
  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="group flex flex-col md:flex-row md:items-center justify-between px-4 sm:px-8 py-4 sm:py-5 hover:bg-bg-header/40 transition-all gap-3 sm:gap-4 border-r-4 border-transparent hover:border-brand/40"
    >
      <div className="flex items-center gap-8 flex-1">
        <div className="hidden md:flex flex-col w-24 text-right">
          <span className="font-mono text-[10px] text-text-muted font-bold tracking-tighter">
            {format(parseISO(t.date), 'yyyy/MM/dd')}
          </span>
          <span className="text-[9px] text-text-muted opacity-40 uppercase font-black tracking-widest font-mono">
            {format(parseISO(t.date), 'EEEE', { locale: language === 'ar' ? ar : undefined })}
          </span>
        </div>
        
        <div className="flex-1 flex items-center gap-4">
          <div className={cn(
            "w-8 h-8 rounded-lg flex items-center justify-center transition-all shadow-sm",
            t.type === 'income' ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500"
          )}>
            <CategoryIcon name={category?.icon || ''} size={14} />
          </div>
          <div>
            <div className={cn("flex items-center gap-2", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
              <p className="text-text-main text-xs font-bold leading-tight group-hover:text-brand transition-colors">{t.description || (language === 'ar' ? category?.name : category?.nameEn)}</p>
              {t.attachment && (
                <a 
                  href={t.attachment.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-500 hover:text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-md transition-all font-sans"
                  title={t.attachment.name}
                >
                  <Icons.HardDrive size={10} />
                  <span>{language === 'ar' ? 'مرفق' : 'Drive'}</span>
                </a>
              )}
            </div>
            <div className="flex items-center gap-3 mt-1 md:hidden">
              <span className="text-[9px] text-text-muted font-mono font-bold tabular-nums tracking-tighter">{format(parseISO(t.date), 'yyyy/MM/dd')}</span>
              <span className={cn(
                "text-[8px] px-1.5 py-0.5 rounded-lg border font-mono uppercase tracking-tighter",
                t.type === 'income' ? "bg-emerald-500/5 text-emerald-400 border-emerald-500/10" : "bg-rose-500/5 text-rose-400 border-rose-500/10"
              )}>
                {language === 'ar' ? category?.name : category?.nameEn}
              </span>
            </div>
            <p className="hidden md:block text-[9px] text-text-muted opacity-40 uppercase tracking-widest font-black mt-0.5 font-mono">{language === 'ar' ? category?.name : category?.nameEn}</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-6 justify-between md:justify-end md:w-48">
        <div className={cn(language === 'ar' ? "text-left" : "text-right")}>
          <p className={cn(
            "font-mono font-bold text-base leading-none tabular-nums",
            t.type === 'income' ? "text-emerald-400" : "text-rose-400"
          )}>
            {t.type === 'income' ? '+' : '-'} {formatCurrencyBase(t.amount, currency)}
          </p>
        </div>
        
        <button 
          onClick={() => onDelete(t.id)}
          className="p-2.5 text-text-muted/20 hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all md:opacity-0 md:group-hover:opacity-100 border border-transparent hover:border-rose-500/20"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </motion.div>
  );
});

// Add Transaction Modal Component to isolate form state
const TransactionModal = React.memo(({ 
  isOpen, 
  onClose, 
  onSubmit, 
  currency, 
  language,
  categories,
  ensureGoogleAccessToken
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (data: any) => Promise<void>; 
  currency: string; 
  language: 'ar' | 'en';
  categories: { income: Category[], expense: Category[] };
  ensureGoogleAccessToken: () => Promise<string>;
}) => {
  const [formData, setFormData] = useState<{
    amount: string;
    type: TransactionType;
    category: string;
    date: string;
    description: string;
    attachment?: { id: string; name: string; url: string; mimeType: string };
  }>({
    amount: '',
    type: 'expense' as TransactionType,
    category: categories.expense[0]?.id || '',
    date: format(new Date(), 'yyyy-MM-dd'),
    description: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset category when type changes
  useEffect(() => {
    setFormData(prev => ({ ...prev, category: categories[prev.type][0]?.id || '' }));
  }, [formData.type, categories]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatAmountInput(e.target.value);
    setFormData(prev => ({ ...prev, amount: cleanAmount(formatted) }));
  };

  const handleOpenPicker = async () => {
    try {
      const token = await ensureGoogleAccessToken();
      await openGooglePicker(token, (file) => {
        setFormData(prev => ({
          ...prev,
          attachment: file
        }));
      });
    } catch (error) {
      console.error('Failed to open Google Picker for transaction', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount) return;
    setIsSubmitting(true);
    try {
      await onSubmit(formData);
      setFormData({
        amount: '',
        type: 'expense',
        category: categories.expense[0]?.id || '',
        date: format(new Date(), 'yyyy-MM-dd'),
        description: '',
        attachment: undefined
      });
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 overflow-hidden"
          />
          <motion.div 
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 lg:inset-0 lg:m-auto lg:h-fit lg:max-w-xl bg-bg-card rounded-t-3xl lg:rounded-3xl p-8 z-[60] shadow-2xl border-t lg:border border-border-subtle overflow-y-auto max-h-[90vh]"
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-sans font-bold text-text-main">{language === 'ar' ? 'عملية جديدة' : 'New Transaction'}</h3>
                <p className="text-[10px] text-text-muted mt-1 uppercase tracking-widest font-bold opacity-60">{language === 'ar' ? 'تسجيل دخول أو خروج للأموال' : 'Recording cash inflow or outflow'}</p>
              </div>
              <button 
                onClick={onClose}
                className="w-10 h-10 bg-bg-header/50 text-text-muted rounded-full flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-all border border-border-subtle"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Type Selector */}
              <div className="flex bg-bg-header/30 p-1.5 rounded-2xl border border-border-subtle shadow-inner">
                <button 
                  type="button"
                  onClick={() => setFormData({ ...formData, type: 'expense' })}
                  className={cn(
                    "flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2",
                    formData.type === 'expense' ? "bg-red-500 text-white shadow-lg" : "text-text-muted opacity-40 hover:opacity-100"
                  )}
                >
                  <TrendingDown size={14} />
                  <span>{language === 'ar' ? 'مصروف' : 'EXPENSE'}</span>
                </button>
                <button 
                  type="button"
                  onClick={() => setFormData({ ...formData, type: 'income' })}
                  className={cn(
                    "flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2",
                    formData.type === 'income' ? "bg-emerald-500 text-white shadow-lg" : "text-text-muted opacity-40 hover:opacity-100"
                  )}
                >
                  <TrendingUp size={14} />
                  <span>{language === 'ar' ? 'دخل' : 'INCOME'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Amount Input */}
                <div className="space-y-3">
                  <label className={cn("text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono px-2", language === 'ar' ? "text-right" : "text-left")}>{language === 'ar' ? 'المبلغ' : 'Amount'}</label>
                  <div className="relative group">
                    <input 
                      type="text"
                      inputMode="decimal"
                      required
                      value={formatAmountInput(formData.amount)}
                      onChange={handleAmountChange}
                      className={cn(
                        "w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-6 px-8 text-3xl font-mono font-bold outline-none focus:bg-bg-header/50 transition-all placeholder:opacity-20 text-center tabular-nums",
                        formData.type === 'income' ? "focus:border-emerald-500/40 text-emerald-400" : "focus:border-red-500/40 text-rose-400"
                      )}
                      placeholder="0"
                      dir="ltr"
                    />
                  </div>
                </div>

                {/* Date Input */}
                <div className="space-y-3">
                  <label className={cn("text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono px-2", language === 'ar' ? "text-right" : "text-left")}>{language === 'ar' ? 'تاريخ العملية' : 'Transaction Date'}</label>
                  <input 
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className={cn(
                      "w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-6 px-8 text-sm text-text-main outline-none focus:border-brand/40 focus:bg-bg-header/50 transition-all font-mono",
                      language === 'ar' ? "text-right" : "text-left"
                    )}
                  />
                </div>
              </div>

              {/* Category Selection Grid */}
              <div className="space-y-4">
                <label className={cn("text-[10px] text-text-muted uppercase font-black font-mono tracking-widest block opacity-60 px-2", language === 'ar' ? "text-right" : "text-left")}>
                  {language === 'ar' ? 'الفئة المحاسبية' : 'Accounting Category'}
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2">
                  {categories[formData.type].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, category: cat.id })}
                      className={cn(
                        "flex flex-col items-center gap-1.5 p-2 rounded-xl border transition-all active:scale-95 group relative overflow-hidden",
                        formData.category === cat.id 
                          ? (formData.type === 'income' ? "bg-emerald-500/10 border-emerald-500/40" : "bg-red-500/10 border-red-500/40")
                          : "bg-bg-header/10 border-border-subtle/30 hover:border-brand/30"
                      )}
                    >
                      <div className={cn(
                        "w-6 h-6 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110",
                        formData.category === cat.id 
                          ? (formData.type === 'income' ? "text-emerald-400" : "text-rose-400") 
                          : "text-text-muted opacity-30"
                      )}>
                        <CategoryIcon name={cat.icon} size={12} />
                      </div>
                      <span className={cn(
                        "text-[8px] font-bold font-mono tracking-tighter uppercase whitespace-nowrap",
                        formData.category === cat.id 
                          ? (formData.type === 'income' ? "text-emerald-400" : "text-rose-400") 
                          : "text-text-muted opacity-30 group-hover:opacity-100"
                      )}>{language === 'ar' ? cat.name : cat.nameEn}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Note Input */}
              <div className="space-y-3">
                <label className={cn("text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono px-2", language === 'ar' ? "text-right" : "text-left")}>{language === 'ar' ? 'البيان / الوصف' : 'Description / Note'}</label>
                <input 
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className={cn(
                    "w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-5 px-8 text-sm text-text-main outline-none focus:border-brand/40 focus:bg-bg-header/50 transition-all font-mono placeholder:opacity-20",
                    language === 'ar' ? "text-right" : "text-left"
                  )}
                  placeholder={language === 'ar' ? "وصف مختصر للعملية..." : "Brief description..."}
                />
              </div>

              {/* Google Drive Attachment */}
              <div className="space-y-3">
                <label className={cn("text-[10px] text-text-muted uppercase font-black font-mono tracking-widest block opacity-60 px-2", language === 'ar' ? "text-right" : "text-left")}>
                  {language === 'ar' ? 'إرفاق مستند من Google Drive (اختياري)' : 'Google Drive Attachment (Optional)'}
                </label>
                
                {formData.attachment ? (
                  <div className={cn("flex items-center justify-between p-4 bg-bg-header/20 border border-border-subtle/30 rounded-2xl", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                    <div className={cn("flex items-center gap-3", language === 'ar' ? "flex-row-reverse" : "flex-row")}>
                      <Icons.FileText size={18} className="text-brand" />
                      <div className={language === 'ar' ? "text-right" : "text-left"}>
                        <a 
                          href={formData.attachment.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs font-bold text-brand hover:underline block max-w-[150px] truncate"
                        >
                          {formData.attachment.name}
                        </a>
                        <span className="text-[9px] font-mono text-text-muted opacity-60 block mt-0.5">
                          {formData.attachment.mimeType}
                        </span>
                      </div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, attachment: undefined }))}
                      className="p-1.5 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                    >
                      <Icons.X size={14} />
                    </button>
                  </div>
                ) : (
                  <button 
                    type="button"
                    onClick={handleOpenPicker}
                    className="w-full py-4 bg-bg-header/10 border border-dashed border-border-subtle/50 hover:border-brand/40 hover:bg-brand/5 rounded-2xl flex flex-col items-center justify-center gap-1 group transition-all"
                  >
                    <Icons.Cloud size={20} className="text-text-muted/60 group-hover:text-brand transition-all" />
                    <span className="text-[11px] font-bold text-text-muted group-hover:text-brand transition-all">
                      {language === 'ar' ? 'ربط مستند من Google Drive' : 'Attach file from Google Drive'}
                    </span>
                  </button>
                )}
              </div>

              <button 
                type="submit"
                disabled={isSubmitting}
                className={cn(
                  "w-full py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-xl active:scale-95 transition-all text-white",
                  formData.type === 'income' ? "bg-emerald-500 shadow-emerald-500/20" : "bg-red-500 shadow-red-500/20",
                  isSubmitting && "opacity-50 cursor-not-allowed"
                )}
              >
                {language === 'ar' ? 'حفظ البيانات' : 'SAVE TRANSACTION'}
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
});

// Add Category Modal Component
const CategoryModal = React.memo(({ 
  isOpen, 
  onClose, 
  onSubmit, 
  onDelete,
  formData,
  setFormData,
  editingCategory,
  language
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (e: React.FormEvent) => Promise<void>; 
  onDelete: (id: string) => Promise<void>;
  formData: Partial<Category>;
  setFormData: React.Dispatch<React.SetStateAction<Partial<Category>>>;
  editingCategory: Category | null;
  language: 'ar' | 'en';
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    setIsSubmitting(true);
    try {
      await onSubmit(e);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const isDefaultCategory = editingCategory ? (
    DEFAULT_CATEGORIES.income.some(d => d.id === editingCategory.id) ||
    DEFAULT_CATEGORIES.expense.some(d => d.id === editingCategory.id)
  ) : false;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 overflow-hidden"
          />
          <motion.div 
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 lg:inset-y-0 lg:inset-x-auto lg:right-0 lg:h-full lg:w-[480px] bg-bg-card p-8 z-[60] shadow-2xl border-t lg:border-t-0 lg:border-l border-border-subtle overflow-y-auto max-h-[90vh] lg:max-h-screen"
            dir={language === 'ar' ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-sans font-bold text-text-main">
                  {editingCategory 
                    ? (language === 'ar' ? 'تعديل الفئة' : 'Edit Category')
                    : (language === 'ar' ? 'فئة جديدة' : 'New Category')
                  }
                </h3>
                <p className="text-[10px] text-text-muted mt-1 uppercase tracking-widest font-bold opacity-60 font-sans">
                  {language === 'ar' ? 'تخصيص تصنيف العمليات المالية' : 'Customize financial transaction category'}
                </p>
              </div>
              <button 
                onClick={onClose}
                className="w-10 h-10 bg-bg-header/50 text-text-muted rounded-full flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-all border border-border-subtle"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Type Selector (Income vs Expense) */}
              <div className="space-y-2">
                <label className="text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono">
                  {language === 'ar' ? 'نوع الفئة' : 'Category Type'}
                </label>
                <div className="flex bg-bg-header/30 p-1.5 rounded-2xl border border-border-subtle shadow-inner">
                  <button 
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'expense' }))}
                    className={cn(
                      "flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2",
                      formData.type === 'expense' ? "bg-rose-500 text-white shadow-lg" : "text-text-muted opacity-40 hover:opacity-100"
                    )}
                  >
                    <TrendingDown size={14} />
                    <span>{language === 'ar' ? 'مصروف' : 'EXPENSE'}</span>
                  </button>
                  <button 
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'income' }))}
                    className={cn(
                      "flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2",
                      formData.type === 'income' ? "bg-emerald-500 text-white shadow-lg" : "text-text-muted opacity-40 hover:opacity-100"
                    )}
                  >
                    <TrendingUp size={14} />
                    <span>{language === 'ar' ? 'دخل' : 'INCOME'}</span>
                  </button>
                </div>
              </div>

              {/* Name Arabic */}
              <div className="space-y-2">
                <label className="text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono">
                  {language === 'ar' ? 'اسم الفئة (بالعربية)' : 'Category Name (Arabic)'}
                </label>
                <input 
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-4 px-6 text-sm text-text-main outline-none focus:border-brand/40 focus:bg-bg-header/50 transition-all font-sans text-right"
                  placeholder={language === 'ar' ? 'مثال: وجبات، فواتير...' : 'e.g., Food, Salary...'}
                  dir="rtl"
                />
              </div>

              {/* Name English */}
              <div className="space-y-2">
                <label className="text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono">
                  {language === 'ar' ? 'اسم الفئة (بالإنجليزي - اختياري)' : 'Category Name (English - Optional)'}
                </label>
                <input 
                  type="text"
                  value={formData.nameEn || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, nameEn: e.target.value }))}
                  className="w-full bg-bg-header/30 border border-border-subtle rounded-2xl py-4 px-6 text-sm text-text-main outline-none focus:border-brand/40 focus:bg-bg-header/50 transition-all font-sans text-left"
                  placeholder="e.g., Dining, Utilities..."
                  dir="ltr"
                />
              </div>

              {/* Color Selection Grid */}
              <div className="space-y-3">
                <label className="text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono">
                  {language === 'ar' ? 'لون الفئة' : 'Category Color'}
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {AVAILABLE_COLORS.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, color }))}
                      className={cn(
                        "w-8 h-8 rounded-full transition-all active:scale-90 flex items-center justify-center border-2 border-transparent hover:scale-105",
                        color,
                        formData.color === color ? "border-text-main scale-110 shadow-lg" : "opacity-80"
                      )}
                    >
                      {formData.color === color && (
                        <Check size={14} className="text-white" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Icon Selection Grid */}
              <div className="space-y-3">
                <label className="text-[10px] text-text-muted uppercase font-black tracking-widest block opacity-60 font-mono">
                  {language === 'ar' ? 'رمز الفئة' : 'Category Icon'}
                </label>
                <div className="grid grid-cols-6 gap-2 max-h-[160px] overflow-y-auto p-1.5 bg-bg-header/20 rounded-2xl border border-border-subtle custom-scrollbar">
                  {AVAILABLE_ICONS.map((iconName) => (
                    <button
                      key={iconName}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, icon: iconName }))}
                      className={cn(
                        "flex flex-col items-center justify-center p-3 rounded-xl border transition-all active:scale-90 hover:bg-bg-header/50",
                        formData.icon === iconName 
                          ? "border-brand bg-brand text-black shadow-md font-bold" 
                          : "border-transparent text-text-muted hover:text-text-main hover:border-border-subtle"
                      )}
                      title={iconName}
                    >
                      <CategoryIcon name={iconName} size={18} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 w-full">
                {editingCategory && !isDefaultCategory && (
                  <button 
                    type="button"
                    onClick={async () => {
                      if (editingCategory?.id) {
                        onClose();
                        await onDelete(editingCategory.id);
                      }
                    }}
                    className="flex-1 py-4 rounded-xl font-bold uppercase tracking-[0.1em] text-xs shadow-xl active:scale-95 transition-all text-white bg-rose-600 hover:bg-rose-700 font-sans flex items-center justify-center gap-2"
                  >
                    <Trash2 size={16} />
                    <span>{language === 'ar' ? 'حذف الفئة' : 'DELETE'}</span>
                  </button>
                )}
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className={cn(
                    "py-4 rounded-xl font-bold uppercase tracking-[0.1em] text-xs shadow-xl active:scale-95 transition-all text-black bg-brand hover:bg-brand/90 font-sans",
                    isSubmitting && "opacity-50 cursor-not-allowed",
                    editingCategory && !isDefaultCategory ? "flex-1" : "w-full"
                  )}
                >
                  {editingCategory 
                    ? (language === 'ar' ? 'تحديث الفئة' : 'UPDATE CATEGORY') 
                    : (language === 'ar' ? 'إضافة الفئة' : 'ADD CATEGORY')
                  }
                </button>
              </div>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
});

const CATEGORY_ICONS_MAP: any = {
  Wallet, Briefcase, Gift, Plus, Utensils, Home, Car, HeartPulse, Gamepad2, ShoppingBag, MoreHorizontal,
  Banknote, Building2, Sparkles, CircleDollarSign, Coffee, Key, BusFront, Stethoscope, Tv, ShoppingCart, Receipt,
  TrendingUp, TrendingDown
};

const AVAILABLE_ICONS = [
  'Tag', 'ShoppingCart', 'Utensils', 'BusFront', 'HeartPulse', 'Tv', 'Key', 'Home', 
  'Wallet', 'Banknote', 'Briefcase', 'Gift', 'Sparkles', 'Coffee', 'Gamepad2',
  'Stethoscope', 'Phone', 'MapPin', 'FileText', 'Car', 'ShoppingBag', 'ShoppingBasket', 'Smartphone', 'Laptop', 'GraduationCap', 'Plane', 'TrainFront', 'Camera', 'Music'
];

const AVAILABLE_COLORS = [
  'bg-emerald-500', 'bg-blue-500', 'bg-red-500', 'bg-orange-500', 'bg-indigo-500',
  'bg-purple-500', 'bg-pink-500', 'bg-amber-500', 'bg-rose-500', 'bg-cyan-500',
  'bg-slate-500', 'bg-lime-500', 'bg-teal-500', 'bg-brand'
];

// Icon Helper
function CategoryIcon({ name, size = 20, className }: { name: string, size?: number, className?: string }) {
  const Icon = (Icons as any)[name] || Icons.HelpCircle || Icons.Tag;
  return <Icon size={size} className={className} />;
}

function CustomTooltip({ active, payload, currency, language }: any) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-bg-card p-4 rounded-2xl border border-border-subtle shadow-2xl backdrop-blur-md min-w-[220px] z-[100]">
        <p className="text-text-main font-mono font-bold text-[10px] mb-3 border-b border-border-subtle pb-2 text-right opacity-80 uppercase tracking-tighter">
          {format(parseISO(data.fullDate), 'EEEE, d MMMM', { locale: language === 'ar' ? ar : undefined })}
        </p>
        <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
          {data.transactions && data.transactions.length > 0 ? (
            data.transactions.map((t: any) => (
              <div key={t.id} className="flex justify-between items-center gap-4 text-[9px] text-right">
                <span className="text-text-muted truncate flex-1 order-2 opacity-60 font-mono tracking-tighter">{t.description || (language === 'ar' ? "بدون وصف" : "No description")}</span>
                <span className={cn(
                  "font-mono font-bold order-1 tabular-nums tracking-tighter",
                  t.type === 'income' ? "text-emerald-400" : "text-orange-400"
                )}>
                  {t.type === 'income' ? '+' : '-'} {formatCurrencyBase(t.amount, currency, language)}
                </span>
              </div>
            ))
          ) : (
            <p className="text-[9px] text-text-muted opacity-40 text-center font-mono uppercase tracking-widest">{language === 'ar' ? 'لا توجد عمليات' : 'No Transactions'}</p>
          )}
        </div>
        <div className="mt-4 pt-2 border-t border-border-subtle flex justify-between items-center text-[9px] font-black uppercase tracking-widest font-mono opactity-80 text-right">
           <span className="text-brand">{language === 'ar' ? 'صافي اليوم:' : 'Daily Net:'}</span>
           <span className={cn(data.income - data.expenses >= 0 ? "text-emerald-400" : "text-orange-400")}>
             {formatCurrencyBase(data.income - data.expenses, currency, language)}
           </span>
        </div>
      </div>
    );
  }
  return null;
}
