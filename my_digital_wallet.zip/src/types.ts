export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  date: string;
  currencyId: 'YER' | 'SAR' | 'USD';
  userId?: string;
  createdAt?: any;
  updatedAt?: any;
  attachment?: {
    id: string;
    name: string;
    url: string;
    mimeType: string;
  };
}

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  color: string;
  type: TransactionType;
  userId?: string;
  createdAt?: any;
  updatedAt?: any;
}

export const DEFAULT_CATEGORIES: Record<TransactionType, Category[]> = {
  income: [
    { id: 'salary', name: 'راتب', nameEn: 'Salary', icon: 'Banknote', color: 'bg-emerald-500', type: 'income' },
    { id: 'business', name: 'عمل حر', nameEn: 'Business', icon: 'Wallet', color: 'bg-emerald-600', type: 'income' },
    { id: 'gift', name: 'هدية', nameEn: 'Gift', icon: 'Sparkles', color: 'bg-sky-500', type: 'income' },
    { id: 'other_income', name: 'أخرى', nameEn: 'Other', icon: 'CircleDollarSign', color: 'bg-gray-500', type: 'income' },
  ],
  expense: [
    { id: 'food', name: 'طعام', nameEn: 'Food', icon: 'Utensils', color: 'bg-orange-500', type: 'expense' },
    { id: 'rent', name: 'إيجار', nameEn: 'Rent', icon: 'Key', color: 'bg-blue-500', type: 'expense' },
    { id: 'transport', name: 'مواصلات', nameEn: 'Transport', icon: 'BusFront', color: 'bg-indigo-500', type: 'expense' },
    { id: 'health', name: 'صحة', nameEn: 'Health', icon: 'HeartPulse', color: 'bg-red-500', type: 'expense' },
    { id: 'entertainment', name: 'ترفيه', nameEn: 'Entertainment', icon: 'Tv', color: 'bg-purple-500', type: 'expense' },
    { id: 'shopping', name: 'تسوق', nameEn: 'Shopping', icon: 'ShoppingCart', color: 'bg-pink-500', type: 'expense' },
    { id: 'other_expense', name: 'أخرى', nameEn: 'Other', icon: 'Receipt', color: 'bg-gray-500', type: 'expense' },
  ],
};

export interface InvoiceItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  total: number;
  date: string;
  currencyId: 'YER' | 'SAR' | 'USD';
  customerName?: string;
  shopName?: string;
  customerAddress?: string;
  paymentTerms?: string;
  notes?: string;
  userId: string;
  createdAt: any;
  updatedAt: any;
  attachment?: {
    id: string;
    name: string;
    url: string;
    mimeType: string;
  };
}
