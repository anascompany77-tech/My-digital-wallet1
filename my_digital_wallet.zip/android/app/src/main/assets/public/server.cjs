var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var ai = new import_genai.GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.post("/api/ai/summarize-invoice", async (req, res) => {
    const { transactions, text, language, mode } = req.body;
    try {
      let prompt = "";
      if (mode === "extract") {
        prompt = language === "ar" ? `\u0642\u0645 \u0628\u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0644\u0643\u0645\u064A\u0627\u062A \u0645\u0646 \u0627\u0644\u0646\u0635 \u0627\u0644\u062A\u0627\u0644\u064A \u0648\u062D\u0648\u0644\u0647\u0627 \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 JSON. 
             \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0627\u0644\u0631\u062F \u0639\u0628\u0627\u0631\u0629 \u0639\u0646 JSON \u0641\u0642\u0637 \u0628\u0627\u0644\u062A\u0646\u0633\u064A\u0642 \u0627\u0644\u062A\u0627\u0644\u064A:
             {"items": [{"name": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u062A\u062C", "quantity": 1, "price": 10.0, "total": 10.0}]}
             \u0627\u0644\u0646\u0635: ${text}` : `Extract product names, prices, and quantities from the following text and convert them into a JSON list.
             The response must be JSON only in this format:
             {"items": [{"name": "product name", "quantity": 1, "price": 10.0, "total": 10.0}]}
             Text: ${text}`;
      } else {
        if (!transactions || !Array.isArray(transactions) || transactions.length === 0) {
          return res.status(400).json({ error: "No transactions provided" });
        }
        const transactionSummary = transactions.map(
          (t) => `- ${t.date}: ${t.description || (language === "ar" ? "\u0628\u062F\u0648\u0646 \u0648\u0635\u0641" : "No description")} (${t.amount})`
        ).join("\n");
        prompt = language === "ar" ? `\u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u062A\u0627\u0644\u064A\u0629\u060C \u0642\u0645 \u0628\u0625\u0646\u0634\u0627\u0621 \u0628\u064A\u0627\u0646 \u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u062D\u062A\u0631\u0627\u0641\u064A \u0648\u0645\u062E\u062A\u0635\u0631 \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629. \u064A\u062C\u0628 \u0623\u0646 \u064A\u0644\u062E\u0635 \u0627\u0644\u063A\u0631\u0636 \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0628\u0634\u0643\u0644 \u0639\u0627\u0645 \u0648\u0645\u0646\u0627\u0633\u0628 \u0644\u0644\u062A\u062C\u0627\u0631\u0629:

${transactionSummary}

\u0627\u0644\u0628\u064A\u0627\u0646 \u0627\u0644\u0645\u0637\u0644\u0648\u0628:` : `Based on the following transactions, generate a professional and concise invoice statement in English. It should summarize the general purpose of these transactions for business use:

${transactionSummary}

Statement:`;
      }
      const response = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: prompt
      });
      const resultText = response.text || "";
      if (mode === "extract") {
        const jsonMatch = resultText.match(/\{[\s\S]*\}/);
        const jsonData = jsonMatch ? JSON.parse(jsonMatch[0]) : { items: [] };
        res.json(jsonData);
      } else {
        res.json({ summary: resultText.trim() });
      }
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error.message || "Failed to process AI request" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
