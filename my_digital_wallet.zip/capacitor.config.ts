import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aldatfar.app',
  appName: 'AlDaftar',
  webDir: 'dist'
};

export default config;
