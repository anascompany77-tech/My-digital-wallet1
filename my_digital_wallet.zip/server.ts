import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/ai/summarize-invoice", async (req, res) => {
    const { transactions, text, language, mode } = req.body;

    try {
      let prompt = "";
      if (mode === 'extract') {
        prompt = language === 'ar'
          ? `قم باستخراج أسماء المنتجات والأسعار والكميات من النص التالي وحولها إلى قائمة JSON. 
             يجب أن يكون الرد عبارة عن JSON فقط بالتنسيق التالي:
             {"items": [{"name": "اسم المنتج", "quantity": 1, "price": 10.0, "total": 10.0}]}
             النص: ${text}`
          : `Extract product names, prices, and quantities from the following text and convert them into a JSON list.
             The response must be JSON only in this format:
             {"items": [{"name": "product name", "quantity": 1, "price": 10.0, "total": 10.0}]}
             Text: ${text}`;
      } else {
        if (!transactions || !Array.isArray(transactions) || transactions.length === 0) {
          return res.status(400).json({ error: "No transactions provided" });
        }
        const transactionSummary = transactions.map(t => 
          `- ${t.date}: ${t.description || (language === 'ar' ? 'بدون وصف' : 'No description')} (${t.amount})`
        ).join("\n");

        prompt = language === 'ar' 
          ? `بناءً على المعاملات التالية، قم بإنشاء بيان فاتورة احترافي ومختصر باللغة العربية. يجب أن يلخص الغرض من هذه المعاملات بشكل عام ومناسب للتجارة:\n\n${transactionSummary}\n\nالبيان المطلوب:`
          : `Based on the following transactions, generate a professional and concise invoice statement in English. It should summarize the general purpose of these transactions for business use:\n\n${transactionSummary}\n\nStatement:`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });

      const resultText = response.text || "";
      if (mode === 'extract') {
        // Extract JSON block if present
        const jsonMatch = resultText.match(/\{[\s\S]*\}/);
        const jsonData = jsonMatch ? JSON.parse(jsonMatch[0]) : { items: [] };
        res.json(jsonData);
      } else {
        res.json({ summary: resultText.trim() });
      }
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error.message || "Failed to process AI request" });
    }
  });

  app.post("/api/ai/organize-invoice", async (req, res) => {
    const { invoice, language } = req.body;

    if (!invoice) {
      return res.status(400).json({ error: "No invoice data provided" });
    }

    try {
      const prompt = `You are an expert professional AI accountant and invoice system.
Your goal is to organize, optimize, format, and professionalize all the fields of the invoice to look highly professional, complete, and formatted correctly for a commercial transaction.

Input Invoice Details:
- Invoice Reference Number: ${invoice.invoiceNumber || ""}
- Date: ${invoice.date || ""}
- Selected Language: ${language === "ar" ? "Arabic" : "English"}
- Items entered so far: ${JSON.stringify(invoice.items || [])}
- Raw Notes / Descriptions / Paste area: ${invoice.notes || ""}
- Shop Name Entered: ${invoice.shopName || ""}
- Customer Address Entered: ${invoice.customerAddress || ""}
- Payment Terms Entered: ${invoice.paymentTerms || ""}

Your strict rules:
1. If the 'items' list is thin or empty, but 'notes' contains information about products, services, hours, prices, or a raw pasted purchase text (e.g., "3 items of X for $10 each"), automatically extract and convert these into the structured 'items' array.
2. Standardize and refine the item names so they sound highly professional and polished in the target language (${language === "ar" ? "Arabic (العربية)" : "English"}). Do not use generic names.
3. For each item, ensure: quantity, price, and total are filled. (total = quantity * price). Keep values clean and positive.
4. Rewrite the 'notes' field as a highly elegant, professional invoice statement, terms, or thanks letter in the target language (${language === "ar" ? "Arabic (العربية)" : "English"}). For example: "نشكركم على تعاملكم معنا. يرجى سداد المبلغ المتبقي خلال المدة المحددة..." or "Thank you for your business. Please settle the payment according to terms."
5. Extract the Shop Name (اسم المحل) if implied in notes, or keep/suggest a highly professional commercial name. If completely unspecified, suggest a premium business/shop name relevant to the content (e.g., "متجر النخبة الرقمي" or "Elite Digital Store", etc.).
6. Always output valid JSON strictly matching the response schema. Never include markdown wrappers like \`\`\`json.

Return the organized invoice data.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              items: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    name: { type: "STRING" },
                    quantity: { type: "NUMBER" },
                    price: { type: "NUMBER" },
                    total: { type: "NUMBER" }
                  },
                  required: ["name", "quantity", "price", "total"]
                }
              },
              notes: { type: "STRING" },
              shopName: { type: "STRING" },
              customerAddress: { type: "STRING" },
              paymentTerms: { type: "STRING" }
            },
            required: ["items", "notes", "shopName", "customerAddress", "paymentTerms"]
          }
        }
      });

      const responseText = response.text || "{}";
      const cleanJson = JSON.parse(responseText.trim());
      res.json(cleanJson);
    } catch (error: any) {
      console.error("Error organizing invoice via AI:", error);
      res.status(500).json({ error: error.message || "Failed to organize invoice with AI" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
