import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', 'android/**/*', 'public/**/*']
  },
  firebaseRulesPlugin.configs['flat/recommended']
];
