# Security Specification - Accounting Ledger

## 1. Data Invariants
- **Identity Integrity**: All transactions must have a `userId` field that strictly matches the `request.auth.uid`.
- **Relational Integrity**: Transactions are stored under `users/{userId}/transactions/{transactionId}`. The `userId` in the path must match the `userId` in the document data.
- **Type Safety**: 
  - `amount` must be a positive number (or at least a number).
  - `type` must be one of ['income', 'expense'].
  - `category` must be a string.
  - `date` must be a string (or date format).
- **Temporal Integrity**:
  - `createdAt` must be set to `request.time` on creation and never modified.
  - `updatedAt` must be set to `request.time` on every write.

## 2. The "Dirty Dozen" Payloads

### P1: Identity Spoofing (Creation)
Attempt to create a transaction with a different `userId` in the data.
```json
{
  "id": "trans_1",
  "type": "expense",
  "amount": 100,
  "category": "food",
  "description": "Stealing credit",
  "date": "2024-03-20",
  "userId": "SOME_OTHER_USER_ID",
  "createdAt": "SERVER_TIMESTAMP",
  "updatedAt": "SERVER_TIMESTAMP"
}
```
**Expected**: PERMISSION_DENIED

### P2: Identity Spoofing (Path vs Data)
Attempt to write to `users/MY_UID/transactions/ID` but with `userId: OTHER_UID` in payload.
**Expected**: PERMISSION_DENIED

### P3: Resource Poisoning (ID)
Attempt to use an extremely long ID (>128 chars).
**Expected**: PERMISSION_DENIED

### P4: Value Poisoning (Types)
Attempt to set `amount` as a string.
```json
{
  "amount": "one million dollars"
}
```
**Expected**: PERMISSION_DENIED

### P5: Enum Breakage
Attempt to set `type` to "lottery_winnings" (not in enum).
**Expected**: PERMISSION_DENIED

### P6: Ghost Field Injection (Shadow Update)
Attempt to add an `isAdmin: true` field.
```json
{
  "isAdmin": true,
  "amount": 50
}
```
**Expected**: PERMISSION_DENIED

### P7: Immutability Violation
Attempt to update `createdAt` field.
**Expected**: PERMISSION_DENIED

### P8: Ownership Leak (Read)
Attempt to read `users/OTHER_USER/transactions/ID`.
**Expected**: PERMISSION_DENIED

### P9: Blanket Read Attack
Attempt to list all transactions without specifying a user path (if attempted).
**Expected**: PERMISSION_DENIED (by rules)

### P10: Unverified Access
Attempt to write with `email_verified: false` (if we enforce this).
**Expected**: PERMISSION_DENIED

### P11: Resource Exhaustion (String Size)
Attempt to send a 1MB description string.
**Expected**: PERMISSION_DENIED

### P12: Orphaned Write
Attempt to update a document by changing its `userId`.
**Expected**: PERMISSION_DENIED

## 3. Test Runner (Conceptual)
A `firestore.rules.test.ts` will be implemented to verify these.
